# WordPress : http://localhost:8080/fixitall MySQL database backup
#
# Generated: Wednesday 30. April 2014 03:27 UTC
# Hostname: localhost
# Database: `fixitall`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_forms`
# --------------------------------------------------------


#
# Delete any existing table `wp_cftemail_forms`
#

DROP TABLE IF EXISTS `wp_cftemail_forms`;


#
# Table structure of table `wp_cftemail_forms`
#

CREATE TABLE `wp_cftemail_forms` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `form_name` varchar(250) NOT NULL DEFAULT '',
  `form_structure` text,
  `fp_from_email` varchar(250) NOT NULL DEFAULT '',
  `fp_destination_emails` text,
  `fp_subject` varchar(250) NOT NULL DEFAULT '',
  `fp_inc_additional_info` varchar(10) NOT NULL DEFAULT '',
  `fp_return_page` varchar(250) NOT NULL DEFAULT '',
  `fp_message` text,
  `fp_emailformat` varchar(10) NOT NULL DEFAULT '',
  `cu_enable_copy_to_user` varchar(10) NOT NULL DEFAULT '',
  `cu_user_email_field` varchar(250) NOT NULL DEFAULT '',
  `cu_subject` varchar(250) NOT NULL DEFAULT '',
  `cu_message` text,
  `cu_emailformat` varchar(10) NOT NULL DEFAULT '',
  `fp_emailfrommethod` varchar(10) NOT NULL DEFAULT '',
  `vs_use_validation` varchar(10) NOT NULL DEFAULT '',
  `vs_text_is_required` varchar(250) NOT NULL DEFAULT '',
  `vs_text_is_email` varchar(250) NOT NULL DEFAULT '',
  `vs_text_datemmddyyyy` varchar(250) NOT NULL DEFAULT '',
  `vs_text_dateddmmyyyy` varchar(250) NOT NULL DEFAULT '',
  `vs_text_number` varchar(250) NOT NULL DEFAULT '',
  `vs_text_digits` varchar(250) NOT NULL DEFAULT '',
  `vs_text_max` varchar(250) NOT NULL DEFAULT '',
  `vs_text_min` varchar(250) NOT NULL DEFAULT '',
  `vs_text_submitbtn` varchar(250) NOT NULL DEFAULT '',
  `vs_text_previousbtn` varchar(250) NOT NULL DEFAULT '',
  `vs_text_nextbtn` varchar(250) NOT NULL DEFAULT '',
  `rep_enable` varchar(10) NOT NULL DEFAULT '',
  `rep_days` varchar(10) NOT NULL DEFAULT '',
  `rep_hour` varchar(10) NOT NULL DEFAULT '',
  `rep_emails` text,
  `rep_subject` text,
  `rep_emailformat` varchar(10) NOT NULL DEFAULT '',
  `rep_message` text,
  `cv_enable_captcha` varchar(20) NOT NULL DEFAULT '',
  `cv_width` varchar(20) NOT NULL DEFAULT '',
  `cv_height` varchar(20) NOT NULL DEFAULT '',
  `cv_chars` varchar(20) NOT NULL DEFAULT '',
  `cv_font` varchar(20) NOT NULL DEFAULT '',
  `cv_min_font_size` varchar(20) NOT NULL DEFAULT '',
  `cv_max_font_size` varchar(20) NOT NULL DEFAULT '',
  `cv_noise` varchar(20) NOT NULL DEFAULT '',
  `cv_noise_length` varchar(20) NOT NULL DEFAULT '',
  `cv_background` varchar(20) NOT NULL DEFAULT '',
  `cv_border` varchar(20) NOT NULL DEFAULT '',
  `cv_text_enter_valid_captcha` varchar(200) NOT NULL DEFAULT '',
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_cftemail_forms (1 records)
#
 
INSERT INTO `wp_cftemail_forms` VALUES (1, 'Form 1', '[[{"name":"email","index":0,"title":"Email","ftype":"femail","userhelp":"","csslayout":"","required":true,"predefined":"","size":"large","shortlabel":"","userhelpTooltip":false,"predefinedClick":false,"equalTo":""},{"name":"fieldname1","index":1,"title":"Phone:","required":true,"shortlabel":"","ftype":"ftext","userhelp":"","userhelpTooltip":false,"csslayout":"","predefined":"","predefinedClick":false,"size":"medium","minlength":"","maxlength":"","equalTo":""},{"name":"subject","index":2,"title":"City or Zip Code","required":true,"ftype":"ftext","userhelp":"","csslayout":"","predefined":"","size":"large","shortlabel":"","userhelpTooltip":false,"predefinedClick":false,"minlength":"","maxlength":"","equalTo":""},{"name":"message","index":3,"size":"large","required":true,"title":"What\'s the problem?","ftype":"ftextarea","userhelp":"","csslayout":"","predefined":"","shortlabel":"","userhelpTooltip":false,"predefinedClick":false,"minlength":"","maxlength":""}],[{"title":"Contact Form","description":"You can use the following form to contact us.","formlayout":"top_aligned"}]]', 'kshoufer@gmail.com', 'kshoufer@gmail.com', 'Contact from the blog...', 'true', 'http://localhost:8080/fixitall/', 'The following contact message has been sent:

<%INFO%>

', 'text', 'true', 'email', 'Confirmation: Message received...', 'Thank you for your message. We will reply you as soon as possible.

This is a copy of the data sent:

<%INFO%>

Best Regards.', 'text', 'fixed', 'true', 'This field is required.', 'Please enter a valid email address.', 'Please enter a valid date with this format(mm/dd/yyyy)', 'Please enter a valid date with this format(dd/mm/yyyy)', 'Please enter a valid number.', 'Please enter only digits.', 'Please enter a value less than or equal to {0}.', 'Please enter a value greater than or equal to {0}.', 'Submit', 'Previous', 'Next', 'no', '1', '0', '', 'Submissions report...', 'text', 'Attached you will find the data from the form submissions.', 'false', '180', '60', '5', 'font-1.ttf', '25', '35', '200', '4', 'ffffff', '000000', 'Please enter a valid captcha code.') ;
#
# End of data contents of table wp_cftemail_forms
# --------------------------------------------------------

# WordPress : http://localhost:8080/fixitall MySQL database backup
#
# Generated: Wednesday 30. April 2014 03:27 UTC
# Hostname: localhost
# Database: `fixitall`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_messages`
# --------------------------------------------------------


#
# Delete any existing table `wp_cftemail_messages`
#

DROP TABLE IF EXISTS `wp_cftemail_messages`;


#
# Table structure of table `wp_cftemail_messages`
#

CREATE TABLE `wp_cftemail_messages` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `formid` int(11) NOT NULL,
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ipaddr` varchar(32) NOT NULL DEFAULT '',
  `notifyto` varchar(250) NOT NULL DEFAULT '',
  `data` text,
  `posted_data` text,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_cftemail_messages (0 records)
#

#
# End of data contents of table wp_cftemail_messages
# --------------------------------------------------------

# WordPress : http://localhost:8080/fixitall MySQL database backup
#
# Generated: Wednesday 30. April 2014 03:27 UTC
# Hostname: localhost
# Database: `fixitall`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_messages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_commentmeta (0 records)
#

#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost:8080/fixitall MySQL database backup
#
# Generated: Wednesday 30. April 2014 03:27 UTC
# Hostname: localhost
# Database: `fixitall`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_messages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_comments (1 records)
#
 
INSERT INTO `wp_comments` VALUES (1, 1, 'Mr WordPress', '', 'http://wordpress.org/', '', '2014-02-13 15:22:52', '2014-02-13 15:22:52', 'Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;
#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://localhost:8080/fixitall MySQL database backup
#
# Generated: Wednesday 30. April 2014 03:27 UTC
# Hostname: localhost
# Database: `fixitall`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_messages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_links (0 records)
#

#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://localhost:8080/fixitall MySQL database backup
#
# Generated: Wednesday 30. April 2014 03:27 UTC
# Hostname: localhost
# Database: `fixitall`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_messages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter`
# --------------------------------------------------------


#
# Delete any existing table `wp_newsletter`
#

DROP TABLE IF EXISTS `wp_newsletter`;


#
# Table structure of table `wp_newsletter`
#

CREATE TABLE `wp_newsletter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `surname` varchar(100) NOT NULL DEFAULT '',
  `sex` char(1) NOT NULL DEFAULT 'n',
  `status` char(1) NOT NULL DEFAULT 'S',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` varchar(50) NOT NULL DEFAULT '',
  `feed` tinyint(4) NOT NULL DEFAULT '0',
  `feed_time` bigint(20) NOT NULL DEFAULT '0',
  `country` varchar(4) NOT NULL DEFAULT '',
  `list_1` tinyint(4) NOT NULL DEFAULT '0',
  `list_2` tinyint(4) NOT NULL DEFAULT '0',
  `list_3` tinyint(4) NOT NULL DEFAULT '0',
  `list_4` tinyint(4) NOT NULL DEFAULT '0',
  `list_5` tinyint(4) NOT NULL DEFAULT '0',
  `list_6` tinyint(4) NOT NULL DEFAULT '0',
  `list_7` tinyint(4) NOT NULL DEFAULT '0',
  `list_8` tinyint(4) NOT NULL DEFAULT '0',
  `list_9` tinyint(4) NOT NULL DEFAULT '0',
  `list_10` tinyint(4) NOT NULL DEFAULT '0',
  `list_11` tinyint(4) NOT NULL DEFAULT '0',
  `list_12` tinyint(4) NOT NULL DEFAULT '0',
  `list_13` tinyint(4) NOT NULL DEFAULT '0',
  `list_14` tinyint(4) NOT NULL DEFAULT '0',
  `list_15` tinyint(4) NOT NULL DEFAULT '0',
  `list_16` tinyint(4) NOT NULL DEFAULT '0',
  `list_17` tinyint(4) NOT NULL DEFAULT '0',
  `list_18` tinyint(4) NOT NULL DEFAULT '0',
  `list_19` tinyint(4) NOT NULL DEFAULT '0',
  `list_20` tinyint(4) NOT NULL DEFAULT '0',
  `profile_1` varchar(255) NOT NULL DEFAULT '',
  `profile_2` varchar(255) NOT NULL DEFAULT '',
  `profile_3` varchar(255) NOT NULL DEFAULT '',
  `profile_4` varchar(255) NOT NULL DEFAULT '',
  `profile_5` varchar(255) NOT NULL DEFAULT '',
  `profile_6` varchar(255) NOT NULL DEFAULT '',
  `profile_7` varchar(255) NOT NULL DEFAULT '',
  `profile_8` varchar(255) NOT NULL DEFAULT '',
  `profile_9` varchar(255) NOT NULL DEFAULT '',
  `profile_10` varchar(255) NOT NULL DEFAULT '',
  `profile_11` varchar(255) NOT NULL DEFAULT '',
  `profile_12` varchar(255) NOT NULL DEFAULT '',
  `profile_13` varchar(255) NOT NULL DEFAULT '',
  `profile_14` varchar(255) NOT NULL DEFAULT '',
  `profile_15` varchar(255) NOT NULL DEFAULT '',
  `profile_16` varchar(255) NOT NULL DEFAULT '',
  `profile_17` varchar(255) NOT NULL DEFAULT '',
  `profile_18` varchar(255) NOT NULL DEFAULT '',
  `profile_19` varchar(255) NOT NULL DEFAULT '',
  `profile_20` varchar(255) NOT NULL DEFAULT '',
  `referrer` varchar(50) NOT NULL DEFAULT '',
  `http_referer` varchar(255) NOT NULL DEFAULT '',
  `wp_user_id` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `test` tinyint(4) NOT NULL DEFAULT '0',
  `flow` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_newsletter (0 records)
#

#
# End of data contents of table wp_newsletter
# --------------------------------------------------------

# WordPress : http://localhost:8080/fixitall MySQL database backup
#
# Generated: Wednesday 30. April 2014 03:27 UTC
# Hostname: localhost
# Database: `fixitall`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_messages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_emails`
# --------------------------------------------------------


#
# Delete any existing table `wp_newsletter_emails`
#

DROP TABLE IF EXISTS `wp_newsletter_emails`;


#
# Table structure of table `wp_newsletter_emails`
#

CREATE TABLE `wp_newsletter_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` longtext,
  `message_text` longtext,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(50) NOT NULL DEFAULT '',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('new','sending','sent','paused') NOT NULL DEFAULT 'new',
  `total` int(11) NOT NULL DEFAULT '0',
  `last_id` int(11) NOT NULL DEFAULT '0',
  `sent` int(11) NOT NULL DEFAULT '0',
  `send_on` int(11) NOT NULL DEFAULT '0',
  `track` tinyint(4) NOT NULL DEFAULT '0',
  `editor` tinyint(4) NOT NULL DEFAULT '0',
  `sex` char(1) NOT NULL DEFAULT '',
  `query` mediumtext,
  `preferences` mediumtext,
  `options` longtext,
  `token` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_newsletter_emails (0 records)
#

#
# End of data contents of table wp_newsletter_emails
# --------------------------------------------------------

# WordPress : http://localhost:8080/fixitall MySQL database backup
#
# Generated: Wednesday 30. April 2014 03:27 UTC
# Hostname: localhost
# Database: `fixitall`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_messages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_emails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_stats`
# --------------------------------------------------------


#
# Delete any existing table `wp_newsletter_stats`
#

DROP TABLE IF EXISTS `wp_newsletter_stats`;


#
# Table structure of table `wp_newsletter_stats`
#

CREATE TABLE `wp_newsletter_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `email_id` int(11) NOT NULL DEFAULT '0',
  `link_id` int(11) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `url` varchar(255) NOT NULL DEFAULT '',
  `anchor` varchar(200) NOT NULL DEFAULT '',
  `ip` varchar(20) NOT NULL DEFAULT '',
  `country` varchar(4) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `email_id` (`email_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_newsletter_stats (0 records)
#

#
# End of data contents of table wp_newsletter_stats
# --------------------------------------------------------

# WordPress : http://localhost:8080/fixitall MySQL database backup
#
# Generated: Wednesday 30. April 2014 03:27 UTC
# Hostname: localhost
# Database: `fixitall`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_messages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_emails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_stats`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=1130 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_options (188 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://localhost:8080/fixitall/', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'blogname', 'PluMax', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogdescription', 'Plumbing to the max', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'admin_email', 'kshoufer@gmail.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_pingback_flag', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (21, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (25, 'links_recently_updated_prepend', '<em>', 'yes') ; 
INSERT INTO `wp_options` VALUES (26, 'links_recently_updated_append', '</em>', 'yes') ; 
INSERT INTO `wp_options` VALUES (27, 'links_recently_updated_time', '120', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'permalink_structure', '/%postname%/', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (32, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (33, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (35, 'active_plugins', 'a:5:{i:0;s:35:"backupwordpress/backupwordpress.php";i:1;s:39:"contact-form-to-email/form-to-email.php";i:2;s:21:"newsletter/plugin.php";i:3;s:33:"w3-total-cache/w3-total-cache.php";i:4;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (36, 'home', 'http://localhost:8080/fixitall/', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (41, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'recently_edited', '', 'no') ; 
INSERT INTO `wp_options` VALUES (44, 'template', 'Divi', 'yes') ; 
INSERT INTO `wp_options` VALUES (45, 'stylesheet', 'Divi-Child', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (48, 'comment_registration', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (49, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (50, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'db_version', '26691', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'upload_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'blog_public', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'show_on_front', 'page', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (70, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wp_options` VALUES (71, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'page_comments', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'widget_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (83, 'widget_text', 'a:6:{i:2;a:3:{s:5:"title";s:16:"Citys We Service";s:4:"text";s:2263:"<table id="cities" cellpadding="0" cellspacing=\'0\' style=\'font-size:9pt;\' width=100%>
               <tr>
               	<td width=\'30%\'>Artesia</td>
               	 <td>Orange</td>
                </tr>
               <tr width=\'33%\'>
                 <td>Bell</td>
                 <td>Garden Grove</td>
                 <td>Palos Verdes </td>
                 </tr>
               <tr>
                 <td>Bell Gardens</td>
                 <td width="30%">Gardena</td>
                 <td>Paramount</td>
                 </tr>
               <tr>
                 <td>Bellflower</td>
                 <td>Hawaiian Gardens</td>
                 <td>Redondo Beach</td>
                 </tr>
               <tr>
                 <td>Buena Park</td>
                 <td>Hermosa Beach</td>
                 <td>Rolling Hills</td>
                 </tr>
               <tr>
                 <td>Carson</td>
                 <td>Huntington Beach</td>
                 <td>Santa Fe Springs</td>
                 </tr>
               <tr>
                 <td>Cerritos</td>
                 <td>Inglewood</td>
                 <td>Santa Monica</td>
                 </tr>
               <tr>
                 <td>Compton</td>
                 <td>Lakewood</td>
                 <td>Seal Beach</td>
                 </tr>
               <tr>
                 <td>Lawndale</td>
                 <td>Signal Hill</td>
               </tr>
               <tr>
                 <td>Cudahy</td>
                 <td>Long Beach</td>
                 <td>South Gate</td>
               </tr>
               <tr>
                 <td>Culver City</td>
                 <td width="33%">Los Alamitos</td>
                 <td>Stanton</td>
               </tr>
               <tr>
                 <td>Cypress</td>
                 <td>Manhattan Beach</td>
                 <td>Torrance</td>
               </tr>
               <tr>
                 <td width="33%">Downey</td>
                 <td>Newport</td>
                 <td>Westminster</td>
               </tr>
               <tr>
                 <td>El Segundo</td>
                 <td>Norwalk</td>
                 </tr>
               </table>";s:6:"filter";b:0;}i:3;a:3:{s:5:"title";s:0:"";s:4:"text";s:246:"<a href=\'https://lowesinstaller.com/\' target=\'_blank\'><img src=\'http://www.vmaxplumbing.com/wordpress/wp-content/uploads/2013/05/Lowes_Certified_Installer_Logo.jpg\' /></a>
<h5 style="color:#fff;">We work with Lowe\'s Install Sales Department</h5>";s:6:"filter";b:0;}i:4;a:3:{s:5:"title";s:18:"Get Help Right Now";s:4:"text";s:30:"[CONTACT_FORM_TO_EMAIL id="1"]";s:6:"filter";b:0;}i:6;a:3:{s:5:"title";s:9:"Location:";s:4:"text";s:99:"<h4>Tel: (310)- 555-1212</h4>
<h5>1212 Century Blvd. Unit D</h5>
<h5>Los Angeles, CA 90003</h5>
";s:6:"filter";b:0;}i:7;a:3:{s:5:"title";s:0:"";s:4:"text";s:461:"	    <div class="group" id="kenshoufer-boxes">
              <a href="http://ken-shoufer.com/" id="kenshoufer-diw" class="kenshoufer-box">
              <h5>Ken Shoufer Web Design</h5>
              <p>
                  I\'m focused on building beautiful, effective and affordable websites for small businesses and professionals.
              </p>
              <br />
              <h5>>CLICK ME<</h5>
              </a>
            </div>
	</div>
";s:6:"filter";b:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'widget_rss', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'uninstall_plugins', 'a:0:{}', 'no') ; 
INSERT INTO `wp_options` VALUES (86, 'timezone_string', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'page_for_posts', '73', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'page_on_front', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (90, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'initial_db_version', '26691', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'widget_recent-posts', 'a:2:{i:2;a:3:{s:5:"title";s:12:"Latest News:";s:6:"number";i:5;s:9:"show_date";b:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (97, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (98, 'sidebars_widgets', 'a:7:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:4:{i:0;s:6:"text-6";i:1;s:18:"newsletterwidget-2";i:2;s:6:"text-2";i:3;s:6:"text-7";}s:9:"sidebar-2";a:1:{i:0;s:10:"nav_menu-2";}s:9:"sidebar-3";a:1:{i:0;s:6:"text-3";}s:9:"sidebar-4";a:1:{i:0;s:6:"text-4";}s:9:"sidebar-5";a:1:{i:0;s:14:"recent-posts-2";}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (99, 'cron', 'a:9:{i:1398828443;a:1:{s:10:"newsletter";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"newsletter";s:4:"args";a:0:{}s:8:"interval";i:300;}}}i:1398843180;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1398871381;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1398871397;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1398873825;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1398914778;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}}}i:1399087578;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}i:1399426043;a:1:{s:25:"newsletter_check_versions";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:17:"newsletter_weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (129, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1392305109;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (130, 'current_theme', 'Divi Child', 'yes') ; 
INSERT INTO `wp_options` VALUES (131, 'theme_mods_Divi', 'a:3:{i:0;b:0;s:30:"et_pb_predefined_layouts_added";s:2:"on";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1392306488;s:4:"data";a:6:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}s:9:"sidebar-4";N;s:9:"sidebar-5";N;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (132, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (133, 'shop_catalog_image_size', 'a:3:{s:5:"width";s:3:"400";s:6:"height";s:3:"400";s:4:"crop";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (134, 'shop_single_image_size', 'a:3:{s:5:"width";s:3:"510";s:6:"height";s:4:"9999";s:4:"crop";i:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (135, 'shop_thumbnail_image_size', 'a:3:{s:5:"width";s:3:"157";s:6:"height";s:3:"157";s:4:"crop";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (136, 'et_images_temp_folder', 'C:\\wamp\\www\\vmax/wp-content/uploads/et_temp', 'yes') ; 
INSERT INTO `wp_options` VALUES (137, 'et_schedule_clean_images_last_time', '1398490768', 'yes') ; 
INSERT INTO `wp_options` VALUES (138, 'et_divi', 'a:77:{s:9:"divi_logo";s:74:"http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumaxlogo1.png";s:12:"divi_favicon";s:77:"http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumaxfavicon1.png";s:15:"divi_grab_image";s:5:"false";s:15:"divi_blog_style";s:5:"false";s:22:"divi_shop_page_sidebar";s:16:"et_right_sidebar";s:22:"divi_mailchimp_api_key";s:0:"";s:31:"divi_regenerate_mailchimp_lists";s:5:"false";s:23:"divi_show_facebook_icon";s:2:"on";s:22:"divi_show_twitter_icon";s:2:"on";s:21:"divi_show_google_icon";s:2:"on";s:18:"divi_show_rss_icon";s:2:"on";s:17:"divi_facebook_url";s:1:"#";s:16:"divi_twitter_url";s:1:"#";s:15:"divi_google_url";s:1:"#";s:12:"divi_rss_url";s:0:"";s:17:"divi_catnum_posts";i:6;s:21:"divi_archivenum_posts";i:5;s:20:"divi_searchnum_posts";i:5;s:17:"divi_tagnum_posts";i:5;s:16:"divi_date_format";s:6:"M j, Y";s:16:"divi_use_excerpt";s:5:"false";s:26:"divi_responsive_shortcodes";s:2:"on";s:33:"divi_gf_enable_all_character_sets";s:5:"false";s:15:"divi_custom_css";s:0:"";s:21:"divi_enable_dropdowns";s:2:"on";s:14:"divi_home_link";s:2:"on";s:15:"divi_sort_pages";s:10:"post_title";s:15:"divi_order_page";s:3:"asc";s:22:"divi_tiers_shown_pages";i:3;s:32:"divi_enable_dropdowns_categories";s:2:"on";s:21:"divi_categories_empty";s:2:"on";s:27:"divi_tiers_shown_categories";i:3;s:13:"divi_sort_cat";s:4:"name";s:14:"divi_order_cat";s:3:"asc";s:20:"divi_disable_toptier";s:5:"false";s:14:"divi_postinfo2";a:4:{i:0;s:6:"author";i:1;s:4:"date";i:2;s:10:"categories";i:3;s:8:"comments";}s:22:"divi_show_postcomments";s:2:"on";s:15:"divi_thumbnails";s:2:"on";s:20:"divi_page_thumbnails";s:5:"false";s:23:"divi_show_pagescomments";s:5:"false";s:14:"divi_postinfo1";a:3:{i:0;s:6:"author";i:1;s:4:"date";i:2;s:10:"categories";}s:21:"divi_thumbnails_index";s:2:"on";s:19:"divi_seo_home_title";s:5:"false";s:25:"divi_seo_home_description";s:5:"false";s:22:"divi_seo_home_keywords";s:5:"false";s:23:"divi_seo_home_canonical";s:5:"false";s:23:"divi_seo_home_titletext";s:0:"";s:29:"divi_seo_home_descriptiontext";s:0:"";s:26:"divi_seo_home_keywordstext";s:0:"";s:18:"divi_seo_home_type";s:27:"BlogName | Blog description";s:22:"divi_seo_home_separate";s:3:" | ";s:21:"divi_seo_single_title";s:5:"false";s:27:"divi_seo_single_description";s:5:"false";s:24:"divi_seo_single_keywords";s:5:"false";s:25:"divi_seo_single_canonical";s:5:"false";s:27:"divi_seo_single_field_title";s:9:"seo_title";s:33:"divi_seo_single_field_description";s:15:"seo_description";s:30:"divi_seo_single_field_keywords";s:12:"seo_keywords";s:20:"divi_seo_single_type";s:21:"Post title | BlogName";s:24:"divi_seo_single_separate";s:3:" | ";s:24:"divi_seo_index_canonical";s:5:"false";s:26:"divi_seo_index_description";s:5:"false";s:19:"divi_seo_index_type";s:24:"Category name | BlogName";s:23:"divi_seo_index_separate";s:3:" | ";s:28:"divi_integrate_header_enable";s:2:"on";s:26:"divi_integrate_body_enable";s:2:"on";s:31:"divi_integrate_singletop_enable";s:2:"on";s:34:"divi_integrate_singlebottom_enable";s:2:"on";s:21:"divi_integration_head";s:0:"";s:21:"divi_integration_body";s:0:"";s:27:"divi_integration_single_top";s:0:"";s:30:"divi_integration_single_bottom";s:0:"";s:15:"divi_468_enable";s:5:"false";s:14:"divi_468_image";s:0:"";s:12:"divi_468_url";s:0:"";s:16:"divi_468_adsense";s:0:"";s:15:"divi_1_3_images";s:7:"checked";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (139, '_site_transient_et_update_themes', 'O:8:"stdClass":3:{s:7:"checked";a:5:{s:10:"Divi-Child";s:0:"";s:4:"Divi";s:3:"1.4";s:14:"twentyfourteen";s:3:"1.0";s:14:"twentythirteen";s:3:"1.1";s:12:"twentytwelve";s:3:"1.3";}s:8:"response";a:1:{s:4:"Divi";a:2:{s:11:"new_version";s:5:"1.9.1";s:3:"url";s:52:"https://www.elegantthemes.com/api/changelog/divi.txt";}}s:12:"last_checked";i:1398821233;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (140, 'theme_mods_Divi-Child', 'a:3:{i:0;b:0;s:30:"et_pb_predefined_layouts_added";s:2:"on";s:18:"nav_menu_locations";a:1:{s:12:"primary-menu";i:2;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (141, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (142, 'widget_nav_menu', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:8:"nav_menu";i:2;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (144, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (150, 'cp_cfte_last_verified', '2014-04-30 03:27:08', 'yes') ; 
INSERT INTO `wp_options` VALUES (162, 'newsletter_logger_secret', '99d86f4e', 'yes') ; 
INSERT INTO `wp_options` VALUES (163, 'newsletter_main', 'a:19:{s:12:"smtp_enabled";s:1:"0";s:11:"return_path";N;s:8:"reply_to";s:18:"kshoufer@gmail.com";s:12:"sender_email";s:18:"kshoufer@gmail.com";s:11:"sender_name";s:6:"PluMax";s:6:"editor";s:1:"0";s:13:"scheduler_max";s:3:"100";s:12:"lock_message";s:107:"This content is protected, only newsletter subscribers can access it. Subscribe now!

{subscription_form}";s:7:"api_key";s:10:"54eea69746";s:3:"css";s:0:"";s:25:"content_transfer_encoding";s:0:"";s:9:"smtp_host";s:0:"";s:9:"smtp_port";s:0:"";s:11:"smtp_secure";s:0:"";s:9:"smtp_user";s:0:"";s:9:"smtp_pass";s:0:"";s:15:"smtp_test_email";s:0:"";s:8:"lock_ids";s:0:"";s:8:"lock_url";s:0:"";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (164, 'newsletter_main_version', '1.2.1', 'yes') ; 
INSERT INTO `wp_options` VALUES (165, 'newsletter', 'a:14:{s:12:"profile_text";s:104:"{profile_form}<p>To cancel your subscription, <a href=\'{unsubscription_confirm_url}\'>click here</a>.</p>";s:10:"error_text";s:173:"<p>This subscription can\'t be completed, sorry. The email address is blocked or already subscribed. You should contact the owner to unlock that email address. Thank you.</p>";s:22:"already_confirmed_text";s:99:"<p>This email address is already subscribed, anyway a welcome email has been resent. Thank you.</p>";s:17:"subscription_text";s:19:"{subscription_form}";s:17:"confirmation_text";s:271:"<p>You have successfully subscribed to the newsletter. You\'ll
receive a confirmation email in few minutes. Please follow the
link in it to confirm your subscription. If the email takes
more than 15 minutes to appear in your mailbox, please check
your spam folder.</p>";s:20:"confirmation_subject";s:53:"Please confirm subscription - {blog_title} newsletter";s:20:"confirmation_message";s:376:"<p>Hi {name},</p>
<p>A newsletter subscription request for this email address was
received. Please confirm it by clicking here. If you cannot
click the link, please use the following link.</p>

<p>{subscription_confirm_url}</p>

<p>If you did not make this subscription request, just ignore this
message.</p>
<p>Thank you!<br>
<a href=\'{blog_url}\'>{blog_url}</a></p>";s:14:"confirmed_text";s:62:"<p>Your subscription has been confirmed! Thank you {name}!</p>";s:17:"confirmed_subject";s:22:"Welcome aboard, {name}";s:17:"confirmed_message";s:281:"<p>This message confirms your subscription to the {blog_title} newsletter.</p>
<p>Thank you!<br>
<a href=\'{blog_url}\'>{blog_url}</a></p>
<p>To unsubscribe, <a href=\'{unsubscription_url}\'>click here</a>.  To change subscriber options,
<a href=\'{profile_url}\'>click here</a>.</p>";s:19:"unsubscription_text";s:111:"<p>Please confirm that you want to unsubscribe by <a href=\'{unsubscription_confirm_url}\'>clicking here</a>.</p>";s:17:"unsubscribed_text";s:53:"<p>Your subscription has been deleted. Thank you.</p>";s:20:"unsubscribed_subject";s:15:"Goodbye, {name}";s:20:"unsubscribed_message";s:198:"<p>This message confirms that you have unsubscribed from the {blog_title} newsletter.</p>
<p>You\'re welcome to sign up again anytime.</p>
<p>Thank you!<br>
<a href=\'{blog_url}\'>{blog_url}</a></p>";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (166, 'newsletter_profile', 'a:17:{s:5:"email";s:5:"Email";s:11:"email_error";s:24:"The email is not correct";s:4:"name";s:4:"Name";s:10:"name_error";s:23:"The name is not correct";s:7:"surname";s:9:"Last name";s:13:"surname_error";s:28:"The last name is not correct";s:3:"sex";s:3:"I\'m";s:7:"privacy";s:51:"Subscribing I accept the privacy rules of this site";s:13:"privacy_error";s:37:"You must accept the privacy statement";s:9:"subscribe";s:9:"Subscribe";s:4:"save";s:4:"Save";s:12:"title_female";s:4:"Mrs.";s:10:"title_male";s:3:"Mr.";s:10:"title_none";s:4:"Dear";s:8:"sex_male";s:3:"Man";s:10:"sex_female";s:5:"Woman";s:8:"sex_none";s:4:"None";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (167, 'newsletter_subscription_version', '1.1.1', 'yes') ; 
INSERT INTO `wp_options` VALUES (168, 'newsletter_emails', 'a:12:{s:5:"theme";s:7:"default";s:11:"theme_color";s:0:"";s:12:"theme_banner";s:19:"<p>test message</p>";s:10:"theme_tags";s:0:"";s:15:"theme_max_posts";s:0:"";s:14:"theme_facebook";s:0:"";s:13:"theme_twitter";s:0:"";s:15:"theme_pinterest";s:0:"";s:16:"theme_googleplus";s:0:"";s:14:"theme_linkedin";s:0:"";s:12:"theme_tumblr";s:0:"";s:13:"theme_youtube";s:0:"";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (169, 'newsletter_emails_theme_default', 'a:11:{s:11:"theme_color";s:0:"";s:12:"theme_banner";s:19:"<p>test message</p>";s:10:"theme_tags";s:0:"";s:15:"theme_max_posts";s:0:"";s:14:"theme_facebook";s:0:"";s:13:"theme_twitter";s:0:"";s:15:"theme_pinterest";s:0:"";s:16:"theme_googleplus";s:0:"";s:14:"theme_linkedin";s:0:"";s:12:"theme_tumblr";s:0:"";s:13:"theme_youtube";s:0:"";}', 'no') ; 
INSERT INTO `wp_options` VALUES (170, 'newsletter_emails_version', '1.1.0', 'yes') ; 
INSERT INTO `wp_options` VALUES (171, 'newsletter_users', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (172, 'newsletter_users_version', '1.0.4', 'yes') ; 
INSERT INTO `wp_options` VALUES (173, 'newsletter_statistics', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (175, 'newsletter_statistics_version', '1.1.0', 'yes') ; 
INSERT INTO `wp_options` VALUES (177, 'newsletter_feed', 'a:1:{s:5:"theme";s:7:"default";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (178, 'newsletter_feed_theme_default', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (180, 'newsletter_feed_version', '1.0.0', 'yes') ; 
INSERT INTO `wp_options` VALUES (188, 'newsletter_reports_available_version', '1.0.7', 'yes') ; 
INSERT INTO `wp_options` VALUES (189, 'newsletter_feed_available_version', '1.2.2', 'yes') ; 
INSERT INTO `wp_options` VALUES (190, 'newsletter_followup_available_version', '1.1.1', 'yes') ; 
INSERT INTO `wp_options` VALUES (191, 'newsletter_facebook_available_version', '1.1.3', 'yes') ; 
INSERT INTO `wp_options` VALUES (192, 'newsletter_sendgrid_available_version', '1.1.0', 'yes') ; 
INSERT INTO `wp_options` VALUES (193, 'newsletter_popup_available_version', '1.0.5', 'yes') ; 
INSERT INTO `wp_options` VALUES (194, 'newsletter_mandrill_available_version', '1.1.0', 'yes') ; 
INSERT INTO `wp_options` VALUES (195, 'widget_newsletterwidget', 'a:2:{i:2;a:2:{s:5:"title";s:26:"Sign Up to Our Newsletter:";s:4:"text";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (199, 'newsletter_users_search', 'a:3:{s:11:"search_text";s:0:"";s:13:"search_status";s:0:"";s:11:"search_page";i:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (206, 'hmbkp_schedule_default-1', 'a:3:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:11:"max_backups";i:14;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (207, 'hmbkp_schedule_default-2', 'a:3:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (208, 'hmbkp_plugin_version', '2.6', 'yes') ; 
INSERT INTO `wp_options` VALUES (211, '_transient_timeout_hmbkp_schedule_default-1_database_filesize', '2784723662', 'no') ; 
INSERT INTO `wp_options` VALUES (212, '_transient_hmbkp_schedule_default-1_database_filesize', '868352', 'no') ; 
INSERT INTO `wp_options` VALUES (213, '_transient_timeout_hmbkp_schedule_1392318635_complete_filesize', '2784723672', 'no') ; 
INSERT INTO `wp_options` VALUES (214, '_transient_hmbkp_schedule_1392318635_complete_filesize', '23739263', 'no') ; 
INSERT INTO `wp_options` VALUES (215, 'hmbkp_schedule_1392318635', 'a:4:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:8:"manually";s:11:"max_backups";i:10;s:19:"HMBKP_Email_Service";a:1:{s:5:"email";s:0:"";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (409, '_transient_timeout_hmbkp_schedule_1392336167_complete_filesize', '2784758742', 'no') ; 
INSERT INTO `wp_options` VALUES (410, '_transient_hmbkp_schedule_1392336167_complete_filesize', '25632706', 'no') ; 
INSERT INTO `wp_options` VALUES (411, 'hmbkp_schedule_1392336167', 'a:4:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:8:"manually";s:11:"max_backups";i:10;s:19:"HMBKP_Email_Service";a:1:{s:5:"email";s:0:"";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (533, '_transient_timeout_hmbkp_schedule_1392575059_complete_filesize', '2785236532', 'no') ; 
INSERT INTO `wp_options` VALUES (534, '_transient_hmbkp_schedule_1392575059_complete_filesize', '26336084', 'no') ; 
INSERT INTO `wp_options` VALUES (535, 'hmbkp_schedule_1392575059', 'a:4:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:8:"manually";s:11:"max_backups";i:10;s:19:"HMBKP_Email_Service";a:1:{s:5:"email";s:0:"";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (941, 'hmbkp_default_path', 'C:/wamp/www/fixitall/wp-content/backupwordpress-fd6570407f-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (942, 'hmbkp_path', 'C:/wamp/www/fixitall/wp-content/backupwordpress-fd6570407f-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (981, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1398821233;s:7:"checked";a:5:{s:10:"Divi-Child";s:0:"";s:4:"Divi";s:3:"1.4";s:14:"twentyfourteen";s:3:"1.0";s:14:"twentythirteen";s:3:"1.1";s:12:"twentytwelve";s:3:"1.3";}s:8:"response";a:1:{s:4:"Divi";a:2:{s:11:"new_version";s:5:"1.9.1";s:3:"url";s:52:"https://www.elegantthemes.com/api/changelog/divi.txt";}}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1001, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1398828231;s:7:"checked";a:6:{s:19:"akismet/akismet.php";s:5:"2.6.0";s:35:"backupwordpress/backupwordpress.php";s:3:"2.6";s:39:"contact-form-to-email/form-to-email.php";s:4:"1.01";s:9:"hello.php";s:3:"1.6";s:21:"newsletter/plugin.php";s:5:"3.5.1";s:31:"wp-migrate-db/wp-migrate-db.php";s:3:"0.5";}s:8:"response";a:3:{s:19:"akismet/akismet.php";O:8:"stdClass":6:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"3.0.0";s:3:"url";s:37:"http://wordpress.org/plugins/akismet/";s:7:"package";s:55:"http://downloads.wordpress.org/plugin/akismet.3.0.0.zip";}s:35:"backupwordpress/backupwordpress.php";O:8:"stdClass":6:{s:2:"id";s:3:"885";s:4:"slug";s:15:"backupwordpress";s:6:"plugin";s:35:"backupwordpress/backupwordpress.php";s:11:"new_version";s:5:"2.6.1";s:3:"url";s:45:"http://wordpress.org/plugins/backupwordpress/";s:7:"package";s:63:"http://downloads.wordpress.org/plugin/backupwordpress.2.6.1.zip";}s:21:"newsletter/plugin.php";O:8:"stdClass":6:{s:2:"id";s:4:"8171";s:4:"slug";s:10:"newsletter";s:6:"plugin";s:21:"newsletter/plugin.php";s:11:"new_version";s:5:"3.5.4";s:3:"url";s:40:"http://wordpress.org/plugins/newsletter/";s:7:"package";s:52:"http://downloads.wordpress.org/plugin/newsletter.zip";}}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1002, 'w3tc_request_data', '', 'no') ; 
INSERT INTO `wp_options` VALUES (1042, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:18:"kshoufer@gmail.com";s:7:"version";s:5:"3.8.3";s:9:"timestamp";i:1397541463;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1048, 'db_upgraded', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (1061, 'category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1070, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:7:"upgrade";s:8:"download";s:56:"http://downloads.wordpress.org/release/wordpress-3.9.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:56:"http://downloads.wordpress.org/release/wordpress-3.9.zip";s:10:"no_content";b:0;s:11:"new_bundled";b:0;s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:3:"3.9";s:7:"version";s:3:"3.9";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1398828231;s:15:"version_checked";s:5:"3.8.1";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1073, '_site_transient_timeout_browser_cdd9bb9381c4c4ef67c3954a553de46b', '1399426033', 'yes') ; 
INSERT INTO `wp_options` VALUES (1074, '_site_transient_browser_cdd9bb9381c4c4ef67c3954a553de46b', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"34.0.1847.131";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1075, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (1076, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1398864436', 'no') ; 
INSERT INTO `wp_options` VALUES (1077, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Apr 2014 01:07:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/?v=4.0-alpha";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.9 “Smith”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/news/2014/04/smith/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/news/2014/04/smith/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 18:33:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3154";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:411:"Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist Jimmy Smith, is available for download or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love. A smoother media editing experience Improved visual editing The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:23279:"<p>Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist <a href="http://en.wikipedia.org/wiki/Jimmy_Smith_(musician)">Jimmy Smith</a>, is available <a href="http://wordpress.org/download/">for download</a> or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love.</p>
<embed src="//v0.wordpress.com/player.swf?v=1.03" type="application/x-shockwave-flash" width="640" height="360" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true" flashvars="guid=sAiXhCfV&amp;isDynamicSeeking=true" title=""></embed>
<h2 class="about-headline-callout" style="text-align: center">A smoother media editing experience</h2>
<div>
<p><img class="alignright wp-image-3168" src="//wordpress.org/news/files/2014/04/editor1-300x233.jpg" alt="editor" width="228" height="177" /></p>
<h3>Improved visual editing</h3>
<p>The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the visual editor from your word processor without wasting time to clean up messy styling. (Yeah, we’re talking about you, Microsoft Word.)</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3170" src="//wordpress.org/news/files/2014/04/image1-300x233.jpg" alt="image" width="228" height="178" /></p>
<h3>Edit images easily</h3>
<p>With quicker access to crop and rotation tools, it’s now much easier to edit your images while editing posts. You can also scale images directly in the editor to find just the right fit.</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3187" src="//wordpress.org/news/files/2014/04/dragdrop1-300x233.jpg" alt="dragdrop" width="228" height="178" /></p>
<h3>Drag and drop your images</h3>
<p>Uploading your images is easier than ever. Just grab them from your desktop and drop them in the editor.</p>
</div>
<div style="clear: both"></div>
<hr />
<h2 style="text-align: center">Gallery previews</h2>
<p><img class="aligncenter size-full wp-image-3169" src="//wordpress.org/news/files/2014/04/gallery1.jpg" alt="gallery" width="980" height="550" /></p>
<p>Galleries display a beautiful grid of images right in the editor, just like they do in your published post.</p>
<hr />
<h2 style="text-align: center">Do more with audio and video</h2>

<a href=\'http://wordpress.org/news/files/2014/04/AintMisbehavin.mp3\'>Ain\'t Misbehavin\'</a>
<a href=\'http://wordpress.org/news/files/2014/04/DavenportBlues.mp3\'>Davenport Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/JellyRollMorton-BuddyBoldensBlues.mp3\'>Buddy Bolden\'s Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/Johnny_Hodges_Orchestra-Squaty_Roo-1941.mp3\'>Squaty Roo</a>
<a href=\'http://wordpress.org/news/files/2014/04/Louisiana_Five-Dixie_Blues-1919.mp3\'>Dixie Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/WolverineBlues.mp3\'>Wolverine Blues</a>

<p>Images have galleries; now we’ve added simple audio and video playlists, so you can showcase your music and clips.</p>
<hr />
<h2 style="text-align: center">Live widget and header previews</h2>
<div style="width: 692px; max-width: 100%;" class="wp-video"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<video class="wp-video-shortcode" id="video-3154-1" width="692" height="448" preload="metadata" controls="controls"><source type="video/mp4" src="//wordpress.org/news/files/2014/04/widgets.mp4?_=1" /><a href="//wordpress.org/news/files/2014/04/widgets.mp4">//wordpress.org/news/files/2014/04/widgets.mp4</a></video></div>
<p>Add, edit, and rearrange your site’s widgets right in the theme customizer. No “save and surprise” — preview your changes live and only save them when you’re ready.</p>
<p>The improved header image tool also lets you upload, crop, and manage headers while customizing your theme.</p>
<hr />
<h2 style="text-align: center">Stunning new theme browser</h2>
<p><img class="aligncenter size-full wp-image-3172" src="//wordpress.org/news/files/2014/04/theme1.jpg" alt="theme" width="1003" height="558" /><br />
Looking for a new theme should be easy and fun. Lose yourself in the boundless supply of free WordPress.org themes with the beautiful new theme browser.</p>
<hr />
<h2 style="text-align: center">The Crew</h2>
<p>This release was led by <a href="http://nacin.com/">Andrew Nacin</a> and <a href="http://www.getsource.net/">Mike Schroder</a>, with the help of these fine individuals. There are 267 contributors with props in this release, a new high:</p>
<p><a href="http://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/kawauso">Adam Harley</a>, <a href="http://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="http://profiles.wordpress.org/adelval">adelval</a>, <a href="http://profiles.wordpress.org/ajay">Ajay</a>, <a href="http://profiles.wordpress.org/akeda">Akeda Bagus</a>, <a href="http://profiles.wordpress.org/xknown">Alex Concha</a>, <a href="http://profiles.wordpress.org/aliso">Alison Barrett</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/norcross">Andrew Norcross</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/rarst">Andrey "Rarst" Savchenko</a>, <a href="http://profiles.wordpress.org/andykeith">Andy Keith</a>, <a href="http://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="http://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/barry">Barry</a>, <a href="http://profiles.wordpress.org/toszcze">Bartosz Romanowski</a>, <a href="http://profiles.wordpress.org/bassgang">bassgang</a>, <a href="http://profiles.wordpress.org/bcworkz">bcworkz</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/neoxx">Bernhard Riedl</a>, <a href="http://profiles.wordpress.org/bigdawggi">bigdawggi</a>, <a href="http://profiles.wordpress.org/bobbravo2">Bob Gregor</a>, <a href="http://profiles.wordpress.org/bobbingwide">bobbingwide</a>, <a href="http://profiles.wordpress.org/bradt">Brad Touesnard</a>, <a href="http://profiles.wordpress.org/bradparbs">bradparbs</a>, <a href="http://profiles.wordpress.org/bramd">bramd</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/brasofilo">brasofilo</a>, <a href="http://profiles.wordpress.org/bravokeyl">bravokeyl</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/cgaffga">cgaffga</a>, <a href="http://profiles.wordpress.org/chiragswadia">Chirag Swadia</a>, <a href="http://profiles.wordpress.org/chouby">Chouby</a>, <a href="http://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="http://profiles.wordpress.org/cmmarslender">Chris Marslender</a>, <a href="http://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="http://profiles.wordpress.org/chrisscott">Chris Scott</a>, <a href="http://profiles.wordpress.org/chriseverson">chriseverson</a>, <a href="http://profiles.wordpress.org/chrisguitarguy">chrisguitarguy</a>, <a href="http://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="http://profiles.wordpress.org/ciantic">ciantic</a>, <a href="http://profiles.wordpress.org/antorome">Comparativa de Bancos</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/corvannoorloos">Cor van Noorloos</a>, <a href="http://profiles.wordpress.org/corphi">Corphi</a>, <a href="http://profiles.wordpress.org/cramdesign">cramdesign</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="http://profiles.wordpress.org/dannydehaan">Danny de Haan</a>, <a href="http://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/eightface">Dave Kellam (eightface)</a>, <a href="http://profiles.wordpress.org/dpe415">DaveE</a>, <a href="http://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="http://profiles.wordpress.org/davidanderson">David Anderson</a>, <a href="http://profiles.wordpress.org/davidmarichal">David Marichal</a>, <a href="http://profiles.wordpress.org/denis-de-bernardy">Denis de Bernardy</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/dougwollison">Doug Wollison</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="http://profiles.wordpress.org/drprotocols">DrProtocols</a>, <a href="http://profiles.wordpress.org/dustyf">Dustin Filippini</a>, <a href="http://profiles.wordpress.org/eatingrules">eatingrules</a>, <a href="http://profiles.wordpress.org/plocha">edik</a>, <a href="http://profiles.wordpress.org/eliorivero">Elio Rivero</a>, <a href="http://profiles.wordpress.org/enej">enej</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/evarlese">Erica Varlese</a>, <a href="http://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="http://profiles.wordpress.org/ejdanderson">Evan Anderson</a>, <a href="http://profiles.wordpress.org/fahmiadib">Fahmi Adib</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="http://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/genkisan">genkisan</a>, <a href="http://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/grahamarmfield">Graham Armfield</a>, <a href="http://profiles.wordpress.org/vancoder">Grant Mangham</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/tivnet">Gregory Karpinsky</a>, <a href="http://profiles.wordpress.org/hakre">hakre</a>, <a href="http://profiles.wordpress.org/hanni">hanni</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandí</a>, <a href="http://profiles.wordpress.org/ippetkov">ippetkov</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="http://profiles.wordpress.org/jackreichert">Jack Reichert</a>, <a href="http://profiles.wordpress.org/_jameslee">jameslee</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/jaycc">JayCC</a>, <a href="http://profiles.wordpress.org/jeffsebring">Jeff Sebring</a>, <a href="http://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jesin">Jesin A</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="http://profiles.wordpress.org/jnielsendotnet">jnielsendotnet</a>, <a href="http://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/johnpbloch">John P. Bloch</a>, <a href="http://profiles.wordpress.org/johnregan3">John Regan</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="http://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="http://profiles.wordpress.org/shelob9">Josh Pollock</a>, <a href="http://profiles.wordpress.org/joshuaabenazer">Joshua Abenazer</a>, <a href="http://profiles.wordpress.org/jstraitiff">jstraitiff</a>, <a href="http://profiles.wordpress.org/juliobox">Julio Potier</a>, <a href="http://profiles.wordpress.org/kopepasah">Justin Kopepasah</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/kasparsd">Kaspars</a>, <a href="http://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="http://profiles.wordpress.org/kerikae">kerikae</a>, <a href="http://profiles.wordpress.org/kworthington">Kevin Worthington</a>, <a href="http://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="http://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="http://profiles.wordpress.org/kitchin">kitchin</a>, <a href="http://profiles.wordpress.org/klihelp">klihelp</a>, <a href="http://profiles.wordpress.org/knutsp">Knut Sparhell</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/drozdz">Krzysiek Drozdz</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="http://profiles.wordpress.org/lkwdwrd">lkwdwrd</a>, <a href="http://profiles.wordpress.org/lpointet">lpointet</a>, <a href="http://profiles.wordpress.org/ldebrouwer">Luc De Brouwer</a>, <a href="http://profiles.wordpress.org/spmlucas">Lucas Karpiuk</a>, <a href="http://profiles.wordpress.org/mark8barnes">Mark Barnes</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/marventus">Marventus</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt (Thomas) Miklic</a>, <a href="http://profiles.wordpress.org/mjbanks">Matt Banks</a>, <a href="http://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="http://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="http://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/mattonomics">mattonomics</a>, <a href="http://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="http://profiles.wordpress.org/matveb">Matías Ventura</a>, <a href="http://profiles.wordpress.org/maxcutler">Max Cutler</a>, <a href="http://profiles.wordpress.org/mcadwell">mcadwell</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/meloniq">meloniq</a>, <a href="http://profiles.wordpress.org/michael-arestad">Michael Arestad</a>, <a href="http://profiles.wordpress.org/michelwppi">Michel - xiligroup dev</a>, <a href="http://profiles.wordpress.org/mcsf">Miguel Fonseca</a>, <a href="http://profiles.wordpress.org/gradyetc">Mike Burns</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikemanger">Mike Manger</a>, <a href="http://profiles.wordpress.org/mikeschinkel">Mike Schinkel</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/mikecorkum">mikecorkum</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/mor10">Morten Rand-Hendriksen</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="http://profiles.wordpress.org/nendeb55">nendeb55</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/nicolealleyinteractivecom">Nicole Arnold</a>, <a href="http://profiles.wordpress.org/nikv">Nikhil Vimal (NikV)</a>, <a href="http://profiles.wordpress.org/nivijah">nivijah</a>, <a href="http://profiles.wordpress.org/nofearinc">nofearinc</a>, <a href="http://profiles.wordpress.org/nunomorgadinho">Nuno Morgadinho</a>, <a href="http://profiles.wordpress.org/olivm">olivM</a>, <a href="http://profiles.wordpress.org/jbkkd">Omer Korner</a>, <a href="http://profiles.wordpress.org/originalexe">OriginalEXE</a>, <a href="http://profiles.wordpress.org/oso96_2000">oso96_2000</a>, <a href="http://profiles.wordpress.org/patricknami">patricknami</a>, <a href="http://profiles.wordpress.org/pbearne">Paul Bearne</a>, <a href="http://profiles.wordpress.org/djpaul">Paul Gibbs</a>, <a href="http://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="http://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="http://profiles.wordpress.org/nprasath002">Prasath Nadarajah</a>, <a href="http://profiles.wordpress.org/prettyboymp">prettyboymp</a>, <a href="http://profiles.wordpress.org/raamdev">Raam Dev</a>, <a href="http://profiles.wordpress.org/rachelbaker">rachelbaker</a>, <a href="http://profiles.wordpress.org/mauryaratan">Ram Ratan Maurya</a>, <a href="http://profiles.wordpress.org/ramonchiara">ramonchiara</a>, <a href="http://profiles.wordpress.org/ounziw">Rescuework Support</a>, <a href="http://profiles.wordpress.org/rhyswynne">Rhys Wynne</a>, <a href="http://profiles.wordpress.org/ricardocorreia">Ricardo Correia</a>, <a href="http://profiles.wordpress.org/theorboman">Richard Sweeney</a>, <a href="http://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="http://profiles.wordpress.org/richard2222">richard2222</a>, <a href="http://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="http://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="http://profiles.wordpress.org/robmiller">robmiller</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/romaimperator">romaimperator</a>, <a href="http://profiles.wordpress.org/roothorick">roothorick</a>, <a href="http://profiles.wordpress.org/ruudjoyo">ruud@joyo</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="http://profiles.wordpress.org/salcode">Sal Ferrarello</a>, <a href="http://profiles.wordpress.org/otto42">Samuel Wood (Otto)</a>, <a href="http://profiles.wordpress.org/sandyr">Sandeep</a>, <a href="http://profiles.wordpress.org/scottlee">Scott Lee</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/greglone">ScreenfeedFr</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/sdasse">sdasse</a>, <a href="http://profiles.wordpress.org/bootsz">Sean Butze</a>, <a href="http://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="http://profiles.wordpress.org/nessworthy">Sean Nessworthy</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/shahpranaf">shahpranaf</a>, <a href="http://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="http://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="http://profiles.wordpress.org/pross">Simon Prosser</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="http://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/sonjanyc">sonjanyc</a>, <a href="http://profiles.wordpress.org/spencerfinnell">Spencer Finnell</a>, <a href="http://profiles.wordpress.org/piontkowski">Spencer Piontkowski</a>, <a href="http://profiles.wordpress.org/stephcook22">stephcook22</a>, <a href="http://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="http://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="http://profiles.wordpress.org/sbruner">Steve Bruner</a>, <a href="http://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="http://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="http://profiles.wordpress.org/tanner-m">Tanner Moushey</a>, <a href="http://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="http://profiles.wordpress.org/tbrams">tbrams</a>, <a href="http://profiles.wordpress.org/tellyworth">tellyworth</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tomauger">Tom Auger</a>, <a href="http://profiles.wordpress.org/willmot">Tom Willmot</a>, <a href="http://profiles.wordpress.org/topher1kenobe">Topher</a>, <a href="http://profiles.wordpress.org/topquarky">topquarky</a>, <a href="http://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>, <a href="http://profiles.wordpress.org/toru">Toru</a>, <a href="http://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="http://profiles.wordpress.org/umeshsingla">Umesh Kumar</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, <a href="http://profiles.wordpress.org/varunagw">VarunAgw</a>, <a href="http://profiles.wordpress.org/wawco">wawco</a>, <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="http://profiles.wordpress.org/wokamoto">wokamoto</a>, <a href="http://profiles.wordpress.org/xsonic">xsonic</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>, <a href="http://profiles.wordpress.org/zbtirrell">Zach Tirrell</a>, and <a href="http://profiles.wordpress.org/vanillalounge">Ze Fontainhas</a>. Also thanks to <a href="http://michaelpick.wordpress.com/">Michael Pick</a> for producing the release video.</p>
<p>If you want to follow along or help out, check out <a href="http://make.wordpress.org/">Make WordPress</a> and our <a href="http://make.wordpress.org/core/">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.0!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2014/04/smith/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.9 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Apr 2014 09:47:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3151";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:356:"The second release candidate for WordPress 3.9 is now available for testing. If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the first release candidate, and those changes are all helpfully summarized in our weekly post on the development blog. Probably the biggest fixes are to live [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2328:"<p>The second release candidate for WordPress 3.9 is now available for testing.</p>
<p>If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the <a title="WordPress 3.9 Release Candidate" href="http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/">first release candidate</a>, and those changes are all helpfully summarized <a href="http://make.wordpress.org/core/?p=10237">in our weekly post</a> on the development blog. Probably the biggest fixes are to live widget previews and the new theme browser, along with some extra TinyMCE compatibility and some RTL fixes.</p>
<p><strong>Plugin authors:</strong> Could you test your plugins against 3.9, and if they&#8217;re compatible, make sure they are marked as tested up to 3.9? It only takes a few minutes and this really helps make launch easier. Be sure to follow along the core development blog; we&#8217;ve been posting <a href="http://make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example: <a href="http://make.wordpress.org/core/2014/04/15/html5-galleries-captions-in-wordpress-3-9/">HTML5</a>, <a href="http://make.wordpress.org/core/2014/04/14/symlinked-plugins-in-wordpress-3-9/">symlinks</a>, <a href="http://make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">MySQL</a>, <a href="http://make.wordpress.org/core/2014/04/11/plupload-2-x-in-wordpress-3-9/">Plupload</a>.)</p>
<p>To test WordPress 3.9 RC2, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-RC2.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the nearly complete About screen in your dashboard (<strong><img src="http://i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and also check out <a title="WordPress 3.9 Beta 1" href="http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><em>This is for testing,</em><br />
<em>so not recommended for<br />
production sites—yet.</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.8.3 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/04/wordpress-3-8-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/04/wordpress-3-8-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Apr 2014 19:29:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3145";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"WordPress 3.8.3 is now available to fix a small but unfortunate bug in the WordPress 3.8.2 security release. The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2339:"<p>WordPress 3.8.3 is now available to fix a small but unfortunate bug in the <a title="WordPress 3.8.2 Security Release" href="http://wordpress.org/news/2014/04/wordpress-3-8-2/">WordPress 3.8.2 security release</a>.</p>
<p>The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using this tool, <em>any</em> loss of content is unacceptable to us.</p>
<p>We recognize how much trust you place in us to safeguard your content, and we take this responsibility very seriously. We&#8217;re sorry we let you down.</p>
<p>We&#8217;ve all lost words we&#8217;ve written before, like an email thanks to a cat on the keyboard or a term paper to a blue screen of death. Over the last few WordPress releases, we&#8217;ve made a number of improvements to features like autosaves and revisions. With revisions, an old edit can always be restored. We&#8217;re trying our hardest to save your content somewhere even if your power goes out or your browser crashes. We even monitor your internet connection and prevent you from hitting that &#8220;Publish&#8221; button at the exact moment the coffee shop Wi-Fi has a hiccup.</p>
<p>It&#8217;s <em>possible</em> that the quick draft you lost last week is still in the database, and just hidden from view. As an added complication, these &#8220;discarded drafts&#8221; normally get deleted after seven days, and it&#8217;s already been six days since the release. If we were able to rescue your draft, you&#8217;ll see it on the &#8220;All Posts&#8221; screen after you update to 3.8.3. (We&#8217;ll also be pushing 3.8.3 out as a background update, so you may just see a draft appear.)</p>
<p>So, if you tried to jot down a quick idea last week, I hope WordPress has recovered it for you. Maybe it&#8217;ll turn into that novella.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.3</a> or click &#8220;Update Now&#8221; on Dashboard → Updates.</p>
<p><em>This affected version 3.7.2 as well, so we&#8217;re pushing a 3.7.3 to these installs, but we&#8217;d encourage you to update to the latest and greatest.</em></p>
<hr />
<p><em>Now for some good news:<br />
WordPress 3.9 is near.<br />
Expect it this week</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/04/wordpress-3-8-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 3.9 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Apr 2014 21:05:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3129";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"As teased earlier, the first release candidate for WordPress 3.9 is now available for testing! We hope to ship WordPress 3.9 next week, but we need your help to get there. If you haven’t tested 3.9 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.) To test WordPress 3.9 [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3022:"<p><a href="http://wordpress.org/news/2014/04/wordpress-3-8-2/">As teased earlier</a>, the first release candidate for WordPress 3.9 is now available for testing!</p>
<p>We hope to ship WordPress 3.9 <em>next week</em>, but we need your help to get there. If you haven’t tested 3.9 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.)</p>
<p>To test WordPress 3.9 RC1, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-RC1.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the work-in-progress About screen in your dashboard (<strong><img src="http://i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and check out <a title="WordPress 3.9 Beta 1" href="http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><strong>Think you’ve found a bug? </strong>Please post to the <a href="http://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>. If any known issues come up, you’ll be able to <a href="http://core.trac.wordpress.org/report/5">find them here</a>.</p>
<p><strong>If you&#8217;re a plugin author</strong>, there are two important changes in particular to be aware of:</p>
<ul>
<li>TinyMCE received a major update, to version 4.0. Any editor plugins written for TinyMCE 3.x might require some updates. (If things broke, we&#8217;d like to hear about them so we can make adjustments.) For more, see TinyMCE&#8217;s <a href="http://www.tinymce.com/wiki.php/Tutorial:Migration_guide_from_3.x">migration guide</a> and <a href="http://www.tinymce.com/wiki.php/api4:index">API documentation</a>, and the notes on the <a href="http://make.wordpress.org/core/2014/01/18/tinymce-4-0-is-in-core/">core development blog</a>.</li>
<li>WordPress 3.9 now uses the MySQLi Improved extension for sites running PHP 5.5. Any plugins that made direct calls to <code>mysql_*</code> functions will experience some problems on these sites. For more information, see the notes on the <a href="http://make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">core development blog</a>.</li>
</ul>
<p>Be sure to follow along the core development blog, where we will be continuing to post <a href="http://make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example, read <a href="http://make.wordpress.org/core/2014/03/27/masonry-in-wordpress-3-9/">this</a> if you are using Masonry in your theme.) And please, please update your plugin&#8217;s <em>Tested up to</em> version in the readme to 3.9 before April 16.</p>
<p><em>Release candidate<br />
This haiku&#8217;s the easy one<br />
3.9 is near</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"WordPress 3.8.2 Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/04/wordpress-3-8-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/04/wordpress-3-8-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Apr 2014 19:04:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3124";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:355:"WordPress 3.8.2 is now available. This is an important security release for all previous versions and we strongly encourage you to update your sites immediately. This releases fixes a weakness that could let an attacker force their way into your site by forging authentication cookies. This was discovered and fixed by Jon Cave of the WordPress [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2272:"<p>WordPress 3.8.2 is now available. This is an important security release for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>This releases fixes a weakness that could let an attacker force their way into your site by forging authentication cookies. This was discovered and fixed by <a href="http://joncave.co.uk/">Jon Cave</a> of the WordPress security team.</p>
<p>It also contains a fix to prevent a user with the Contributor role from improperly publishing posts. Reported by <a href="http://edik.ch/">edik</a>.</p>
<p>This release also fixes nine bugs and contains three other security hardening changes:</p>
<ul>
<li>Pass along additional information when processing pingbacks to help hosts identify potentially abusive requests.</li>
<li>Fix a low-impact SQL injection by trusted users. Reported by <a href="http://www.dxw.com/">Tom Adams</a> of dxw.</li>
<li>Prevent possible cross-domain scripting through Plupload, the third-party library WordPress uses for uploading files. Reported by <a href="http://szgru.website.pl/">Szymon Gruszecki</a>.</li>
</ul>
<p>We appreciated <a href="http://codex.wordpress.org/FAQ_Security">responsible disclosure</a> of these security issues directly to our security team. For more information on all of the changes, see the <a href="http://codex.wordpress.org/Version_3.8.2">release notes</a> or consult <a href="https://core.trac.wordpress.org/log/branches/3.8?rev=28057&amp;stop_rev=27024">the list of changes</a>.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.2</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Sites that support automatic background updates will be updated to WordPress 3.8.2 within 12 hours. If you are still on WordPress 3.7.1, you will be updated to 3.7.2, which contains the same security fixes as 3.8.2. We don&#8217;t support older versions, so please update to 3.8.2 for the latest and greatest.</p>
<p>Already testing WordPress 3.9? The first release candidate is <a href="https://wordpress.org/wordpress-3.9-RC1.zip">now available</a> (zip) and it contains these security fixes. Look for a full announcement later today; we expect to release 3.9 next week.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/04/wordpress-3-8-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 29 Mar 2014 13:15:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3106";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:373:"The third (and maybe last) beta of WordPress 3.9 is now available for download. Beta 3 includes more than 200 changes, including: New features like live widget previews and the new theme installer are now more ready for prime time, so check &#8216;em out. UI refinements when editing images and when working with media in the editor. We&#8217;ve also brought [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2668:"<p>The third (and maybe last) beta of WordPress 3.9 is now available for download.</p>
<p>Beta 3 includes more than 200 <a href="https://core.trac.wordpress.org/log?rev=27850&amp;stop_rev=27639&amp;limit=300">changes</a>, including:</p>
<ul>
<li>New features like live widget previews and the new theme installer are now more ready for prime time, so check &#8216;em out.</li>
<li>UI refinements when editing images and when working with media in the editor. We&#8217;ve also brought back some of the advanced display settings for images.</li>
<li>If you want to test out audio and video playlists, the links will appear in the media manager once you&#8217;ve uploaded an audio or video file.</li>
<li>For theme developers, we&#8217;ve added HTML5 caption support (<a class="reopened ticket" title="task (blessed): HTML5 captions (reopened)" href="https://core.trac.wordpress.org/ticket/26642">#26642</a>) to match the new gallery support (<a class="closed ticket" title="enhancement: HTML5 Galleries (closed: fixed)" href="https://core.trac.wordpress.org/ticket/26697">#26697</a>).</li>
<li>The formatting function that turns straight quotes into smart quotes (among other things) underwent some changes to drastically speed it up, so let us know if you see anything weird.</li>
</ul>
<p><strong>We need your help</strong>. We&#8217;re still aiming for an April release, which means the next week will be critical for identifying and squashing bugs. If you&#8217;re just joining us, please see <a href="https://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 announcement post</a> for what to look out for.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums, where friendly moderators are standing by. <b>Plugin developers</b><strong>,</strong> if you haven&#8217;t tested WordPress 3.9 yet, now is the time — and be sure to update the &#8220;tested up to&#8221; version for your plugins so they&#8217;re listed as compatible with 3.9.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta3.zip">download the beta here</a> (zip).</p>
<p><em>WordPress 3.9<br />
Let&#8217;s make the date official<br />
It&#8217;s April 16</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Mar 2014 05:01:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3101";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:309:"WordPress 3.9 Beta 2 is now available for testing! We&#8217;ve made more than a hundred changes since Beta 1, but we still need your help if we&#8217;re going to hit our goal of an April release. For what to look out for, please head on over to the Beta 1 announcement post. Some of the changes in [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1901:"<p>WordPress 3.9 Beta 2 is now available for testing!</p>
<p>We&#8217;ve made more than a hundred <a href="https://core.trac.wordpress.org/log?rev=27639&amp;stop_rev=27500&amp;limit=200">changes</a> since Beta 1, but we still need your help if we&#8217;re going to hit our goal of an April release. For what to look out for, please head on over to <a href="https://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 announcement post</a>. Some of the changes in Beta 2 include:</p>
<ul>
<li>Rendering of embedded audio and video players directly in the visual editor.</li>
<li>Visual and functional improvements to the editor, the media manager, and theme installer.</li>
<li>Various bug fixes to TinyMCE, the software behind the visual editor.</li>
<li>Lots of fixes to widget management in the theme customizer.</li>
</ul>
<p>As always,<strong> if you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.9">everything we’ve fixed</a> so far.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta2.zip">download the beta here</a> (zip).</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 11 Mar 2014 13:42:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3083";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:329:"I&#8217;m excited to announce that the first beta of WordPress 3.9 is now available for testing. WordPress 3.9 is due out next month &#8212; but in order to hit that goal, we need your help testing all of the goodies we&#8217;ve added: We updated TinyMCE, the software powering the visual editor, to the latest version. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:6065:"<p>I&#8217;m excited to announce that the <strong>first beta of WordPress 3.9</strong> is now available for testing.</p>
<p>WordPress 3.9 is due out next month &#8212; but in order to hit that goal, <strong>we need your help</strong> testing all of the goodies we&#8217;ve added:</p>
<ul>
<li>We updated TinyMCE, the software powering the visual editor, to the latest version. Be on the lookout for cleaner markup. Also try the new paste handling &#8212; if you paste in a block of text from Microsoft Word, for example, it will no longer come out terrible. (The &#8220;Paste from Word&#8221; button you probably never noticed has been removed.) It&#8217;s possible some plugins that added stuff to the visual editor (like a new toolbar button) no longer work, so we&#8217;d like to hear about them (<a href="https://core.trac.wordpress.org/ticket/24067">#24067</a>). (And be sure to <a href="http://wordpress.org/support/">open a support thread</a> for the plugin author.)</li>
<li>We&#8217;ve added <strong>widget management to live previews</strong> (the customizer). Please test editing, adding, and rearranging widgets! (<a href="https://core.trac.wordpress.org/ticket/27112">#27112</a>) We&#8217;ve also added the ability to upload, crop, and manage header images, without needing to leave the preview. (<a href="https://core.trac.wordpress.org/ticket/21785">#21785</a>)</li>
<li>We brought 3.8&#8242;s beautiful new theme browsing experience to the <strong>theme installer</strong>. Check it out! (<a title="View ticket" href="https://core.trac.wordpress.org/ticket/27055">#27055</a>)</li>
<li><strong>Galleries</strong> now receive a live preview in the editor. Upload some photos and insert a gallery to see this in action. (<a href="https://core.trac.wordpress.org/ticket/26959">#26959</a>)</li>
<li>You can now <strong>drag-and-drop</strong> images directly onto the editor to upload them. It can be a bit finicky, so try it and help us work out the kinks. (<a href="https://core.trac.wordpress.org/ticket/19845">#19845</a>)</li>
<li>Some things got improved around <strong>editing images</strong>. It&#8217;s a lot easier to make changes to an image after you insert it into a post (<a class="closed" title="View ticket" href="https://core.trac.wordpress.org/ticket/24409">#24409</a>) and you no longer get kicked to a new window when you need to crop or rotate an image (<a href="https://core.trac.wordpress.org/ticket/21811">#21811</a>).</li>
<li>New <strong>audio/video playlists</strong>. Upload a few audio or video files to test these. (<a href="https://core.trac.wordpress.org/ticket/26631">#26631</a>)</li>
</ul>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We&#8217;d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.9">everything we’ve fixed</a> so far.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta1.zip">download the beta here</a> (zip).</p>
<hr />
<p><strong>DEVELOPERS!</strong> Hello! There&#8217;s lots for you, too.</p>
<p><strong>Please test your plugins and themes!</strong> There&#8217;s a lot of great stuff under the hood in 3.9 and we hope to blog a bit about them in the coming days. If you haven&#8217;t been reading the awesome <a href="http://make.wordpress.org/core/tag/week-in-core/">weekly summaries</a> on the <a href="http://make.wordpress.org/core/">main core development blog</a>, that&#8217;s a great place to start. (You should definitely follow that blog.) For now, here are some things to watch out for when testing:</p>
<ul>
<li>The <strong>load process in multisite</strong> got rewritten. If you notice any issues with your network, see <a href="https://core.trac.wordpress.org/ticket/27003">#27003</a>.</li>
<li>We now use the <strong>MySQL Improved (mysqli) database extension</strong> if you&#8217;re running a recent version of PHP (<a href="https://core.trac.wordpress.org/ticket/21663">#21663</a>). Please test your plugins and see that everything works well, and please make sure you&#8217;re not calling <code>mysql_*</code> functions directly.</li>
<li><strong>Autosave</strong> was refactored, so if you see any issues related to autosaving, heartbeat, etc., let us know (<a href="https://core.trac.wordpress.org/ticket/25272">#25272</a>).</li>
<li>Library updates, in particular Backbone 1.1 and Underscore 1.6 (<a href="https://core.trac.wordpress.org/ticket/26799">#26799</a>). Also Masonry 3 (<a href="https://core.trac.wordpress.org/ticket/25351">#25351</a>), PHPMailer (<a href="https://core.trac.wordpress.org/ticket/25560">#25560</a>), Plupload (<a href="https://core.trac.wordpress.org/ticket/25663">#25663</a>), and TinyMCE (<a href="https://core.trac.wordpress.org/ticket/24067">#24067</a>).</li>
<li>TinyMCE 4.0 is a <em>major</em> update. Please see TinyMCE&#8217;s <a href="http://www.tinymce.com/wiki.php/Tutorial:Migration_guide_from_3.x">upgrade guide</a> and our <a href="https://core.trac.wordpress.org/ticket/24067">implementation ticket</a> for more. If you have any questions or problems, please <a href="http://wordpress.org/support/forum/alphabeta">open a thread in the support forums</a>.</li>
</ul>
<p>Happy testing!</p>
<p><em><em>Lots of improvements<br />
Little things go a long way</em><br />
Please test beta one<br />
</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.8.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/01/wordpress-3-8-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/01/wordpress-3-8-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jan 2014 20:37:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3063";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:358:"After six weeks and more than 9.3 million downloads of WordPress 3.8, we&#8217;re pleased to announce WordPress 3.8.1 is now available. Version 3.8.1 is a maintenance releases that addresses 31 bugs in 3.8, including various fixes and improvements for the new dashboard design and new themes admin screen. An issue with taxonomy queries in WP_Query [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3809:"<p>After six weeks and more than <a href="http://wordpress.org/download/counter/">9.3 million downloads</a> of WordPress 3.8, we&#8217;re pleased to announce WordPress 3.8.1 is now available.</p>
<p>Version 3.8.1 is a maintenance releases that addresses 31 bugs in 3.8, including various fixes and improvements for the new dashboard design and new themes admin screen. An issue with taxonomy queries in WP_Query was resolved. And if you&#8217;ve been frustrated by submit buttons that won&#8217;t do anything when you click on them (or thought you were going crazy, like some of us), we&#8217;ve found and fixed this &#8220;dead zone&#8221; on submit buttons.</p>
<p>It also contains a fix for <strong>embedding tweets</strong> (by placing the URL to the tweet on its own line), which was broken due to a recent Twitter API change. (For more on Embeds, see <a href="http://codex.wordpress.org/Embeds">the Codex</a>.)</p>
<p>For a full list of changes, consult the <a href="http://core.trac.wordpress.org/query?milestone=3.8.1">list of tickets</a> and <a href="https://core.trac.wordpress.org/log/branches/3.8?rev=27018&amp;stop_rev=26862">the changelog</a>. There&#8217;s also a <a href="http://make.wordpress.org/core/2014/01/22/wordpress-3-8-1-release-candidate/">detailed summary</a> for developers on the development blog.</p>
<p>If you are one of the millions already running WordPress 3.8, we will start rolling out automatic background updates for WordPress 3.8.1 in the next few hours. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Thanks to all of these fine individuals for contributing to 3.8.1:</p>
<p><a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="#">José Pino</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/matveb">Matias Ventura</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt Thomas</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/nivijah">nivijah</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, and <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>.</p>
<p><em>WordPress three eight one<br />
We heard you didn&#8217;t like bugs<br />
So we took them out</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/01/wordpress-3-8-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"WordPress 3.8 “Parker”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://wordpress.org/news/2013/12/parker/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2013/12/parker/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 12 Dec 2013 17:00:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2765";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:354:"Version 3.8 of WordPress, named “Parker” in honor of Charlie Parker, bebop innovator, is available for download or update in your WordPress dashboard. We hope you&#8217;ll think this is the most beautiful update yet. Introducing a modern new design WordPress has gotten a facelift. 3.8 brings a fresh new look to the entire admin dashboard. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:19098:"<p>Version 3.8 of WordPress, named “Parker” in honor of <a href="http://en.wikipedia.org/wiki/Charlie_Parker">Charlie Parker</a>, bebop innovator, is available <a href="http://wordpress.org/download/">for download</a> or update in your WordPress dashboard. We hope you&#8217;ll think this is the most beautiful update yet.</p>
<div id="v-6wORgoGb-1" class="video-player"><embed id="v-6wORgoGb-1-video" src="http://s0.videopress.com/player.swf?v=1.03&amp;guid=6wORgoGb&amp;isDynamicSeeking=true" type="application/x-shockwave-flash" width="692" height="388" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true"></embed></div>
<h2 class="aligncenter">Introducing a modern new design</h2>
<p><img class="wp-image-2951 aligncenter" alt="overview" src="http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/overview.jpg?resize=623%2C193" data-recalc-dims="1" /></p>
<p>WordPress has gotten a facelift. 3.8 brings a fresh new look to the entire admin dashboard. Gone are overbearing gradients and dozens of shades of grey — bring on a bigger, bolder, more colorful design!</p>
<p><img class="aligncenter  wp-image-2856" style="margin-left: 0;margin-right: 0" alt="about-modern-wordpress" src="http://i2.wp.com/wpdotorg.files.wordpress.com/2013/12/design.png?resize=623%2C151" data-recalc-dims="1" /></p>
<h3>Modern aesthetic</h3>
<p>The new WordPress dashboard has a fresh, uncluttered design that embraces clarity and simplicity.</p>
<h3>Clean typography</h3>
<p>The Open Sans typeface provides simple, friendly text that is optimized for both desktop and mobile viewing. It’s even open source, just like WordPress.</p>
<h3>Refined contrast</h3>
<p>We think beautiful design should never sacrifice legibility. With superior contrast and large, comfortable type, the new design is easy to read and a pleasure to navigate.</p>
<hr />
<h2 class="aligncenter">WordPress on every device</h2>
<p><img class="alignright  wp-image-2984" alt="responsive" src="http://i2.wp.com/wpdotorg.files.wordpress.com/2013/12/responsive.jpg?resize=255%2C255" data-recalc-dims="1" />We all access the internet in different ways. Smartphone, tablet, notebook, desktop — no matter what you use, WordPress will adapt and you’ll feel right at home.</p>
<h3>High definition at high speed</h3>
<p>WordPress is sharper than ever with new vector-based icons that scale to your screen. By ditching pixels, pages load significantly faster, too.</p>
<hr />
<h2 class="aligncenter">Admin color schemes to match your personality</h2>
<p><img class="aligncenter  wp-image-2954" alt="colors" src="http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/colors.jpg?resize=623%2C339" data-recalc-dims="1" /></p>
<p>WordPress just got a colorful new update. We’ve included eight new admin color schemes so you can pick the one that suits you best.</p>
<p>Color schemes can be previewed and changed from your Profile page.</p>
<hr />
<h2 class="aligncenter">Refined theme management</h2>
<p><img class="alignright  wp-image-2967" alt="themes" src="http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/themes.jpg?resize=360%2C344" data-recalc-dims="1" />The new themes screen lets you survey your themes at a glance. Or want more information? Click to discover more. Then sit back and use your keyboard’s navigation arrows to flip through every theme you’ve got.</p>
<h3>Smoother widget experience</h3>
<p>Drag-drag-drag. Scroll-scroll-scroll. Widget management can be complicated. With the new design, we’ve worked to streamline the widgets screen.</p>
<p>Have a large monitor? Multiple widget areas stack side-by-side to use the available space. Using a tablet? Just tap a widget to add it.</p>
<hr />
<h2 class="aligncenter">Twenty Fourteen, a sleek new magazine theme</h2>
<p><img class="aligncenter size-large wp-image-2789" alt="The new Twenty Fourteen theme displayed on a laptop. tablet and phone" src="http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/twentyfourteen.jpg?resize=692%2C275" data-recalc-dims="1" /></p>
<h3>Turn your blog into a magazine</h3>
<p>Create a beautiful magazine-style site with WordPress and Twenty Fourteen. Choose a grid or a slider to display featured content on your homepage. Customize your site with three widget areas or change your layout with two page templates.</p>
<p>With a striking design that does not compromise our trademark simplicity, Twenty Fourteen is our most intrepid default theme yet.</p>
<hr />
<h2>Beginning of a new era</h2>
<p>This release was led by Matt Mullenweg. This is our second release using the new plugin-first development process, with a much shorter timeframe than in the past. We think it’s been going great. You can check out the features currently in production on the <a title="Make WordPress Core" href="http://make.wordpress.org/core/" target="_blank">make/core blog</a>.</p>
<p>There are 188 contributors with props in this release:</p>
<p><a href="http://profiles.wordpress.org/aaronholbrook">Aaron Holbrook</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/adamsilverstein">adamsilverstein</a>, <a href="http://profiles.wordpress.org/admiralthrawn">admiralthrawn</a>, <a href="http://profiles.wordpress.org/ahoereth">Alexander Hoereth</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/aralbald">Andrey Kabakchiev</a>, <a href="http://profiles.wordpress.org/andykeith">Andy Keith</a>, <a href="http://profiles.wordpress.org/apeatling">Andy Peatling</a>, <a href="http://profiles.wordpress.org/ankitgadertcampcom">Ankit Gade</a>, <a href="http://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="http://profiles.wordpress.org/fliespl">Arkadiusz Rzadkowolski</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/bassgang">bassgang</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/bananastalktome">Billy Schneider</a>, <a href="http://profiles.wordpress.org/binarymoon">binarymoon</a>, <a href="http://profiles.wordpress.org/bradyvercher">Brady Vercher</a>, <a href="http://profiles.wordpress.org/bramd">bramd</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/calin">Calin Don</a>, <a href="http://profiles.wordpress.org/carldanley">Carl Danley</a>, <a href="http://profiles.wordpress.org/sixhours">Caroline Moore</a>, <a href="http://profiles.wordpress.org/caspie">Caspie</a>, <a href="http://profiles.wordpress.org/chrisbliss18">Chris Jean</a>, <a href="http://profiles.wordpress.org/iblamefish">Clinton Montague</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/corphi">Corphi</a>, <a href="http://profiles.wordpress.org/dbernar1">Dan Bernardic</a>, <a href="http://profiles.wordpress.org/danieldudzic">Daniel Dudzic</a>, <a href="http://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/datafeedrcom">datafeedr</a>, <a href="http://profiles.wordpress.org/lessbloat">Dave Martin</a>, <a href="http://profiles.wordpress.org/drw158">Dave Whitley</a>, <a href="http://profiles.wordpress.org/designsimply">designsimply</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/dougwollison">Doug Wollison</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="http://profiles.wordpress.org/dziudek">dziudek</a>, <a href="http://profiles.wordpress.org/plocha">edik</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="http://profiles.wordpress.org/evansolomon">Evan Solomon</a>, <a href="http://profiles.wordpress.org/faison">Faison</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/gnarf37">gnarf37</a>, <a href="http://profiles.wordpress.org/tivnet">Gregory Karpinsky</a>, <a href="http://profiles.wordpress.org/hanni">hanni</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/iandunn">Ian Dunn</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/isaackeyet">Isaac Keyet</a>, <a href="http://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="http://profiles.wordpress.org/jacklenox">Jack Lenox</a>, <a href="http://profiles.wordpress.org/janhenckens">janhenckens</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/jblz">Jeff Bowen</a>, <a href="http://profiles.wordpress.org/jeffr0">Jeff Chandler</a>, <a href="http://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="http://profiles.wordpress.org/buffler">Jeremy Buller</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jeherve">Jeremy Herve</a>, <a href="http://profiles.wordpress.org/jpry">Jeremy Pry</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="http://profiles.wordpress.org/jhned">jhned</a>, <a href="http://profiles.wordpress.org/jim912">jim912</a>, <a href="http://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/joen">Joen Asmussen</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/johnafish">John Fish</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="http://profiles.wordpress.org/joshuaabenazer">Joshua Abenazer</a>, <a href="http://profiles.wordpress.org/nukaga">Junko Nukaga</a>, <a href="http://profiles.wordpress.org/devesine">Justin de Vesine</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">K. Adam White</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/codebykat">Kat Hagan</a>, <a href="http://profiles.wordpress.org/littlethingsstudio">Kate Whitley</a>, <a href="http://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="http://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="http://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="http://profiles.wordpress.org/koki4a">Konstantin Dankov</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/drozdz">Krzysiek Drozdz</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="http://profiles.wordpress.org/lite3">lite3</a>, <a href="http://profiles.wordpress.org/lucp">Luc Princen</a>, <a href="http://profiles.wordpress.org/latz">Lutz Schroer</a>, <a href="http://profiles.wordpress.org/mako09">Mako</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markmcwilliams">Mark McWilliams</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt Thomas</a>, <a href="http://profiles.wordpress.org/mattwiebe">Matt Wiebe</a>, <a href="http://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/mattonomics">mattonomics</a>, <a href="http://profiles.wordpress.org/matveb">Matías Ventura</a>, <a href="http://profiles.wordpress.org/megane9988">megane9988</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/micahwave">micahwave</a>, <a href="http://profiles.wordpress.org/cainm">Michael Cain</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">Michael Erlewine</a>, <a href="http://profiles.wordpress.org/michelwppi">Michel - xiligroup dev</a>, <a href="http://profiles.wordpress.org/chellycat">Michelle Langston</a>, <a href="http://profiles.wordpress.org/gradyetc">Mike Burns</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikelittle">Mike Little</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/mt8biz">moto hachi</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/neil_pie">Neil Pie</a>, <a href="http://profiles.wordpress.org/nickdaugherty">Nick Daugherty</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="http://profiles.wordpress.org/ninio">ninio</a>, <a href="http://profiles.wordpress.org/ninnypants">ninnypants</a>, <a href="http://profiles.wordpress.org/nivijah">nivijah</a>, <a href="http://profiles.wordpress.org/nofearinc">nofearinc</a>, <a href="http://profiles.wordpress.org/nvwd">Nowell VanHoesen</a>, <a href="http://profiles.wordpress.org/odysseygate">odyssey</a>, <a href="http://profiles.wordpress.org/originalexe">OriginalEXE</a>, <a href="http://profiles.wordpress.org/swissspidy">Pascal Birchler</a>, <a href="http://profiles.wordpress.org/pauldewouters">Paul de Wouters</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/senlin">Piet</a>, <a href="http://profiles.wordpress.org/ptahdunbar">Ptah Dunbar</a>, <a href="http://profiles.wordpress.org/raamdev">Raam Dev</a>, <a href="http://profiles.wordpress.org/bamadesigner">Rachel Carden</a>, <a href="http://profiles.wordpress.org/rachelbaker">rachelbaker</a>, <a href="http://profiles.wordpress.org/radices">Radices</a>, <a href="http://profiles.wordpress.org/mauryaratan">Ram Ratan Maurya</a>, <a href="http://profiles.wordpress.org/defries">Remkus de Vries</a>, <a href="http://profiles.wordpress.org/ounziw">Rescuework Support</a>, <a href="http://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="http://profiles.wordpress.org/rdall">Robert Dall</a>, <a href="http://profiles.wordpress.org/wet">Robert Wetzlmayr, PHP-Programmierer</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/otto42">Samuel Wood</a>, <a href="http://profiles.wordpress.org/sanchothefat">sanchothefat</a>, <a href="http://profiles.wordpress.org/sboisvert">sboisvert</a>, <a href="http://profiles.wordpress.org/scottbasgaard">Scott Basgaard</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="http://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="http://profiles.wordpress.org/sirbrillig">sirbrillig</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="http://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="http://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="http://profiles.wordpress.org/iamtakashi">Takashi Irie</a>, <a href="http://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="http://profiles.wordpress.org/tmtoy">Takuma Morikawa</a>, <a href="http://profiles.wordpress.org/tellyworth">tellyworth</a>, <a href="http://profiles.wordpress.org/thomasguillot">Thomas Guillot</a>, <a href="http://profiles.wordpress.org/tierra">tierra</a>, <a href="http://profiles.wordpress.org/tillkruess">Till Krüss</a>, <a href="http://profiles.wordpress.org/tlamedia">TLA Media</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tomdxw">tomdxw</a>, <a href="http://profiles.wordpress.org/tommcfarlin">tommcfarlin</a>, <a href="http://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>, <a href="http://profiles.wordpress.org/taupecat">Tracy Rotton</a>, <a href="http://profiles.wordpress.org/trishasalas">trishasalas</a>, <a href="http://profiles.wordpress.org/mbmufffin">Tyler Smith</a>, <a href="http://profiles.wordpress.org/grapplerulrich">Ulrich</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, <a href="http://profiles.wordpress.org/l10n">Vladimir</a>, <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="http://profiles.wordpress.org/yonasy">yonasy</a>, <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>, and <a href="http://profiles.wordpress.org/tollmanz">Zack Tollman</a>. Also thanks to <a href="http://benmorrison.org/">Ben Morrison</a> and <a href="http://christineswebb.com/">Christine Webb</a> for help with the video.</p>
<p>Thanks for choosing WordPress. See you soon for version 3.9!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:46:"http://wordpress.org/news/2013/12/parker/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:31:"http://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:8:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Wed, 30 Apr 2014 01:27:15 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:10:"x-pingback";s:36:"http://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Thu, 17 Apr 2014 01:07:32 GMT";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130911110210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (1078, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1398864436', 'no') ; 
INSERT INTO `wp_options` VALUES (1079, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1398821236', 'no') ; 
INSERT INTO `wp_options` VALUES (1080, '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1398864438', 'no') ; 
INSERT INTO `wp_options` VALUES (1081, '_transient_feed_867bd5c64f85878d03a060509cd2f92c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WPTavern: Would Anyone Be Interested in a WordCamp Badges Plugin?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22020";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:172:"http://wptavern.com/would-anyone-be-interested-in-a-wordcamp-badges-plugin?utm_source=rss&utm_medium=rss&utm_campaign=would-anyone-be-interested-in-a-wordcamp-badges-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3364:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/wcmia-badge.jpg" rel="prettyphoto[22020]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/wcmia-badge.jpg?resize=171%2C195" alt="wcmia-badge" class="alignright size-full wp-image-22031" /></a><a href="http://wordpress.org/plugins/wordcamp-miami-badges/" target="_blank">Wordcamp Miami Badges</a> is a new plugin in the WordPress directory today. It allows speakers, attendees and volunteers to easily display badges indicating their participation in the <a href="http://2014.miami.wordcamp.org/" target="_blank">2014 event</a>, which is estimated to surpass 700 this year.</p>
<p>The badges plugin was created by <a href="http://smyl.es/" target="_blank">Myles McNamara</a>, a self-described &#8220;geek who loves open source, writing code, and helping others out.&#8221; After searching the directory for a plugin that would display an event-specific WordCamp badge, he couldn&#8217;t find a suitable option and was inspired to create a new plugin. WordCamp Miami Badges makes it easy to place a badge on your website using a configurable shortcode or widget.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/badges-widget.png" rel="prettyphoto[22020]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/badges-widget.png?resize=475%2C333" alt="badges-widget" class="aligncenter size-full wp-image-22030" /></a></p>
<h3>The Possibility of a Generic WordCamp Badges Plugin</h3>
<p>I got in touch with McNamara to find out how difficult it would be for other WordCamp organizers to adapt the plugin for their own events. He said that it&#8217;s possible to restructure it for use as a generic WordCamp badges plugin. &#8220;As of right now this will only work for the Miami one as I hard coded the images into the plugin, but it would be very easy to add an option for the user to specify the image, or even just set it as a variable in one of the files that others could change to what they want,&#8221; he said.</p>
<p>McNamara has a few ideas for enhancements to the plugin that he&#8217;d like to add, if there&#8217;s enough interest in converting this beta version into a widespread WordCamp plugin:</p>
<ul>
<li>A Countdown Clock</li>
<li>A Ribbon throughout entire site (like the GitHub fork me one)</li>
<li>A Sticky footer throughout entire site</li>
<li>A More customization for image (resizing, floating (absolute positing) image</li>
<li>Add animations using animate.css</li>
</ul>
<p>McNamara contributes to a number of open source projects on <a href="https://github.com/tripflex" target="_blank">Github</a>, including <a href="https://github.com/owncloud" target="_blank">ownCloud</a> and the <a href="https://github.com/pods-framework/pods" target="_blank">Pods Framework for WordPress</a>. If he gets enough interest in a generic WordCamp badges plugin, he&#8217;d be happy to adapt the WordCamp Miami plugin for broader use. If you&#8217;d like to get involved, you can contribute code and localizations to the plugin via <a href="http://github.com/tripflex/wordcamp-miami-badges" target="_blank">GitHub</a>.</p>
<p>What do you think? Would a WordCamp Badges plugin be useful for promoting events? Do you like McNamara&#8217;s list of proposed enhancements? Or is it just as easy to upload a badge to your website?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 29 Apr 2014 22:59:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WPTavern: How To Archive A Site You Don’t Have Access To";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21993";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:154:"http://wptavern.com/how-to-archive-a-site-you-dont-have-access-to?utm_source=rss&utm_medium=rss&utm_campaign=how-to-archive-a-site-you-dont-have-access-to";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4533:"<p>There are several options when it comes to backing up a WordPress site. Depending on the type of access you have, retrieving the database or an XML backup is easy. But what if you don&#8217;t have access to the database or the backend? Consider the <a title="http://www.reddit.com/r/Wordpress/comments/2453h1/downloading_all_from_a_wordpress_site/" href="http://www.reddit.com/r/Wordpress/comments/2453h1/downloading_all_from_a_wordpress_site/">following scenario presented on the WordPress subreddit</a>: <em>A relative who used WordPress recently passed away and you have no way to access the backend of their site. Their site is filled with memorable posts you&#8217;d like to archive</em>.</p>
<p>One option is to use <a title="http://www.gnu.org/software/wget/" href="http://www.gnu.org/software/wget/">WGET</a>. WGET is a free, open source software package used for retrieving files using HTTP, HTTPS and FTP, the most widely used Internet protocols. I used version 1.10.2 of <a title="http://xoomer.virgilio.it/hherold/" href="http://xoomer.virgilio.it/hherold/">this WGET package</a> put together by HHerold which worked successfully on my Windows 7 64-bit desktop. Once installed, you&#8217;ll need to activate the command prompt and navigate to the folder where WGET.exe is installed.</p>
<div id="attachment_22006" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/WGETinAction.png" rel="prettyphoto[21993]"><img class="size-full wp-image-22006" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/WGETinAction.png?resize=677%2C366" alt="WGET In Action" /></a><p class="wp-caption-text">WGET In Action</p></div>
<p>In the example below, I used four different parameters. GNU.org has an <a title="http://www.gnu.org/software/wget/manual/html_node/" href="http://www.gnu.org/software/wget/manual/html_node/">excellent guide available</a> that explains what each parameter does. Alternatively, you can use the <strong>wget &#8212; help</strong> command to see a list of commands.</p>
<ul>
<li>HTML Extension &#8211; This will save the retrieved files as .HTML</li>
<li>Convert Links &#8211; After the download is complete, this will convert the links in the document to make them suitable for local viewing. This affects not only the visible hyperlinks, but any part of the document that links to external content, such as embedded images, links to style sheets, hyperlinks to non-<small>HTML</small> content, etc.</li>
<li>-m &#8211; This turns on the options suitable for mirroring.</li>
<li>-w 20 &#8211; This command puts 20 seconds in between each file retrieved so it doesn&#8217;t hammer the server with traffic.</li>
</ul>
<p><em>wget &#8211;html-extension &#8211;convert-links -m -w 20 http://example.com</em></p>
<p>Using this command, each post and page will be saved as an HTML file. The site will be mirrored and links will be converted so I can browse them locally. The last parameter places 20 second intervals between each file retrieved to help prevent overloading the web server.</p>
<p><em>Keep in mind that this is saving the output of a post or page into an HTML file. This method should not be used as the primary means of backing up a website.</em></p>
<div id="attachment_22007" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/PostsandFilesDownloaded.png" rel="prettyphoto[21993]"><img class="size-full wp-image-22007" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/PostsandFilesDownloaded.png?resize=845%2C576" alt="Results Of The WGET Command" /></a><p class="wp-caption-text">Results Of The WGET Command</p></div>
<h3>The Command Line Proves Superior To The GUI</h3>
<p>A popular alternative to WGET is <a title="http://www.httrack.com/" href="http://www.httrack.com/">WinHTTrack</a>. Unfortunately, I couldn&#8217;t figure out how to get it to provide me with more than just the index.html of the site.  I found WinHTTrack to be confusing and hard to use. I spent a few hours trying several different programs to archive the output of websites. Most were hard to use or didn&#8217;t provide an easy to use interface. While I normally don&#8217;t use the command line to accomplish a task, it was superior in this case.</p>
<p>Going back to our scenario, it&#8217;s entirely possible to archive a site you don&#8217;t have access to thanks to WGET and similar tools.</p>
<p><strong>What tools or software do you recommend for archiving the output of a website?</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 29 Apr 2014 22:23:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"WPTavern: How to Share Beer Recipes in WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21992";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:140:"http://wptavern.com/how-to-share-beer-recipes-in-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=how-to-share-beer-recipes-in-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4292:"<div id="attachment_22012" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/beer.jpg" rel="prettyphoto[21992]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/beer.jpg?resize=1025%2C490" alt="photo credit: adambarhan - cc" class="size-full wp-image-22012" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/adambarhan/7213006248/">adambarhan</a> &#8211; <a href="http://creativecommons.org/licenses/by/2.0/">cc</a></p></div>
<p>Whether lager or ale, malty or hoppy, ice cold or room temperature, from a bottle, can, pint or stein, there&#8217;s no bad way to enjoy a brewski (unless you&#8217;ve had one too many). From ancient Egypt and Mesopotamia to all corners of the globe today, there is no denying beer&#8217;s popularity, as can also be observed by the continued rise in the craft brew movement and the homebrewing community. The <a href="http://www.homebrewersassociation.org/" target="_blank">American Homebrewers Association</a> has registered over 1,700 homebrew clubs with individual memberships estimated in the millions.</p>
<p>Part of the joy of homebrewing is the art of putting different recipes together and discovering new flavors, exploring new styles of beer and tinkering with ingredients. This recipe creation process used to require quite a few calculations and a rather expansive knowledge of ingredients, hops, yeasts and brewing techniques in order to brew a particular style. However, creating and saving beer recipes is much easier today, thanks to programs like <a href="http://beersmith.com/" target="_blank">BeerSmith</a> and websites like <a href="https://www.brewtoad.com/" target="_blank">Brewtoad</a> that combine extensive databases of ingredients with built-in calculators that can help novice brewers create and share their recipes.</p>
<p>And now, it&#8217;s easy to share homebrew recipes on your WordPress site, thanks to the <a href="https://wordpress.org/plugins/beerxml-shortcode/" target="_blank">BeerXML Shortcode</a> plugin. <a href="https://twitter.com/derekspringer" target="_blank">Derek Springer</a>, the plugin&#8217;s creator, is currently a Code Wrangler at Automattic and an avid homebrewer. His plugin takes an XML beer recipe and displays it nicely on the page via a shortcode.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/beer-recipe.png" rel="prettyphoto[21992]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/beer-recipe.png?resize=1025%2C1108" alt="beer-recipe" class="aligncenter size-full wp-image-22005" /></a></p>
<p>The BeerXML Shortcode plugin features the following:</p>
<ul>
<li>Link to a BeerXML document to display recipe details, style details, fermentables, hops, miscs, yeast, and notes</li>
<li>Allows you to easily switch between U.S. and Metric measurements</li>
<li>Control if and how long recipe is cached</li>
<li>Allow readers to download the recipe directly</li>
</ul>
<p>BeerXML Shortcode makes it possible for you to create your own library of recipes on your site and open them up for visitor feedback in WordPress posts or pages. Since WordPress is search engine friendly, adding recipes to posts makes easier for others to discover and try. The plugin also lets you provide a recipe for download as an XML file, which can easily be imported into BeerSmith and/or other brewing programs where the next brewer can tweak and change it as necessary.</p>
<p>The open source software community and homebrewers have a good deal in common. Sharing a beer recipe is like open sourcing happiness. The days of secret family recipes hidden away from the competition have fallen aside with the explosion of craft brew culture, which values sharing and openness. Recipe sharing gets more people brewing and promotes the appreciation of craft beer.</p>
<p>As the saying goes:</p>
<p><strong>&#8220;Give a man a beer and he&#8217;ll waste an hour. Teach a man to homebrew and he&#8217;ll waste a lifetime.&#8221;</strong></p>
<p>The <a href="https://wordpress.org/plugins/beerxml-shortcode/" target="_blank">BeerXML Shortcode</a> plugin is available for free from the WordPress plugin directory. Add it to your site to start sharing your beer recipes with the world.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 29 Apr 2014 19:55:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WPTavern: Important Security Update for SyntaxHighlighter Evolved WordPress Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21971";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:208:"http://wptavern.com/important-security-update-for-syntaxhighlighter-evolved-wordpress-plugin?utm_source=rss&utm_medium=rss&utm_campaign=important-security-update-for-syntaxhighlighter-evolved-wordpress-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1900:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/syntaxhighlighter-evolved.png" rel="prettyphoto[21971]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/syntaxhighlighter-evolved.png?resize=772%2C250" alt="syntaxhighlighter-evolved" class="aligncenter size-full wp-image-21982" /></a></p>
<p>Alex Mills announced an important security update today for his <a href="http://wordpress.org/plugins/syntaxhighlighter/" target="_blank">SyntaxHighlighter Evolved</a> plugin. The 3.1.10 release includes a new version of the SyntaxHighlighter 3.x library to address an XSS security issue.</p>
<blockquote class="twitter-tweet" width="550"><p>If you run my SyntaxHighlighter WordPress plugin on your site, please update to 3.1.10. Important security fix from upstream JS package.</p>
<p>&mdash; Alex Mills (@Viper007Bond) <a href="https://twitter.com/Viper007Bond/statuses/460926205978345472">April 28, 2014</a></p></blockquote>
<p></p>
<p>SyntaxHighlighter Evolved is used widely on self-hosted WordPress sites for sharing code and has been downloaded more than 350,000 times. Most notably, it&#8217;s used on WordPress.com to allow users to <a href="http://en.support.wordpress.com/code/posting-source-code/" target="_blank">post code snippets</a> and is the same plugin we use on WP Tavern for tutorials. Mills credits Ben Bidner for finding the bug and <a href="http://alexgorbatchev.com/SyntaxHighlighter/" target="_blank">Alex Gorbatchev</a> for working with Automattic to patch the issue.</p>
<p>Version 3.1.10 also adds compatibility with sites where the plugins folder has been moved to another location other than the default directory, though the security fix is the bulk of this update. If you&#8217;re using SyntaxHighlighter Evolved on any of your WordPress sites, make sure to visit each and update the plugin to avoid a potential XSS security breach.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 29 Apr 2014 01:27:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WPTavern: How to Change BuddyPress Profile Field Visibility Settings";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21951";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:180:"http://wptavern.com/how-to-change-buddypress-profile-field-visibility-settings?utm_source=rss&utm_medium=rss&utm_campaign=how-to-change-buddypress-profile-field-visibility-settings";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2567:"<p>Profile field visibility settings were <a href="http://bpdevel.wordpress.com/2012/03/16/profile-field-visibility-in-bp-1-6/" target="_blank">added to BuddyPress in version 1.6</a> in order to address a popular request for profile privacy. The settings had remained the same up until the recent 2.0 release. Field visibility settings were previously tacked onto each field in the profile editing screens. BuddyPress project lead John James Jacoby <a href="https://buddypress.trac.wordpress.org/ticket/5352" target="_blank">proposed</a> that the plugin separate field data from field privacy by moving the visibility into its own settings page.</p>
<p><a href="http://wptavern.com/buddypress-2-0-released-big-performance-improvements-and-new-administration-tools" target="_blank">BuddyPress 2.0</a> added a new Settings > Profile tab that allows users to configure profile field visibility from a single screen. This change declutters the profile editing pages and provides an easier way to edit field visibility all in one pass.</p>
<p>If you were not aware that the settings were moved in BP 2.0, it may have seemed that they disappeared entirely. Logged-in members can now find them at <strong>Settings > Profile</strong>:</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/buddypress-profile-field-visibility.png" rel="prettyphoto[21951]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/buddypress-profile-field-visibility.png?resize=1025%2C846" alt="buddypress-profile-field-visibility" class="aligncenter size-full wp-image-21955" /></a></p>
<p>As you can see in the example, some fields do not have visibility options. This is because administrators can opt to override them and set per-member visibility settings for each field at <strong>Users > Profile Fields > Edit Field</strong>.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/admin-visibility-settings.png" rel="prettyphoto[21951]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/admin-visibility-settings.png?resize=985%2C666" alt="admin-visibility-settings" class="aligncenter size-full wp-image-21964" /></a></p>
<p>The default option is to let members change the field&#8217;s visibility, but you can also elect to enforce the default visibility for all members.</p>
<p>If you don&#8217;t have a BuddyPress site handy for checking out the new profile field visibility settings page, you can see a live demo on <a href="http://buddypress.org/" target="_blank">BuddyPress.org</a> when logged into your profile.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 28 Apr 2014 23:25:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:106:"WPTavern: Genesis Skeleton for WordPress: Rapidly Create, Develop, and Deploy Across Multiple Environments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21826";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:250:"http://wptavern.com/genesis-skeleton-for-wordpress-rapidly-create-develop-and-deploy-across-multiple-environments?utm_source=rss&utm_medium=rss&utm_campaign=genesis-skeleton-for-wordpress-rapidly-create-develop-and-deploy-across-multiple-environments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8515:"<p>Last week we featured a collection of <a href="http://wptavern.com/13-vagrant-resources-for-wordpress-development" target="_blank">Vagrant resources for WordPress development</a>. Eric Clemmons, one of our readers, commented to let us know about <a href="https://github.com/genesis/wordpress" target="_blank">Genesis Skeleton for WordPress</a>, an awesome project that uses Vagrant for creating, developing and deploying WordPress across multiple environments.</p>
<p>When Clemmons created Genesis, he wasn&#8217;t aware of how easily the name might be confused with the Genesis theme from StudioPress, so he&#8217;s updating the project to be called &#8220;Genesis Skeleton for WordPress.&#8221; The project utilizes <a href="http://nodejs.org/" target="_blank">NodeJS</a>, <a href="http://www.vagrantup.com/" target="_blank">Vagrant</a> and <a href="https://www.virtualbox.org/" target="_blank">VirtualBox</a>. For scaffolding and development, it relies on <a href="http://yeoman.io/" target="_blank">Yeoman</a>, <a href="http://bower.io/" target="_blank">Bower</a>, <a href="https://github.com/genesis/generator-wordpress/" target="_blank">Genesis WordPress Generator</a>, and <a href="https://github.com/smdahlen/vagrant-hostmanager" target="_blank">Vagrant Host Manager</a>. Deployment is handled by Capistrano and Ansible. This setup allows for the following:</p>
<ul>
<li>Generate a functional WordPress site + server</li>
<li>First-class local development</li>
<li>Independently stage features for review</li>
<li>Use production data when developing</li>
<li>High-performance, zero-configuration caching out of the box</li>
<li>Easily monitor remote server errors</li>
<li>Instant, secure SSH access</li>
<li>Automated server provisioning</li>
<li>Consistent, reliable environments</li>
</ul>
<p>Here&#8217;s a quick demo:</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/genesis.gif" rel="prettyphoto[21826]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/genesis.gif?resize=782%2C614" alt="genesis" class="aligncenter size-full wp-image-21830" /></a></p>
<p>Clemmons and his colleagues use Genesis at <a href="http://www.cmn.com/" target="_blank">Consumer Media Network</a> to make it easier to develop, test, stage, and deploy a robust WordPress site. &#8220;The project has been re-invented over the past 2 years,&#8221; Clemmons said. &#8220;Once Yeoman and Ansible gained more traction, I was ready to re-tool it into what it is today.&#8221;</p>
<h3>What makes the Genesis Skeleton for WordPress unique?</h3>
<p>The Genesis project was specifically created to allow the developers at CMN to follow the best practices set for all of their other projects, including non-WordPress projects using Symfony or Node. Clemmons outlined those practices and how they are integrated into Genesis:</p>
<ul>
<li>Local development should be within a Vagrant VM to keep the client OS pristine.</li>
<li>All environments (local/staging/production) should share the exact same machine setup (i.e. provisioning) to minimize environmental errors when deploying.</li>
<li>Utilize the best-in-class tools suited for individual tasks:  Vagrant for local development, Yeoman for scaffolding, WordPress for the CMS, Ansible for provisioning, Capistrano for deployment.</li>
<li>Draw a firm line in the sand regarding what Genesis Skeleton won&#8217;t do. (e.g. installing themes, plugins)</li>
<li>Encourage performance via Apache optimization and Varnish, vs. relying on the application layer (e.g. WordPress Plugins) to do the server&#8217;s job.</li>
<li>Support for staging/previewing branches. (e.g. http://my-new-feature.staging.mysite.com)</li>
</ul>
<p>While the first incarnation of the Genesis skeleton used a wrapper script, the latest version requires the developer to have a better understanding of his tools. <strong>&#8220;I intentionally avoided &#8216;do-it-all&#8217; wrapper scripts, because the developer becomes reliant on Genesis Skeleton, not the underlying tools powering their project,&#8221;</strong> Clemmons said. He&#8217;s started several &#8220;Genesis Skeletons&#8221; for various technologies they use for scaffolding projects at CMN. The <a href="https://github.com/genesis/angular" target="_blank">Angular</a> and <a href="https://github.com/genesis/wordpress" target="_blank">WordPress</a> skeletons have both been open source for the past year.</p>
<h3>Genesis Skeleton Provides a Consistent Workflow and Better Collaboration</h3>
<p>Because Clemmons and his team have dozens of WordPress sites, he wanted them to have a consistent workflow across all projects, no matter what the complexity:</p>
<ol>
<li>git clone &#8230;</li>
<li>bower install</li>
<li>vagrant up </li>
<li>cap production genesis:down</li>
<li>open http://local.reponame.com/</li>
<li>cap production deploy</li>
</ol>
<p>This streamlined workflow allows his team to collaborate on projects more efficiently. <strong>&#8220;We&#8217;ve been able to have a half-dozen people openly collaborating, committing, and deploying the same WordPress site within a day,&#8221;</strong> Clemmons said. The Genesis Skeleton has revolutionized the way they work together:</p>
<blockquote><p>Whereas, in the past, a single developer was in charge of everything and was responsible for FTP&#8217;ing (ugh!) the code to production, and subsequently committing and pushing to Github afterwards. (Hopefully they remembered that part!)</p>
<p>Now, Github is our &#8216;single source of truth&#8217; for what gets deployed, and our sites have vastly improved in terms of reliability, quality, and speed.</p></blockquote>
<p>From the outside, the Skeleton may seem like a fancy excuse to use all the newest development tools available, but Clemmons reports that changing their workflow greatly increased the team&#8217;s productivity. &#8220;The best thing that Genesis Skeleton for WordPress has done for us is to allow all members of our technology team (from systems, to frontend, to backend) to actively collaborate and work on a site,&#8221; he said. <strong>&#8220;The productivity gains have been astounding!&#8221;</strong></p>
<h3>Open Sourcing the Genesis Skeleton for WordPress</h3>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/genesis-skeleton.jpg" rel="prettyphoto[21826]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/genesis-skeleton.jpg?resize=700%2C325" alt="genesis-skeleton" class="aligncenter size-full wp-image-21832" /></a></p>
<p>The Genesis skeleton is now a fairly well-supported and well-documented open source project on github. Clemmons said the project grew out of their own need across dozens of sites and a previous project he began two years ago. &#8220;Once I completed the latest iteration&#8217;s prototype, we battle-tested in production,&#8221; he said. &#8220;The entire team worked to solidify the project with regards to performance, workflow, and edge-cases specific to WordPress.&#8221;</p>
<p>When asked why he decided to open source the skeleton, Clemmons said that he hopes the community will be able to benefit from the project. <strong>&#8220;I usually despise working with WordPress, as do many others, not because it&#8217;s a terrible framework, but because the development/deployment workflow is generally terrible and out-dated,&#8221;</strong> he said. &#8220;Because this is a problem that wasn&#8217;t solved at my place of business (and was marginally solved by moving hosting to a PaaS), I wanted to share the progress with the community at large.&#8221;</p>
<p>Clemmons has always believed in open sourcing tools wherever possible. He also encourages the activity with his colleagues. When his team is active in building something for work, they try to open source the parts not specific to the business model. As a result, Clemmons has seen an impressive amount of involvement with the project. &#8220;Key individuals have been essential to improving performance and resolving bugs, so clearly open-sourcing it was the right move.&#8221;</p>
<p>If you want to incorporate modern development tools into your WordPress projects, Genesis is a solid option for getting started. Whether you&#8217;re one person working alone or collaborating with a large team, Genesis makes it easy to create a consistent development and deployment workflow across all environments. Check out the <a href="https://github.com/genesis/wordpress" target="_blank">Genesis Skeleton for WordPress</a> on Github.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 28 Apr 2014 16:49:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:63:"WPTavern: WPWeekly Episode 147 – Interview With Japh Thompson";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=21889&preview_id=21889";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:162:"http://wptavern.com/wpweekly-episode-147-interview-with-japh-thompson?utm_source=rss&utm_medium=rss&utm_campaign=wpweekly-episode-147-interview-with-japh-thompson";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2403:"<p>In this episode of WordPress Weekly, I sat down with <a href="http://japh.com.au/" title="http://japh.com.au/">Japh Thompson</a> to discuss his experience working at Envato for the past four years. Thompson worked in support before becoming the WordPress Evangelist for ThemeForest. In the interview, we learned what it was like to be a liaison between a huge theme marketplace and the WordPress Community.</p>
<p>We learned how difficult it was to try to change the negative perception of ThemeForest while working alongside the community. Last but not least, we learned what he&#8217;s working on at <a href="https://x-team.com/" title="https://x-team.com/">X-Team</a>.</p>
<h2>Stories Discussed:</h2>
<p><a href="http://wptavern.com/how-the-advanced-image-editing-properties-contributed-to-wordpress-theme-lock-in" title="http://wptavern.com/how-the-advanced-image-editing-properties-contributed-to-wordpress-theme-lock-in">How The Advanced Image Editing Properties Contributed To WordPress Theme Lock-in</a><br />
<a href="http://wptavern.com/themelab-acquired-by-syed-balkhi" title="http://wptavern.com/themelab-acquired-by-syed-balkhi">ThemeLab Acquired By Syed Balkhi</a><br />
<a href="http://wptavern.com/take-the-wordpress-contributor-experience-survey" title="http://wptavern.com/take-the-wordpress-contributor-experience-survey">Take the WordPress Contributor Experience Survey</a><br />
<a href="http://wptavern.com/why-wordpress-cant-kill-commercial-plugin-businesses" title="http://wptavern.com/why-wordpress-cant-kill-commercial-plugin-businesses">Why WordPress Can’t Kill Commercial Plugin Businesses</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Friday, May 2nd 3 P.M. Eastern &#8211; Special Guest <a href="http://siobhanmckeown.com/" title="http://siobhanmckeown.com/">Siobhan McKeown</a></p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #147:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 26 Apr 2014 16:22:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:55:"WPTavern: How to Repair a Crashed WordPress Posts Table";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21797";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:154:"http://wptavern.com/how-to-repair-a-crashed-wordpress-posts-table?utm_source=rss&utm_medium=rss&utm_campaign=how-to-repair-a-crashed-wordpress-posts-table";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4659:"<div id="attachment_21873" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/emergency.jpg" rel="prettyphoto[21797]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/emergency.jpg?resize=1024%2C482" alt="photo credit: Code & Martini by Ivana Vasilj - cc license" class="size-full wp-image-21873" /></a><p class="wp-caption-text">photo credit: <a href="https://flic.kr/p/dLUWMb">Code &#038; Martini</a> by <a href="https://www.flickr.com/photos/ivanavasilj/">Ivana Vasilj</a> &#8211; cc license</p></div>
<p>Every now and then the WordPress posts table will crash and screw up your website. Why does this happen? It&#8217;s not always clear how tables get corrupted, although it can usually be attributed to an <a href="https://dev.mysql.com/doc/refman/5.1/en/crashing.html" target="_blank">unexpected event</a>, such as the MySQL server or the server host getting killed in the middle of an update, causing interrupted writes to the database.</p>
<h3>Symptoms of a Crashed Posts Table</h3>
<p>If you navigate to the &#8220;All Posts&#8221; or &#8220;All Pages&#8221; screen in the WordPress admin and find nothing there, your first instinct is probably to freak out. <strong><em>What happened to all of my content?!</em></strong> Don&#8217;t worry; it&#8217;s still there. This is often a symptom of a crashed posts table in the database. It&#8217;s the MySQL equivalent to a throwing a tantrum, but it&#8217;s easily fixed, so you should stay calm.</p>
<p>You may also see blank pages or get 404s on existing pages where there should be content. Those who have BuddyPress active may also see a message like this:</p>
<p><strong>&#8220;The following active BuddyPress Components do not have associated WordPress Pages: User Groups, Members, Activate, Register. Repair&#8221;</strong></p>
<p>When the posts table is crashed, BuddyPress can&#8217;t find those pages, so it gives you that warning, even though you set the pages before.</p>
<h3>How to Fix a Crashed Table</h3>
<p>Sometimes WordPress can repair this problem automatically, but other times you&#8217;ll just have to do it manually via phpMyAdmin. Before touching anything, make sure that you have a backup of your database.</p>
<p>If you&#8217;re not comfortable with phpmyadmin, you should first try to use <a href="http://codex.wordpress.org/Editing_wp-config.php#Automatic_Database_Optimizing" target="_blank">WordPress&#8217; recommended method of database repair</a>, available since 2.9. Add the following to your <em>wp-config.php</em> file:</p>
<pre class="brush: php; light: true; title: ; notranslate">define( \'WP_ALLOW_REPAIR\', true );</pre>
<p>That should take effect and automatically repair your crashed table after you visit the script at: <strong>{$your_site}/wp-admin/maint/repair.php</strong></p>
<p>If you&#8217;re comfortable with using phpmyadmin, you may opt for an alternative method of repair, which really does the same thing as the previous method:</p>
<p>Log into your host&#8217;s control panel and launch phpMyAdmin. Select your database and then look for the <strong>wp_posts</strong> table. Chances are that it&#8217;s not going to look like the other tables and will probably say &#8220;In Use&#8221;:</p>
<div id="attachment_21856" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/crashed-posts-table.jpg" rel="prettyphoto[21797]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/crashed-posts-table.jpg?resize=974%2C179" alt="Scary, right?!" class="size-full wp-image-21856" /></a><p class="wp-caption-text">Scary, right?!</p></div>
<p>This is the table that is bedeviling you and you&#8217;ll want to select it and then click on &#8220;<a href="https://dev.mysql.com/doc/refman/5.1/en/repair-table.html" target="_blank">Repair Table</a>&#8221; in the dropdown:</p>
<div id="attachment_21861" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/repair-table.jpg" rel="prettyphoto[21797]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/repair-table.jpg?resize=815%2C234" alt="Repair Table" class="size-full wp-image-21861" /></a><p class="wp-caption-text">Repair Table</p></div>
<p>This should have you all fixed up. Visit your site to verify that your posts and pages are back to normal. <em>Note:</em> This also works for other corrupted tables, i.e. wp_options, etc. It&#8217;s a fairly easy solution to a problem that presents itself as a dire emergency on the frontend of your WordPress site. File this one away for the next time you suspect a corrupted table.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 25 Apr 2014 22:42:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"WPTavern: WordPress Code Reference is Now Live";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21839";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:136:"http://wptavern.com/wordpress-code-reference-is-now-live?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-code-reference-is-now-live";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3186:"<p>Siobhan McKeown <a href="http://make.wordpress.org/docs/2014/04/25/good-news-everyone-version-1-of-the-code/" target="_blank">announced</a> that the first version of the WordPress Code Reference is now live. It&#8217;s still in the very early stages of development but is now out in the wild so that people can help contribute. <a href="http://developer.wordpress.org/reference" target="_blank">Go try it out</a> to see how easy it is to search the WordPress code base.</p>
<p>The reference was created as part of the <a href="http://make.wordpress.org/docs/tag/devhub/" target="_blank">devhub project</a> to make it easy for developers to find more information about WordPress&#8217; functions, classes, methods, hooks, and filters. After a few quick searches, I found that the search function is actually quite forgiving and will return results that are similar to what you were looking for, even if you spell it wrong.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/wordpress-code-reference.jpg" rel="prettyphoto[21839]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/wordpress-code-reference.jpg?resize=794%2C595" alt="wordpress-code-reference" class="aligncenter size-full wp-image-21841" /></a></p>
<h3>How can you help improve the reference?</h3>
<p>McKeown said that current development for the parser will continue on Github and you can <a href="https://github.com/rmccue/WP-Parser/issues?labels=enhancement&state=open" target="_blank">open a ticket</a> there to offer feedback on issues and enhancements. Tickets for the code reference theme can be found on <a href="https://meta.trac.wordpress.org/query?status=!closed&component=developer.wordpress.org" target="_blank">meta trac</a>. Very soon you&#8217;ll be able to submit code examples to the reference, McKeown said:</p>
<blockquote><p>Please feel free to add tickets to meta trac if there are any issues you encounter, and if there’s a feature or enhancement you’d like we can discuss that too. We do have the functionality ready for submitting examples, we just need a few parser things fixed before we can deploy it.</p></blockquote>
<p>The documentation team has been working at a feverish pace to completely overhaul WordPress docs to make them more useful to the community. The contributor handbooks have a <a href="https://make.wordpress.org/docs/2014/04/24/redesigned-contributor-handbooks/" target="_blank">new design</a> that is now live on the <a href="http://make.wordpress.org/core/handbook/" target="_blank">core</a>, <a href="http://make.wordpress.org/mobile/handbook/" target="_blank">mobile</a>, <a href="http://make.wordpress.org/docs/handbook/" target="_blank">docs</a>, and <a href="http://make.wordpress.org/polyglots/handbook/" target="_blank">polyglot</a> handbooks. If you want to get in on the fun and help to make WordPress docs more awesome, join the <a href="https://make.wordpress.org/docs/" target="_blank">Docs team</a> at their weekly meeting <a href="http://www.timeanddate.com/worldclock/fixedtime.html?hour=23&min=00&sec=0&p1=0&msg=Docs+Team+Chat" target="_blank">Thursdays at 23:00 UTC</a> in IRC on the #wordpress-sfd channel.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 25 Apr 2014 20:50:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WPTavern: Interface: A Free Responsive Business Theme for WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21697";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:176:"http://wptavern.com/interface-a-free-responsive-business-theme-for-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=interface-a-free-responsive-business-theme-for-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2890:"<p><a href="http://wordpress.org/themes/interface" target="_blank">Interface</a> is a new business theme in the WordPress Themes Directory, created by <a href="http://themehorse.com/" target="_blank">Theme Horse</a>, the same folks behind the popular <a href="http://wordpress.org/themes/clean-retina" target="_blank">Clean Retina</a> and <a href="http://wordpress.org/themes/attitude" target="_blank">Attitude</a> themes that have more than 80,000 downloads combined. If you need to set up a simple business site and you&#8217;re into the flat-style <a href="http://wptavern.com/exploring-wordpress-theme-designers-love-affair-with-mint-green" target="_blank">mint green design trend</a>, then the new Interface theme might be just the ticket.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/interface.jpg" rel="prettyphoto[21697]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/interface.jpg?resize=880%2C660" alt="interface" class="aligncenter size-full wp-image-21789" /></a></p>
<p>The theme is responsive, retina ready, and compatible with both BuddyPress and bbPress. The social features drop nicely into the theme without any conflicts.</p>
<p>Interface includes several options in the customizer for setting the header image, navigation, background, etc. It also includes a host of theme-specific widgets that you can edit live to create promotional boxes, feature recent work, display services, and add items typically related to business needs.</p>
<p>In addition to the customizer options, Interface includes its own options panel for further customization of the homepage slider, layouts, social links, blog category, optional search form in the header, favicon and more advanced settings.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/interface-options.jpg" rel="prettyphoto[21697]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/interface-options.jpg?resize=875%2C183" alt="interface-options" class="aligncenter size-full wp-image-21804" /></a></p>
<p>Inside this theme you&#8217;ll find many different building blocks for customizing your business site, including:</p>
<ul>
<li>4 layouts for posts/pages</li>
<li>5 unique page templates</li>
<li>8 widget areas</li>
<li>6 custom widgets</li>
<li>Separate top and bottom info bar to highlight contact/email/location</li>
</ul>
<p>Check out the <a href="http://themehorse.com/preview/interface/" target="_blank">live demo</a> on the Theme Horse site where you can view all the different page and blog templates available for both business and more blogger-oriented sites. With all the customization options, <a href="http://wordpress.org/themes/interface" target="_blank">Interface</a> is bound to be another favorite from the folks at Theme Horse. Add it to your site from WordPress.org via the theme browser in your admin panel.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 25 Apr 2014 18:09:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:43:"Matt: Scrollkit and Longreads at Automattic";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43748";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://ma.tt/2014/04/scrollkit-and-longreads-at-automattic/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:680:"<p>You might have seen the news last week that <a href="http://www.businessweek.com/articles/2014-04-09/automattic-steward-of-wordpress-snaps-up-longreads">Longreads is joining Automattic&#8217;s editorial team</a>. Today I&#8217;m excited to announce that <a href="http://www.scrollkit.com/">we&#8217;ve acquired Scroll Kit and they&#8217;re joining Automattic as well</a>, and will be focused on making customization more visual and intuitive. We&#8217;re barely on the second inning of what WordPress could be, and the impact it can have on the world, and I consider myself very lucky to be working with the best and brightest on transforming the way the world publishes.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 25 Apr 2014 00:32:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:81:"WPTavern: Automattic Snaps Up Scroll Kit to Add to the WordPress.com Product Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21755";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:206:"http://wptavern.com/automattic-snaps-up-scroll-kit-to-add-to-the-wordpress-com-product-team?utm_source=rss&utm_medium=rss&utm_campaign=automattic-snaps-up-scroll-kit-to-add-to-the-wordpress-com-product-team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3265:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/scroll-kit.png" rel="prettyphoto[21755]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/scroll-kit.png?resize=640%2C338" alt="scroll-kit" class="aligncenter size-full wp-image-21768" /></a></p>
<p>Scroll Kit founders Cody Brown and Kate Ray <a href="http://www.scrollkit.com/" target="_blank">announced</a> today that they are joining the product team at WordPress.com. Automattic, having recently acquired <a href="http://wptavern.com/automattic-acquires-longreads-invests-in-digital-longform-publishing" target="_blank">Longreads</a> and <a href="http://wptavern.com/cloudup-makes-file-sharing-incredibly-easy" target="_blank">Cloudup</a>, adds <a href="http://www.scrollkit.com/" target="_blank">Scroll Kit</a> to its collection, ostensibly in order to subsume its better features into WordPress.com.</p>
<p>Unlike Cloudup and Longreads, which have continued on with business as usual after acquisition, Scroll Kit will be shutting down its editor in three months as part of the deal. Users of the app are encouraged to export their scrolls in case a more native solution is available further down the road.</p>
<p>Scroll Kit allowed users to create beautiful web pages without writing a line of code. Its powerful visual content editor was actually used to<a href="http://techcrunch.com/2013/05/21/snow-fail-the-new-york-times-and-its-misunderstanding-of-copyright/" target="_blank"> recreate the New York Time&#8217;s interactive Snowfall experiment in an hour</a>, a project which NYT says took hundreds of hours of hand-coding. Although its makers cannot yet comment on their super secret future plans, one cannot help but wonder if this radically simplified visual editor may soon make its way into WordPress.com.</p>
<p>Scroll Kit already has a WordPress <a href="http://wordpress.org/plugins/scrollkit/" target="_blank">plugin</a> listed among WordPress.com VIP&#8217;s list of layout and organization <a href="http://vip.wordpress.com/plugins/" target="_blank">plugins</a>. This tool offered Scroll Kit users the ability to connect directly to self-hosted WordPress sites and create customized templates as well as change images, fonts, backgrounds, and add special effects. <strong>&#8220;We&#8217;ll take what we learned building Scroll Kit and apply it to a product that’s always been tightly integrated with ours,&#8221;</strong> Scroll Kit creators said, as they bid their current users goodbye.</p>
<p>Will WordPress.com incorporate Scroll Kit&#8217;s editor into the theme editing experience for its customers? If so, it will be interesting to see if some of those features trickle down to the open source WordPress project. With the instant popularity of front-end visual editors like <a href="http://velocitypage.com/" target="_blank">VelocityPage</a> for self-hosted sites, a simplified theme editing experience is bound to resonate with WordPress.com&#8217;s user base. Scroll Kit&#8217;s makers said that their objective was <strong>&#8220;to create a process for making the web that was more like drawing on a piece of paper.&#8221;</strong> If they can bring that experience to WordPress.com, then Automattic has just bought itself a magic wand.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 24 Apr 2014 23:37:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"WPTavern: View More Themes in the WordPress Theme Browser";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21736";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:158:"http://wptavern.com/view-more-themes-in-the-wordpress-theme-browser?utm_source=rss&utm_medium=rss&utm_campaign=view-more-themes-in-the-wordpress-theme-browser";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3169:"<p><a href="http://wptavern.com/wordpress-3-9-smith-released" target="_blank">WordPress 3.9</a> brought a huge improvement to the WordPress theme browsing experience. By default, the new browser shows large preview images of themes with indicators for the ones you already have installed. It also allows for better filtering and exploring of featured and popular items.</p>
<div id="attachment_21121" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/WP39ThemeExperience.png" rel="prettyphoto[21736]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/WP39ThemeExperience.png?resize=859%2C503" alt="Theme Browser Experience Revamped In WordPress 3.9" class="size-full wp-image-21121" /></a><p class="wp-caption-text">Theme Browser Experience Revamped In WordPress 3.9</p></div>
<p>These updates to the theme browser make it far more likely that WordPress users will want to look for new themes without leaving the admin. The experience is much better than searching directly on WordPress.org.</p>
<h3>See More Themes</h3>
<p>Themes and their previews load quickly from WordPress.org, but the size of the thumbnails prevents you from seeing more of them on the screen at once. <a href="http://wordpress.org/plugins/see-more-themes/" target="_blank">See More Themes</a> is a new plugin, written by <a href="http://www.sdavismedia.com/" target="_blank">Sean Davis</a>, that allows you to browse more themes. When activated, the plugin modifies WordPress&#8217; default admin CSS for the theme browser, reducing the size of the thumbnails to display more themes.</p>
<p>The default theme browser looks like this:</p>
<div id="attachment_21748" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/old-theme-browser.png" rel="prettyphoto[21736]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/old-theme-browser.png?resize=1025%2C643" alt="Default Theme Browser" class="size-full wp-image-21748" /></a><p class="wp-caption-text">Default Theme Browser</p></div>
<p>When you have See More Themes activated, you&#8217;ll be able to take in more themes at a glance:</p>
<div id="attachment_21749" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/new-theme-browser.png" rel="prettyphoto[21736]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/new-theme-browser.png?resize=1025%2C643" alt="Theme Browser with See More Themes plugin activated" class="size-full wp-image-21749" /></a><p class="wp-caption-text">Theme Browser with See More Themes plugin activated</p></div>
<p>Sometimes it takes hours of browsing and previewing themes before you can settle on one that works for your site. See More Themes helps you browse through them faster while still presenting a decent sized thumbnail. It also maintains the theme browser&#8217;s responsiveness. If you like being able to see more themes at once, <a href="http://wordpress.org/plugins/see-more-themes/" target="_blank">download</a> the plugin from WordPress.org the next time you&#8217;re on the hunt for new themes in the admin.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 24 Apr 2014 22:10:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WPTavern: Why WordPress Can’t Kill Commercial Plugin Businesses";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21735";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:168:"http://wptavern.com/why-wordpress-cant-kill-commercial-plugin-businesses?utm_source=rss&utm_medium=rss&utm_campaign=why-wordpress-cant-kill-commercial-plugin-businesses";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2820:"<p><span class="post-byline"><span class="author publisher-anchor-color">Iain Poulson recently published a post that asks an important but easy question to answer. </span></span><a title="http://www.polevaultweb.com/2014/04/will-wordpress-plugin-business-killer/" href="http://www.polevaultweb.com/2014/04/will-wordpress-plugin-business-killer/">Will WordPress be a Plugin Business Killer?</a> The post is based on the idea that features from a commercial plugin added to WordPress could kill the business based on that plugin.</p>
<p>The short answer to Poulson&#8217;s question is <strong>no</strong>. Here&#8217;s why.</p>
<h3>WordPress Needs To Be Generic</h3>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2009/08/gravitylogo.png" rel="prettyphoto[21735]"><img class="alignright size-full wp-image-2322" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2009/08/gravitylogo.png?resize=108%2C109" alt="gravityforms logo" /></a>WordPress serves a huge audience. Commercial plugins usually address a specific niche and hammer away at it with features and functionality. It wouldn&#8217;t make sense to take GravityForms or Backup Buddy and merge them into WordPress because those plugins are not generic enough to cover a wide audience.</p>
<p>Even if a GravityForms were to merge into core, it would likely be stripped of its niche focused functionality and probably be rewritten. It would be stripped to a point of basic functionality to cover the majority of WordPress users. GravityForms would likely continue to exist as a successful commercial plugin since it would contain features that didn&#8217;t make it to the core of WordPress.</p>
<h3>Don&#8217;t Sell Features, Sell Products</h3>
<p>Within the comments of the article, Carl Hancock of RocketGenius <a title="http://www.polevaultweb.com/2014/04/will-wordpress-plugin-business-killer/#comment-1352082767" href="http://www.polevaultweb.com/2014/04/will-wordpress-plugin-business-killer/#comment-1352082767">made a great point</a> when he said:</p>
<blockquote><p>To me a viable commercial product is just that. A product. Not a feature. If something is more of a feature, then unless it&#8217;s part of a collection of offerings it could be dicey to rely on it as a commercial plugin. Features aren&#8217;t products.</p></blockquote>
<p>I agree. Commercial plugins that are just glorified features are more at risk of being added to core than full-fledged products. Regardless of either camp, merging existing plugins into core is not a routine task. Outside of the features as plugins first model, it rarely happens.</p>
<p>I don&#8217;t think commercial plugin author needs to worry. Is it a possibility worth considering? Definitely, but it&#8217;s one of those thoughts that should be in the back of your mind, not the forefront.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 24 Apr 2014 21:46:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WPTavern: Take the WordPress Contributor Experience Survey";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21701";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:160:"http://wptavern.com/take-the-wordpress-contributor-experience-survey?utm_source=rss&utm_medium=rss&utm_campaign=take-the-wordpress-contributor-experience-survey";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4205:"<div id="attachment_21721" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/we.jpg" rel="prettyphoto[21701]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/we.jpg?resize=1024%2C474" alt="photo credit:  - cc license" class="size-full wp-image-21721" /></a><p class="wp-caption-text">photo credit: <a href="https://flic.kr/p/mkLUc">23rdian</a> &#8211; <a href="https://creativecommons.org/licenses/by-nc/2.0/">cc</a> license</p></div>
<p>If you&#8217;ve ever contributed to the WordPress project, whether through code, documentation, plugins and themes, speaking at a WordCamp, etc., your feedback is requested on the WordPress <a href="http://wordpressdotorg.polldaddy.com/s/wordpress-contributor-experience-poll" target="_blank">Contributor Experience Survey</a>.  Jen Mylo <a href="http://make.wordpress.org/community/2014/04/24/contributor-experience-survey/" target="_blank">announced</a> the survey today, noting that none of the questions are mandatory.</p>
<p>One of the questions in the survey asks: <strong>&#8220;What can the WordPress project do to make current contributors feel valued?&#8221;</strong> Since the vast majority of community contributions to the project are done on a volunteer basis, the project is seeking feedback for recognizing and valuing those efforts.</p>
<p>Recent and continued <a href="http://wptavern.com/wordpress-org-profile-redesign-is-live" target="_blank">improvements to WordPress.org profiles</a> present a more accurate representation of a user&#8217;s involvement in the project and recognize users with badges that denote contributions to code, plugins, themes, WordCamps, as well as active participation in the groups listed on <a href="http://make.wordpress.org/" target="_blank">make.wordpress.org</a>. Do these badges resonate with contributors or are there more creative ways that the project can help them feel valued?</p>
<h3>Helping New Contributors Feel Welcome and Encouraged</h3>
<p>Another important question on the survey asks what the WordPress project can do better to make new contributors feel welcome and encouraged. Getting a better handle on this could potentially help the project expand its contributor base and move forward at a faster rate. This past year WordPress has launched several new initiatives targeted at improving new contributors&#8217; experiences.</p>
<p>Recent <a href="http://wptavern.com/wordpress-core-trac-gets-a-design-refresh-new-features-and-enhancements" target="_blank">updates to WordPress core trac</a>, as well as the <a href="http://make.wordpress.org/core/2014/01/27/proposed-trac-component-reorganization/" target="_blank">components reorganization</a>, have gone a long way toward helping contributors to specialize and stay informed on selected tickets. The addition of the <a href="https://core.trac.wordpress.org/query?keywords=~good-first-bug" target="_blank">“good-first-bug”</a> keyword helps to streamline areas where new contributors might get their feet wet.</p>
<p>In addition to helping new code contributors, the <a href="http://make.wordpress.org/community/author/andreamiddleton/" target="_blank">WordCamp Organizer Hangouts</a> have been instrumental in getting new organizers oriented with the responsibilities of leading an event. A <a href="http://make.wordpress.org/docs/2014/02/25/docs-issue-tracker/" target="_blank">preliminary version</a> of a new <a href="http://wptavern.com/coming-soon-an-issues-tracker-for-wordpress-documentation" target="_blank">issues tracker for WordPress documentation</a> was recently launched and will be refined to help documentation contributors work together more efficiently. However, there are many more areas where contributors might jump in that have not yet been optimized for newcomers.</p>
<p>The survey asks for feedback on user experiences contributing to the project, both positive and negative. If you have any thoughts on how WordPress can improve these experiences, take a few minutes to communicate your feedback via the <a href="http://wordpressdotorg.polldaddy.com/s/wordpress-contributor-experience-poll" target="_blank">Contributor Experience Survey</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 24 Apr 2014 18:23:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:79:"WPTavern: Read Where You Write In WordPress With The Orbital Feed Reader Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=20779";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:202:"http://wptavern.com/read-where-you-write-in-wordpress-with-the-orbital-feed-reader-plugin?utm_source=rss&utm_medium=rss&utm_campaign=read-where-you-write-in-wordpress-with-the-orbital-feed-reader-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3366:"<p>When <a title="http://googlereader.blogspot.com/2013/07/a-final-farewell.html" href="http://googlereader.blogspot.com/2013/07/a-final-farewell.html">Google Reader was shut down</a> on July 2nd, 2013, those who use RSS searched far and wide for suitable replacements. I&#8217;ve settled on using <a title="http://feedly.com/" href="http://feedly.com/">Feedly </a>for my needs. However, there is a plugin available that adds an RSS reader to WordPress so you can create blog posts as you read RSS feeds from within the same interface. It&#8217;s called <a title="http://wordpress.org/plugins/orbital-feed-reader/" href="http://wordpress.org/plugins/orbital-feed-reader/">Orbital Feed Reader</a> and is available on the WordPress plugin directory.</p>
<div id="attachment_21690" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/FeedsWithinOrbitalFeedReader.png" rel="prettyphoto[20779]"><img class="size-full wp-image-21690" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/FeedsWithinOrbitalFeedReader.png?resize=1025%2C559" alt="My Feeds Within Orbital Feed Reader" /></a><p class="wp-caption-text">My Feeds Within Orbital Feed Reader</p></div>
<p>By default, Orbital is subscribed to a few different feeds to get you started. The design of the interface is a far cry from what I&#8217;m use to with Feedly. Because of the way content from feeds are displayed, it&#8217;s hard to determine when posts begin and end. The way the content is displayed makes it hard to decipher, especially if the content contains a lot of images.</p>
<p>If you can get past those setbacks, the feed reader performs as advertised. At the end of each article is a Blog This button. Clicking the button opens up the Press This bookmarklet enabling you to quickly post content to your site. Any text that is highlighted within the article before the button is selected will automatically be shown in the content area of the <a title="http://codex.wordpress.org/Press_This" href="http://codex.wordpress.org/Press_This">Press This bookmarklet</a>. Being able to read feeds and quickly publish articles to a blog is a nice convenience.</p>
<p>You can add feeds either by importing an OPML file or by using a site&#8217;s RSS feed URL.</p>
<div id="attachment_21691" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/OrbitalHowToAddFeeds.png" rel="prettyphoto[20779]"><img class="size-full wp-image-21691" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/OrbitalHowToAddFeeds.png?resize=542%2C208" alt="How To Add Feeds In Orbital" /></a><p class="wp-caption-text">How To Add Feeds In Orbital</p></div>
<h3>I&#8217;m Sticking With Feedly</h3>
<p>Although I don&#8217;t use my feed reader as much as I used to, I prefer Feedly over Orbital because of the synching options between the web and mobile versions of the service. Feedly also displays content in a way that makes it easier to read compared to Orbital. Last but not least, I have the Press This bookmarklet installed in FireFox so I can blog stories from anywhere on the web.</p>
<p>With that said, the plugin&#8217;s purpose is to enable users to read RSS feeds and easily create blog content from within the same interface. It&#8217;s the plugin&#8217;s shining feature and it does so without any problems.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 24 Apr 2014 17:42:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:42:"WPTavern: ThemeLab Acquired By Syed Balkhi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=19860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:128:"http://wptavern.com/themelab-acquired-by-syed-balkhi?utm_source=rss&utm_medium=rss&utm_campaign=themelab-acquired-by-syed-balkhi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3938:"<p><a title="https://www.themelab.com/" href="https://www.themelab.com/">ThemeLab</a>, a popular site dedicated to WordPress theme topics has been acquired by <a title="http://www.balkhis.com/" href="http://www.balkhis.com/">Syed Balkhi</a>. ThemeLab has been a valuable resource of information since 2007. Leland Fiegel, the site&#8217;s previous owner made a positive mark within the community <a title="http://www.themelab.com/stop-downloading-wordpress-themes-from-shady-sites/" href="http://www.themelab.com/stop-downloading-wordpress-themes-from-shady-sites/">when he published an in-depth post</a> explaining why users shouldn&#8217;t download and use themes from shady sites discovered in Google.</p>
<div id="attachment_19876" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/03/ThemeLabShadySites.gif" rel="prettyphoto[19860]"><img class="size-large wp-image-19876" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/03/ThemeLabShadySites.gif?resize=500%2C265" alt="Don\'t Download Themes From Shady Sites" /></a><p class="wp-caption-text">Don&#8217;t Download Themes From Shady Sites</p></div>
<p>According to the <a title="https://www.themelab.com/about-us/" href="https://www.themelab.com/about-us/">about page</a>, the acquisition took place in 2013. During the time of acquisition, Balkhi and his team have revamped the site and turned it into a commercial theme shop. The site&#8217;s mission statement fits in with a trend we&#8217;ve noticed with commercial themes in general: &#8220;While most companies are focused on either design or functionality, our approach is to bring the best of both worlds with a special emphasis on usability.&#8221;</p>
<blockquote><p>As a WordPress user watching from the sidelines, I’ve noticed that themes have become extremely complex over the last several years. The race to add more features, more options, more shortcodes, and more of everything has led developers to lose sight of what’s more important: <strong>usability</strong>.</p>
<p>Beginners who are just starting out no longer find WordPress to be easy. A lot of this has to do with themes because that’s their first encounter. Having to go through 600 options just to get the theme to look like the demo is beyond silly.</p></blockquote>
<p>All of the free themes released on ThemeLab have been retired and are no longer available for download. Tutorials published by Fiegel will be updated as necessary with new ones on the way.</p>
<h3>What&#8217;s Next For Fiegel?</h3>
<p>ThemeLab has been an excellent resource of information within the WordPress community over the years. It&#8217;s awesome to see Fiegel has found the right buyer with the right price. In a <a title="http://leland.me/six-years-of-theme-lab/" href="http://leland.me/six-years-of-theme-lab/">detailed post on his personal blog</a>, Fiegel explains what the past six years have been like running ThemeLab as well the lessons he learned.</p>
<p>His next endeavor is called <a title="http://pluginferno.com/" href="http://pluginferno.com/">Pluginferno</a> and focuses on commercial plugins for WordPress, addons for existing popular plugins, plugin reviews, and commentary about the WordPress community in general.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/Testing.png" rel="prettyphoto[19860]"><img class="aligncenter size-full wp-image-21672" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/Testing.png?resize=1025%2C772" alt="Testing" /></a></p>
<p>He&#8217;ll also be entering the commercial theme market through <a title="http://powertheme.com/" href="http://powertheme.com/">PowerTheme</a>. There&#8217;s not a lot of information about the site but it will sell 100% GPL licensed themes. Both sites give Fiegel a fresh start. The lessons learned from running ThemeLab should make it easier for his new endeavors to be financially successful.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 23 Apr 2014 21:41:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WPTavern: Have You Turned On Akismet 3.0′s Silent Discard Feature?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21649";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:172:"http://wptavern.com/have-you-turned-on-akismet-3-0s-silent-discard-feature?utm_source=rss&utm_medium=rss&utm_campaign=have-you-turned-on-akismet-3-0s-silent-discard-feature";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3926:"<p><a href="http://wordpress.org/plugins/akismet/" target="_blank">Akismet</a> is one of those quiet utility plugins that works in the background of your WordPress site without a lot of fanfare. When it&#8217;s doing it&#8217;s job, your blog comments stay spam-free and you never think twice about it. Forgetting to activate Akismet on a new site will quickly remind you of just how much spam is targeted at WordPress sites.</p>
<p><a href="http://blog.akismet.com/2014/04/15/akismet-3-0-0/" target="_blank">Akismet 3.0</a> is a major rewrite of the plugin that improves its efficiency in handling the worst spam that hits your site. When you visit your Akismet settings you&#8217;ll see how many days of your life Akismet has saved you as well as some new stats and graphs demonstrating the plugin&#8217;s effectiveness. Here&#8217;s an example from a small, personal blog:</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/akismet-settings.jpg" rel="prettyphoto[21649]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/akismet-settings.jpg?resize=795%2C545" alt="akismet-settings" class="aligncenter size-full wp-image-21659" /></a></p>
<h3>Akismet 3.0&#8242;s Silent Discard Feature Improves Performance</h3>
<p>In addition to an easier signup and configuration process, this version introduced a silent discard feature that identifies and outright blocks the worst spam comments.</p>
<p>Throughout the course of improving Akismet, the team found that approximately 80% of spam is so bad that it could be flagged as “pervasive.” The silent discard feature causes pervasive spam to bypass the spam folder entirely so that you&#8217;ll never see it.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/akismet-discard-spam-feature.png" rel="prettyphoto[21649]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/akismet-discard-spam-feature.png?resize=697%2C116" alt="akismet-discard-spam-feature" class="aligncenter size-full wp-image-21657" /></a></p>
<p>The plugin previously had a relatively ineffective option that allowed site owners the ability to automatically discard spam on older posts. This didn&#8217;t do much to block the worst spam and users found it to be confusing.</p>
<p>Akismet 3.0 remembers your selections for this previous feature and applies them to the new silent discard feature. In most cases this means that the silent discard will be automatically turned on when you update the plugin. For users who are new to Akismet, the default setting is to store the pervasive spam in the spam folder for 15 days. The silent discard feature will need to be turned on from the plugin&#8217;s configuration page.</p>
<p>There are some very compelling reasons to turn this new feature on. When <a href="http://blog.akismet.com/2014/04/23/theres-a-ninja-in-your-akismet/" target="_blank">announcing</a> the silent discard option, the folks at Akismet said that <strong>&#8220;enabling the feature can result in significant reductions in your storage and resource usage requirements.&#8221;</strong> This is especially true on sites that are always publishing new content. Silently discarding the most pervasive spam, instead of storing all of it for 15 days, frees up the storage and resources required to display and manage those spam comments in the admin.</p>
<p>Akismet has zapped more than 135 billion spam comments and track backs to date, and the service is getting smarter at defeating the worst spam. The most important spam-fighting feature of 3.0 is the ability to silently discard pervasive spam before it even has the chance to land on your doorstop and get logged in your database. Turning this option on is a no-brainer. If you haven&#8217;t yet updated your plugins or have been waiting to update to WordPress 3.9, Akismet 3.0&#8242;s silent discard feature is another reason to get moving on those updates.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 23 Apr 2014 21:04:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:81:"WPTavern: Tweet Archive: A Free WordPress Theme to Match the New Twitter Profiles";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21511";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:204:"http://wptavern.com/tweet-archive-a-free-wordpress-theme-to-match-the-new-twitter-profiles?utm_source=rss&utm_medium=rss&utm_campaign=tweet-archive-a-free-wordpress-theme-to-match-the-new-twitter-profiles";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3922:"<p>Yesterday, Twitter <a href="https://blog.twitter.com/2014/your-new-web-profile-is-here" target="_blank">announced</a> that it was rolling out the new profile redesign to all users. If you haven&#8217;t updated your Twitter profile, you can click on the &#8220;Get it Now&#8221; button on the <a href="https://about.twitter.com/products/new-profiles" target="_blank">new profiles product page</a>.</p>
<p>Last week we featured <a href="http://wptavern.com/ozh-tweet-archiver-2-0-backs-up-your-tweets-to-wordpress" target="_blank">Ozh’ Tweet Archiver</a> as an easy way to archive your tweets to WordPress. The 2.0 version of the plugin has been updated to work with Twitter’s OAuth API and 2.0.1 has support for post formats, thanks to a contribution from <a href="http://wptavern.com/ozh-tweet-archiver-2-0-backs-up-your-tweets-to-wordpress#comment-54394" target="_blank">Chip Bennett</a>. Ozh also updated the Tweet Archive WordPress theme that accompanies the plugin in order to more closely match Twitter&#8217;s new profile design.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/tweet-archiver-theme.jpg" rel="prettyphoto[21511]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/tweet-archiver-theme.jpg?resize=1025%2C589" alt="tweet-archiver-theme" class="aligncenter size-full wp-image-21624" /></a></p>
<p>You can view a <a href="http://planetozh.com/tweets/" target="_blank">live demo</a> on Ozh&#8217;s tweet archive site. He created the theme for his own use so you&#8217;ll need to edit a few files to personalize it. It was designed to work in combination with the plugin, so the top bar displaying total tweets, following, and followers only works with the plugin installed. The theme utilizes Font Awesome icons within the tweet archive and social accounts display. It also has support for a sidebar which you can use to allow easy browsing of archived tweets, stats, hashtags, or anything you wish.</p>
<p>All of the user info in the left column can be customized in the <em>header.php</em> file as well as the avatar. The header image can be changed in <em>style.css</em>. It would be cool if the theme was updated to use WordPress&#8217; custom header feature, but it wasn&#8217;t really created for distribution. Ozh has the project open to contribution, however, if anyone is interested in refining the theme.</p>
<h3>Use Your WordPress-Powered Twitter Archive to Boost Traffic</h3>
<p>Tweet Archive includes a search bar within the header, since WordPress&#8217; search feature is much easier to use when looking for specific content within your tweets. Ryan Hellyer, who has his tweets backed up to a subdomain, <a href="http://wptavern.com/ozh-tweet-archiver-2-0-backs-up-your-tweets-to-wordpress#comment-54142" target="_blank">commented</a> on our previous post, highlighting another merit to hosting your own archive:</p>
<blockquote><p>Another unexpected benefit, is that I actually get traffic from it. Google seems to preferentially send traffic my way instead of to Twitter itself sometimes.</p></blockquote>
<p>If you&#8217;re getting extra traffic from hosting your own Twitter archive, you may want to make use of Twitter&#8217;s new pinned tweet feature. This should be easy to accomplish in your archive with WordPress&#8217; built-in sticky posts and a little bit of CSS to make it a larger entry. That way, when visitors land on your archive, they will see your curated favorites at the top of the list.</p>
<p>If you&#8217;re using the <a href="http://wordpress.org/plugins/ozh-tweet-archiver/" target="_blank">Ozh Tweet Archiver plugin</a> to automatically archive your tweets to WordPress and you want a theme that will approximate the new Twitter design, grab the <a href="https://github.com/ozh/ozh-tweet-archive-theme" target="_blank">Tweet Archive WordPress theme</a> on Github and customize it to match your Twitter profile.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 23 Apr 2014 18:20:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:42:"Akismet: There’s a Ninja in Your Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.akismet.com/?p=1351";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://blog.akismet.com/2014/04/23/theres-a-ninja-in-your-akismet/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2910:"<p>One of our favorite additions to <a href="http://blog.akismet.com/2014/04/15/akismet-3-0-0/">Akismet 3.0</a> is the new discard setting. Previously, our plugin featured an option that allowed site owners the ability to automatically discard spam on older posts. But, as some may certainly agree, it was rather confusing and had little effect on the world&#8217;s smarter spammers.</p>
<p>After giving thought to how we could improve that particular setting and the overall user experience, we found that approximately 80% of spam could be flagged as &#8220;pervasive&#8221;, meaning that it is the absolute worst of the worst (of the worst!). In fact, that 80% is so bad that there is simply no benefit in paying any attention to it at all. Not even for kicks and giggles. Trust us.</p>
<p>We came up with something that would allow you to automatically and silently discard all of that pervasive spam attacking your site so that it never even appears in your &#8220;Spam&#8221; folder. The new setting identifies the <strong>worst and most pervasive</strong> spam (which can certainly change over time) on our side during the comment check and will immediately discard it if you&#8217;ve configured the plugin to do so. </p>
<p>If you&#8217;re new to Akismet, these spam comments will be stored by default; you must activate the new feature from the plugin&#8217;s configuration page (if you upgraded to 3.0, Akismet will use the previous value of your 30-day discard setting) :</p>
<p><a href="http://akismet.files.wordpress.com/2014/04/akismet-discard-spam-feature.png"><img src="http://akismet.files.wordpress.com/2014/04/akismet-discard-spam-feature.png?w=640&h=106" alt="Akismet Discard Spam Feature" width="640" height="106" class="alignnone size-large wp-image-1376" /></a></p>
<p>It&#8217;s all very ninja-esque, we think. What&#8217;s more, enabling the feature can result in significant reductions in your storage and resource usage requirements.</p>
<p>This is a great step forward in our mission to make the web a cleaner place. We tested the feature on <a href="http://wordpress.com/">WordPress.com</a> and received excellent results and feedback prior to rolling it into the plugin. So, we think (and hope) you&#8217;ll enjoy it. We are also working on an enhancement to the feature, which will highlight the pervasive spam comments in the &#8220;Spam&#8221; folder for users who choose to store them.</p>
<p>If you have any feedback on the new feature, we would love to <a href="http://akismet.com/contact/">hear from you</a>.</p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1351/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1351/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=blog.akismet.com&blog=116920&post=1351&subd=akismet&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 23 Apr 2014 13:09:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Anthony Bubel";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WPTavern: New Plugin Adds Less CSS Preprocessor to WordPress Themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21533";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:178:"http://wptavern.com/new-plugin-adds-less-css-preprocessor-to-wordpress-themes?utm_source=rss&utm_medium=rss&utm_campaign=new-plugin-adds-less-css-preprocessor-to-wordpress-themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3374:"<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/less-theme-support.jpg" rel="prettyphoto[21533]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/less-theme-support.jpg?resize=772%2C250" alt="less-theme-support" class="aligncenter size-full wp-image-21583" /></a></p>
<p>Many WordPress developers opt to use the <a href="http://lesscss.org/" target="_blank">Less</a> CSS preprocessor to speed up theme development. Its availability of variables, mixins, and functions allows you to do more with CSS and to do it more efficiently. It also makes it easy to compile and minify files for production use. However, the initial setup for adding Less to each theme is a somewhat time-consuming process.</p>
<p>Justin Kopepasah wrote a tutorial in the past for <a href="http://kopepasah.com/tutorial/using-less-in-a-live-wordpress-theme/" target="_blank">using LESS in a live WordPress theme</a>, followed by one that <a href="http://kopepasah.com/tutorial/easily-add-less-css-pre-processor-to-any-wordpress-theme/" target="_blank">automated the process</a> by setting up the functionality as a Git submodule. Over time, he found that adding Less to each theme was becoming quite a chore, so he created a plugin to make the process easier for anyone.</p>
<p>Kopepasah&#8217;s <a href="https://wordpress.org/plugins/less-theme-support/" target="_blank">Less Theme Support</a> plugin radically simplifies the process of adding Less to your WordPress theme. It requires just two simple steps following activation:</p>
<ol>
<li>Add <em>style.less</em> to your theme&#8217;s root directory</li>
<li>Add theme support to the after_setup_theme hook:
<pre class="brush: php; light: true; title: ; notranslate">add_theme_support( \'less\', array( \'enable\' =&gt; true ) );</pre>
</li>
</ol>
<p>Less Theme Support comes with four different options which change how it functions on development vs. production sites. All are boolean values defaulting to false:</p>
<ul>
<li><strong>enable</strong> – Enables Less and enqueues <em>less.min.js</em> on the front end.</li>
<li><strong>develop</strong> – Enables development environment for Less and enqueues <em>less-develop.js</em>.</li>
<li><strong>watch</strong> – Enables watch mode for Less and enqueues <em>less-watch.js</em>.</li>
<li><strong>minify</strong> – Enables usage of a minified stylesheet (<em>style.min.css</em>) on the front end for all other visitors (best generated using lessc -x style.less > style.min.css).</li>
</ul>
<p>These options give you quite a bit of flexibility. For example, during development you might configure your theme support with the enable, develop, and watch options:</p>
<pre class="brush: php; title: ; notranslate">add_theme_support( \'less\', array(
    \'enable\'  =&gt; true,
    \'develop\' =&gt; true,
    \'watch\'  =&gt; true
) );</pre>
<p>Less theme support in production would us the minify option:</p>
<pre class="brush: php; title: ; notranslate">add_theme_support( \'less\', array(
 \'minify\' =&gt; true
) );</pre>
<p>Using the <a href="https://wordpress.org/plugins/less-theme-support/" target="_blank">Less Theme Support</a> plugin provides a much cleaner and easier way to add Less to your theme. Download it from WordPress.org or via the project&#8217;s page on <a href="https://github.com/kopepasah/less-theme-support" target="_blank">Github</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 22 Apr 2014 21:49:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:83:"WPTavern: Display Before and After Images In WordPress With The TwentyTwenty Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=20955";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:210:"http://wptavern.com/display-before-and-after-images-in-wordpress-with-the-twentytwenty-plugin?utm_source=rss&utm_medium=rss&utm_campaign=display-before-and-after-images-in-wordpress-with-the-twentytwenty-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4181:"<p>Have you ever wanted to combine two images to show a before and after? You can&#8217;t do that with WordPress out of the box but it&#8217;s possible if you use the <a title="http://wordpress.org/plugins/twentytwenty/" href="http://wordpress.org/plugins/twentytwenty/">TwentyTwenty plugin</a> by <a title="http://aspiringwebdev.com/" href="http://aspiringwebdev.com/">Corey Martin</a>. The plugin takes advantage of the <a title="http://www.w3schools.com/cssref/pr_pos_clip.asp" href="http://www.w3schools.com/cssref/pr_pos_clip.asp">clip property</a> within CSS by stacking two identical sized images on top of each other. The clip property allows the image to show through the container. The slider is responsive and uses custom movement events within the <a title="https://github.com/stephband/jquery.event.move" href="https://github.com/stephband/jquery.event.move">jQuery Event Move library</a> to support <strong>1:1</strong> slider movement on mobile devices.</p>
<p>The plugin is very simple to use. Upload two identical sized images to the media library. When inserting images into a post, make sure the attachment display settings for image size are the same. Add the <strong>[TwentyTwenty]</strong> shortcode above the before image. Add <strong>[/TwentyTwenty]</strong> after the second image. Here&#8217;s an example of the shortcode added to a post.</p>
<div id="attachment_21585" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/TwentyTwentyShortcode.png" rel="prettyphoto[20955]"><img class="size-full wp-image-21585" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/TwentyTwentyShortcode.png?resize=754%2C703" alt="TwentyTwenty Shortcode In Action" /></a><p class="wp-caption-text">TwentyTwenty Shortcode In Action</p></div>
<p>The shortcode generates a slider that can be moved back and forth. You&#8217;ll see which images are before and after when you hover over the slider. To see either image, users must click and drag the circle left or right.</p>
<div id="attachment_21588" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/TwentyTwentyBefore.png" rel="prettyphoto[20955]"><img class="size-full wp-image-21588" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/TwentyTwentyBefore.png?resize=650%2C200" alt="TwentyTwenty Before Image" /></a><p class="wp-caption-text">TwentyTwenty Before Image</p></div>
<div id="attachment_21587" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/TwentyTwentyAfter.png" rel="prettyphoto[20955]"><img class="size-full wp-image-21587" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/TwentyTwentyAfter.png?resize=650%2C200" alt="TwentyTwenty After Image" /></a><p class="wp-caption-text">TwentyTwenty After Image</p></div>
<p>The plugin was written using <a title="http://sass-lang.com/" href="http://sass-lang.com/">Sass</a> and Zurb.com has a <a title="http://zurb.com/playground/twentytwenty" href="http://zurb.com/playground/twentytwenty">listing of each Sass variable</a> used and what its default value is. The variables enable you to control everything from the handle color to the handle radius.</p>
<p>Here are a couple of ideas where TwentyTwenty would be ideal to use.</p>
<ul>
<li>Compare counterfeit merchandise to real merchandise</li>
<li>Website redesigns</li>
<li>Home improvement renovations</li>
</ul>
<p>During my test with WordPress 3.9, I didn&#8217;t experience any problems. According to Martin, <a title="http://wordpress.org/support/plugin/twentytwenty" href="http://wordpress.org/support/plugin/twentytwenty">TwentyTwenty</a> is compatible with the latest versions of Chrome, Safari, FireFox, iOS, IE 9, and above. If you want to see the plugin in action, you can either watch this screencast by Martin or visit the <a title="http://zurb.com/playground/twentytwenty" href="http://zurb.com/playground/twentytwenty">plugin&#8217;s page on Zurb.com</a>.</p>
<p><span class="embed-youtube"></span></p>
<p><strong>Outside of showing before and after images, what other creative ways could this plugin be used?</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 22 Apr 2014 21:20:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:45:"WPTavern: WordPress 3.9 Adds 30 New Dashicons";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21545";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:134:"http://wptavern.com/wordpress-3-9-adds-30-new-dashicons?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-3-9-adds-30-new-dashicons";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1541:"<p><a title="http://melchoyce.github.io/dashicons/" href="http://melchoyce.github.io/dashicons/">Dashicons</a> are what’s known as an icon font and were added to the core of WordPress with the release of 3.8. The icons are vector based so they can be as large or small as you want without losing quality. Plugin authors can use CSS, HTML, or a Glyph for use within Photoshop to display an icon. While 3.8 had 167 icons, WordPress 3.9 shipped with <a title="http://make.wordpress.org/core/2014/04/16/dashicons-in-wordpress-3-9/" href="http://make.wordpress.org/core/2014/04/16/dashicons-in-wordpress-3-9/">30 new Dashicons</a> bringing the total to 197.</p>
<div id="attachment_21547" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/WP39Dashicons.png" rel="prettyphoto[21545]"><img class="size-full wp-image-21547" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/WP39Dashicons.png?resize=652%2C313" alt="New Dashicons In WordPress 3.9" /></a><p class="wp-caption-text">New Dashicons In WordPress 3.9</p></div>
<p>The icons cover Media, TinyMCE, WordPress.org, Sorting, Widgets, Alerts, and Miscellaneous. Some plugin authors have already opted out of using a bitmap image and are using a Dashicon to represent their plugin within the WordPress admin menu. If none of the Dashicons match your use case, try <a title="http://genericons.com" href="http://genericons.com">Genericons</a> instead. Genereicons is also an icon font but has icons that are not focused on WordPress.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 22 Apr 2014 19:37:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"WPTavern: Automattic Introduces Postbot App for Scheduling Photo Posts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21535";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:184:"http://wptavern.com/automattic-introduces-postbot-app-for-scheduling-photo-posts?utm_source=rss&utm_medium=rss&utm_campaign=automattic-introduces-postbot-app-for-scheduling-photo-posts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4368:"<p>Today Automattic introduced <a href="https://postbot.co/" target="_blank">Postbot</a>, a new stand-alone application for scheduling image posts. The new app allows users to upload multiple images and schedule them out over several days. Postbot creates a post for each image and automatically posts them to the selected blog, saving users the trouble of manually scheduling each one.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/postbot.gif" rel="prettyphoto[21535]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/postbot.gif?resize=752%2C376" alt="postbot" class="aligncenter size-full wp-image-21539" /></a></p>
<p>When using <a href="https://postbot.co/">Postbot</a>, you&#8217;ll need to connect via WordPress.com. The app is automatically connected to your main WordPress.com blog but once logged in you&#8217;ll have the option to connect other sites. Self-hosted WordPress sites can use the app via <a href="http://jetpack.me/" target="_blank">Jetpack</a> with the <a href="http://jetpack.me/support/json-api/" target="_blank">JSON API module</a> enabled.</p>
<p>Right now, you can only use the app from a desktop or mobile browser and John Godley, representing Automattic, says that a mobile app is not currently in the works. He elaborated on why they chose to create it as a standalone web app:</p>
<blockquote><p>Postbot lets us provide a very targeted set of features to anyone with a WordPress.com or WordPress.org/Jetpack blog (or both), from one central place. It’s already mobile-ready so a special mobile app isn&#8217;t currently planned.</p></blockquote>
<p>The experience of visiting <a href="https://postbot.co/" target="_blank">Postbot.co</a> from a mobile browser is not unlike using a mobile app. Those who plan to use it frequently via mobile can easily set a bookmark for quick launch while on the go.</p>
<h3>Postbot Puts Photo Publishing on Autopilot</h3>
<p>Postbot allows you to upload up to 50 photos at once to be published individually on different dates. While the images are uploading you can edit the titles, tags and content for each. The option to set a category is planned for a future version.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/uploading-postbot.png" rel="prettyphoto[21535]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/uploading-postbot.png?resize=688%2C311" alt="uploading-postbot" class="aligncenter size-full wp-image-21550" /></a></p>
<p>Scheduling allows you to set the number of days between posts published with the option to ignore weekends.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/schedule_postbot.png" rel="prettyphoto[21535]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/schedule_postbot.png?resize=635%2C42" alt="schedule_postbot" class="aligncenter size-full wp-image-21551" /></a></p>
<p>The app doesn&#8217;t yet allow you to set the featured image, but it&#8217;s on Automattic&#8217;s list of <a href="https://github.com/Automattic/Postbot/issues/6" target="_blank">feature requests</a> for future enhancements.</p>
<p>Postbot is an excellent example of the kinds of apps that can be created using the <a href="http://developer.wordpress.com/docs/api/" target="_blank">WordPress.com API</a>. If you want to take a peek under the hood, the app&#8217;s code was released under the GPL and can be found on <a href="https://github.com/Automattic/Postbot" target="_blank">Github</a>. This means that anyone can host their own Postbot web app or create interesting variations that interact with WordPress.com services.</p>
<p>Postbot is potentially very useful for photobloggers who want to break up their posts into individual images. It could also be handy for automating sites that are dedicated to publishing photos every day, i.e. &#8220;The Daily Kitten&#8221; or &#8220;Your Daily Dose of Fun.&#8221; It allows these kinds of sites to go on autopilot for publishing fresh content on a regular basis. Publishing new posts multiple times per day is an option <a href="http://en.blog.wordpress.com/2014/04/22/postbot-scheduled-photos/#comment-202397" target="_blank">currently under consideration</a> and may be a possibility in the future. We&#8217;ll be following the app&#8217;s progress as it adds new features based on user feedback.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 22 Apr 2014 19:17:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"Mike Little: Apologies for the old posts.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=2023";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:147:"http://journalized.zed1.com/archives/2014/04/22/apologies-for-the-old-posts/?utm_source=rss&utm_medium=rss&utm_campaign=apologies-for-the-old-posts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:598:"<p>Folks, it looks like when I moved this old blog from a subdirectory to a subdomain, <a href="http://planet.wordpress.org">planet.wordpress.org</a> (the feed that shows up in your dashboard) thought my last few old posts were new. Hence a lot of old stuff appeared in your dashboard.</p>
<p>Sorry for the confusion&#8230;</p>
<p>Mike</p>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2014/04/22/apologies-for-the-old-posts/">Apologies for the old posts.</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 22 Apr 2014 14:36:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:90:"WPTavern: How The Advanced Image Editing Properties Contributed To WordPress Theme Lock-in";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21488";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:224:"http://wptavern.com/how-the-advanced-image-editing-properties-contributed-to-wordpress-theme-lock-in?utm_source=rss&utm_medium=rss&utm_campaign=how-the-advanced-image-editing-properties-contributed-to-wordpress-theme-lock-in";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6280:"<p>Although <a title="http://wptavern.com/wordpress-3-9-smith-released" href="http://wptavern.com/wordpress-3-9-smith-released">WordPress 3.9</a> has refined the media editing experience, it did so at the cost of removing a feature users appreciated. In WordPress 3.8, users could easily add a border, vertical, and horizontal padding to images. WordPress 3.9 removed this from the advanced image settings screen.</p>
<p>It’s not just those who use the self-hosted version of WordPress <a title="http://wordpress.org/support/topic/major-problems-with-image-editing-in-wp-39?replies=12" href="http://wordpress.org/support/topic/major-problems-with-image-editing-in-wp-39?replies=12">that are upset with the change</a>. A WordPress.com <a title="http://en.forums.wordpress.com/topic/image-resize-1?replies=430" href="http://en.forums.wordpress.com/topic/image-resize-1?replies=430">support forum thread</a> with over 430 posts is filled with users asking why the feature was removed. In some cases, WordPress.com staff are explaining how to use HTML code to add or remove borders to images.</p>
<p>Thankfully, there&#8217;s a new plugin available that not only restores the original advanced image settings but has expanded upon them. The plugin is called <a title="http://wordpress.org/plugins/advanced-image-styles/" href="http://wordpress.org/plugins/advanced-image-styles/">Advanced Image Styles</a> and is maintained by <a title="http://profiles.wordpress.org/gcorne/" href="http://profiles.wordpress.org/gcorne/">Gregory Cornelius</a>. As you can see, users can now apply padding in all four directions instead of two. You can also apply a border color instead of just the border width.</p>
<div id="attachment_21489" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/AdvancedImageEditingOptions.png" rel="prettyphoto[21488]"><img class="size-full wp-image-21489" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/AdvancedImageEditingOptions.png?resize=840%2C401" alt="Advanced Image Editing Styles" /></a><p class="wp-caption-text">Advanced Image Styles</p></div>
<p><a title="http://wordpress.org/support/view/plugin-reviews/advanced-image-styles" href="http://wordpress.org/support/view/plugin-reviews/advanced-image-styles">Early reviews</a> indicate users are happy to see these options return despite having to use a plugin. Unfortunately, those on WordPress.com are still out of luck. A member of the WordPress.com staff says <a title="http://en.forums.wordpress.com/topic/image-resize-1/page/15?replies=430#post-1754610" href="http://en.forums.wordpress.com/topic/image-resize-1/page/15?replies=430#post-1754610">it&#8217;s possible</a> the plugin will be merged into the WordPress.com codebase.</p>
<blockquote><p>I have asked the developers if this will be merged. At the moment I have not heard back. I will let you know as soon as possible!</p></blockquote>
<h3>These Options Are Causing Theme Lock-in</h3>
<p>If themes are coded to properly handle image padding and borders, the options within WordPress are redundant and unnecessary. What&#8217;s troubling is users are utilizing these options to override the styling within the theme instead of changing its CSS stylesheet.</p>
<p>In a test on my local server, I used the advanced image editing options to add a black, four pixel border to an image within the media library. Then I switched themes to see if the border was still there. I discovered that settings applied to images via the WordPress image editing options are displayed no matter which theme is used.</p>
<div id="attachment_21520" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/OldTavernDesign.png" rel="prettyphoto[21488]"><img class="size-full wp-image-21520" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/OldTavernDesign.png?resize=605%2C339" alt="Old Tavern Design With The Black Image Border" /></a><p class="wp-caption-text">Old Tavern Design With The Black Image Border</p></div>
<div id="attachment_21519" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/NewTavernDesign.png" rel="prettyphoto[21488]"><img class="size-full wp-image-21519" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/NewTavernDesign.png?resize=665%2C387" alt="New Tavern Design With The Black Image Border" /></a><p class="wp-caption-text">New Tavern Design With The Black Image Border</p></div>
<p>If a user switches to a theme that uses a color scheme not compatible with the image border color, each image has to be edited individually within the media library. Each time an image is edited using the advanced settings provided by WordPress, you lose more theme compatibility and it further locks you in to a specific theme.</p>
<h3>WordPress.com vs. Self-hosted WordPress</h3>
<div id="attachment_21515" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/WPcomWporg.png" rel="prettyphoto[21488]"><img class="wp-image-21515 size-full" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/WPcomWporg.png?resize=738%2C296" alt="WPcomWporg" /></a><p class="wp-caption-text">WordPress.com and WordPress.org</p></div>
<p>I understand why WordPress.com users would be so upset with the removal of these options. By default, they don&#8217;t have the ability to edit their theme&#8217;s CSS file. That is reserved as a paid upgrade. So these options give them a chance to override the styling within the theme without having the paid upgrade.</p>
<p>For self-hosted WordPress users, there is no excuse. Image borders and padding should be controlled through the theme, not the advanced image editing options provided by WordPress. Despite the options making it easy to apply those changes to images, users are only hurting themselves by using them.</p>
<p>I think the options for padding and image borders should stay removed from the self-hosted version of WordPress while restored on WordPress.com. In retrospect, these options should have never existed in the first place.</p>
<p><strong>Do you think the image border width, color, and padding options should be restored to the self-hosted version of WordPress?</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 22 Apr 2014 01:37:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"Mike Little: WordPress 10th Anniversary: a Reflection";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=1929";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:171:"http://journalized.zed1.com/archives/2013/05/27/wordpress-10th-anniversary-a-reflection/?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-10th-anniversary-a-reflection";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:468:"<p>I posted about <a href="http://mikelittle.org/wordpress-10th-anniversary/">WordPress&#8217; 10th Anniversary</a> celebration and reflected on the last 10 years over on my new blog</p>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2013/05/27/wordpress-10th-anniversary-a-reflection/">WordPress 10th Anniversary: a Reflection</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 23:00:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"Mike Little: WordPress – A 10 year journey";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=1867";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:147:"http://journalized.zed1.com/archives/2013/01/25/wordpress-a-10-year-journey/?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-a-10-year-journey";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2530:"<p><a href="http://journalized.zed1.com/wp-content/uploads/2013/01/wordpress-logo-notext-rgb.png"><img class="size-thumbnail wp-image-1873 alignleft" alt="WordPress logo" src="http://journalized.zed1.com/wp-content/uploads/2013/01/wordpress-logo-notext-rgb-150x150.png" width="150" height="150" /></a></p>
<p>I find it hard to believe but it has now been <strong>ten years</strong> since my fateful <a href="http://ma.tt/2003/01/the-blogging-software-dilemma/#comment-445">comment on Matt&#8217;s blog </a>that kicked off what became the <a href="http://wordpress.org/">WordPress</a> project!<br />
From those humble beginnings of a simple unmaintained blogging platform (b2/Cafelog) to a world-beating open source CMS. B2/Cafelog was used by perhaps 2,000 bloggers. Now WordPress runs more than <a href="http://en.wordpress.com/stats/">60 million sites</a> around the world. That&#8217;s over <a href="http://w3techs.com/technologies/overview/content_management/all">17.5% of the web</a>!</p>
<h2>WordPress Industry</h2>
<p>WordPress now supports a world-wide industry from individual <a href="http://mikelittle.org/">WordPress specialists</a> like me (I&#8217;ve just completed my fourth year as my own company <a href="http://zed1.com/">zed1.com</a>); small WordPress-based companies like <a href="http://codeforthepeople.com/">Code for the People</a>; through to multi-million dollar companies like <a href="http://www.copyblogger.com/">Copyblogger</a>, <a href="http://www.woothemes.com/">WooThemes</a>, and of course <a href="http://automattic.com/">Automattic</a>.</p>
<p>Praise must go as usual to the <a href="http://make.wordpress.org/">fantastic community</a> around WordPress, the singular vision of <a href="http://ma.tt/">Matt Mullenweg</a>, and the awesome power of the <a title="GNU General Public License" href="http://www.gnu.org/licenses/gpl.html">GNU GPL</a> open source license.</p>
<h2>Here&#8217;s to the next year</h2>
<p>As WordPress enters it&#8217;s <strong>eleventh</strong> year, with version 3.5.1 recently released and <a href="http://make.wordpress.org/core/">version 3.6 currently in the making</a>, I predict it will be another great year for <a title="Personal Publishing Platform" href="http://wordpress.org">WordPress</a>.</p>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2013/01/25/wordpress-a-10-year-journey/">WordPress &#8211; A 10 year journey</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 23:00:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"Mike Little: WordCamp Edinburgh UK 2012";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=1856";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:145:"http://journalized.zed1.com/archives/2012/05/29/wordcamp-edinburgh-uk-2012/?utm_source=rss&utm_medium=rss&utm_campaign=wordcamp-edinburgh-uk-2012";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1650:"<p><a href="http://journalized.zed1.com/wp-content/uploads/2012/05/wordcamp-edinburgh-header-1.png"><img class="aligncenter size-full wp-image-1857" title="wordcamp-edinburgh-header-1" src="http://journalized.zed1.com/wp-content/uploads/2012/05/wordcamp-edinburgh-header-1.png" alt="" width="855" height="330" /></a></p>
<p>Folks, if you are looking to attend WordCamp Edinburgh UK 2012, on the weekend of the 14th and 15th of July, you need to get your <a href="http://2012.edinburgh.wordcamp.org/tickets/">tickets</a> pretty soon to qualify for the early bird price (£35).</p>
<p>After midday this coming Friday (June 1st) the price will rise to £45. Mind you, that&#8217;s still a fantastic price for a <a href="http://2012.edinburgh.wordcamp.org/"><strong>two-day weekend</strong> filled with WordPressy goodness</a> .</p>
<p>I&#8217;ll be there of course, will you? It&#8217;s looking like a cracker with some <a href="http://wiki.wpuk.org/2012_content_ideas">great ideas for sessions already put forward</a>. I&#8217;ll be running an extended session called <a href="http://2012.edinburgh.wordcamp.org/session/starting-out-with-wordpress/">Starting Out with WordPress</a>. Once again, get your <a href="http://2012.edinburgh.wordcamp.org/tickets/">tickets</a> soon.</p>
<p>I look forward to seeing you there.</p>
<p><a href="http://wpuk.org/">WPUK</a> is organising this event.</p>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2012/05/29/wordcamp-edinburgh-uk-2012/">WordCamp Edinburgh UK 2012</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 23:00:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"Mike Little: WordPress is Nine. Happy Birthday WordPress!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=1852";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:177:"http://journalized.zed1.com/archives/2012/05/27/wordpress-is-nine-happy-birthday-wordpress/?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-is-nine-happy-birthday-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1387:"<p>Today is the ninth birthday of WordPress (the anniversary of the <a href="http://wordpress.org/news/2003/05/wordpress-now-available/">first release</a>).</p>
<p>WordPress still continues to astonish me in its phenomenal growth. Comparing to <a href="http://journalized.zed1.com/archives/2011/05/27/wordpress-eighth-birthday/">this time last year</a>, WordPress now powers <a href="http://en.wordpress.com/stats/">more than 74 million sites</a>, accounting for <a href="http://w3techs.com/technologies/overview/content_management/all">more than 16% of the internet</a>.</p>
<div>I&#8217;m looking forward to the next year in the world of WordPress. As usual there are lots of exciting things ahead. The first <a href="http://wpappstore.com/">WordPress App Store</a> launched recently, and I&#8217;m sure there will be more (it looks like <a href="http://z1.tl/wpmudevdashboard">WPMU Dev&#8217;s updater/dashboard</a> now lets you buy).</div>
<div></div>
<div>WordPress is really maturing and as a platform and as an industry. There is much more to come and I can&#8217;t wait.</div>
<div></div>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2012/05/27/wordpress-is-nine-happy-birthday-wordpress/">WordPress is Nine. Happy Birthday WordPress!</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 23:00:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"Mike Little: WordPress 3 for Business Bloggers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=1847";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:159:"http://journalized.zed1.com/archives/2012/03/11/wordpress-3-for-business-bloggers/?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-3-for-business-bloggers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1071:"<p>I&#8217;m currently reading <a href="http://www.packtpub.com/wordpress-3-for-business-bloggers/book">WordPress 3 for Business Bloggers</a><a href="http://www.packtpub.com/wordpress-3-for-business-bloggers/book"><img class="alignright" title="WordPress 3 for Business Bloggers" src="https://www.packtpub.com/sites/default/files/imagecache/productview/1322OS_WordPress%203%20for%20Business%20Bloggers_Frontcover.jpg" alt="" width="124" height="152" /></a> by Paul Thewlis. I&#8217;m trying to squeeze it in between all the other stuff I seem to have on my plate. I read the first edition of the book a couple of years ago (though I can&#8217;t find my review to point to); so I&#8217;m looking forward to this one.</p>
<p>I&#8217;ll post a proper review when I&#8217;ve finished it.</p>
<p>&nbsp;</p>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2012/03/11/wordpress-3-for-business-bloggers/">WordPress 3 for Business Bloggers</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 23:00:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"Mike Little: WordPress – 9 years since it’s conception";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=1836";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:169:"http://journalized.zed1.com/archives/2012/01/25/wordpress-9-years-since-its-conception/?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-9-years-since-its-conception";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2138:"<p>Simon D <a title="Simon\'s tweet" href="https://twitter.com/#!/simond/status/162125708506832896">reminded me</a> that it is now nine years since my fateful <a href="http://ma.tt/2003/01/the-blogging-software-dilemma/#comment-445">comment on Matt&#8217;s blog </a>that kicked off this whole WordPress thing!</p>
<blockquote class="twitter-tweet" width="550"><p>Nine years ago today @<a href="https://twitter.com/mikelittlezed1">mikelittlezed1</a> floated an idea which eventually became WordPress. <a href="https://twitter.com/search/%23thanksmike">#thanksmike</a> <a href="http://t.co/teYbVHX8" title="http://ma.tt/2003/01/the-blogging-software-dilemma/">ma.tt/2003/01/the-bl…</a></p>
<p>&mdash; Simon Dickson (@simond) <a href="https://twitter.com/simond/status/162125708506832896">January 25, 2012</a></p></blockquote>
<p></p>
<p>WordPress is really shaping up, and is an evermore stable and functional CMS platform. The statistics continue to astonish me, with more than <a href="http://en.wordpress.com/stats/">70 million sites</a> around the world. That&#8217;s nearly <a href="http://w3techs.com/technologies/overview/content_management/all">16% of the web</a>!</p>
<p>WordPress is supporting a whole industry of WordPress experts, including me: I&#8217;m just starting my fourth year as an <a href="http://zed1.com/">independent WordPress specialist</a>.</p>
<p>Praise must go as usual to the fantastic community around WordPress, the singular vision of <a href="http://ma.tt/">Matt Mullenweg</a>, and the awesome power of the <a title="GNU General Public License" href="http://www.gnu.org/licenses/gpl.html">GNU GPL</a> open source license.</p>
<p>With version 3.4 currently in the making, I predict it will be another great year for <a title="Personal Publishing Platform" href="http://wordpress.org">WordPress</a>.</p>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2012/01/25/wordpress-9-years-since-its-conception/">WordPress &#8211; 9 years since it&#8217;s conception</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 23:00:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"Mike Little: WordPress’ Eighth Birthday";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=1813";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:143:"http://journalized.zed1.com/archives/2011/05/27/wordpress-eighth-birthday/?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-eighth-birthday";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1737:"<p>Today is WordPress&#8217; official eighth birthday (the anniversary of the <a href="http://wordpress.org/news/2003/05/wordpress-now-available/">first release</a>).</p>
<p>I still marvel at the incredible distance it has come. I&#8217;m also still proud that I had a part in its birth. But even more, I marvel at the wonderful contribution of all the WordPress community make to this fantastic project.</p>
<p>A client said to me this morning &#8220;This WordPress is brilliant isn&#8217;t it?&#8221; As I helped him set up his fourth WordPress site. You can&#8217;t get much clearer praise than that.</p>
<p>So raise a virtual beer (or other non-alcoholic beverage if, like me, you are teetotal) to WordPress, the community, and to another year.</p>
<p><strong>Update:</strong> I just spotted this tweet from <a href="http://twitter.com/#!/nacin">Andrew Nacin</a>:</p>
<blockquote class="twitter-tweet" width="550"><p>At more than 20 million WordPress.com blogs, that puts WordPress at north of 45 million sites. Wowza. Happy birthday indeed.</p>
<p>&mdash; Andrew Nacin (@nacin) <a href="https://twitter.com/nacin/status/74139775761793024">May 27, 2011</a></p></blockquote>
<p></p>
<p>Wow! 25 million <a href="http://wordpress.org/">standalone WordPress</a> sites plus 20 million <a href="http://WordPress.com">WordPress.com</a> sites! No wonder it <a href="http://w3techs.com/technologies/overview/content_management/all">powers more than 14 percent of the web</a>.</p>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2011/05/27/wordpress-eighth-birthday/">WordPress&#8217; Eighth Birthday</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 23:00:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"Mike Little: WordPress – 8 Years in the making";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=1748";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:155:"http://journalized.zed1.com/archives/2011/01/27/wordpress-8-years-in-the-making/?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-8-years-in-the-making";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2038:"<p>Wow! Another year has passed and it is now eight years since my fateful <a href="http://ma.tt/2003/01/the-blogging-software-dilemma/#comment-445">comment on Matt&#8217;s blog </a>that kicked off this whole WordPress thing!</p>
<p>WordPress is now a mature CMS platform driving <a href="http://w3techs.com/technologies/overview/content_management/all">13% of the web</a>! It is used for an <a href="http://wordpress.org/showcase/">astonishing array</a> of very different web sites around the world, from the humblest one person blog to <a title="I\'m a Scientist, Get me out of here!" href="http://imascientist.org.uk/">award-winning education sites</a>, <a title="The New Adventures of Stephen Fry" href="http://www.stephenfry.com/">celebrity sites</a>, <a title="The New York Times blogs" href="http://www.nytimes.com/interactive/blogs/directory.html">newspapers</a>, and even <a title="The official site of the Prime Minister\'s Office" href="http://www.number10.gov.uk">world leaders</a>!</p>
<p>WordPress is supporting a whole industry of <a title="WordPress consultants" href="http://codepoet.com/">WordPress experts</a>, including me: I&#8217;m now in my third year as an <a href="http://zed1.com/">independent WordPress specialist</a>.</p>
<p>I believe that WordPress has achieved this massive success in no small way because of the fantastic community around it, the keen-eyed vision of <a href="http://ma.tt/">Matt Mullenweg</a>, and the awesome power of the <a title="GNU General Public License" href="http://www.gnu.org/licenses/gpl.html">GNU GPL</a> open source license.</p>
<p>With version 3.1 just around the corner, I predict it will be another great year for <a title="Personal Publishing Platform" href="http://wordpress.org">WordPress</a>.</p>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2011/01/27/wordpress-8-years-in-the-making/">WordPress &#8211; 8 Years in the making</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 23:00:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"Mike Little: WordCamp slides featured on Slideshare";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=1523";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:169:"http://journalized.zed1.com/archives/2010/07/21/wordcamp-slides-featured-on-slideshare/?utm_source=rss&utm_medium=rss&utm_campaign=wordcamp-slides-featured-on-slideshare";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1285:"<p>The slides from <a href="http://www.slideshare.net/mikelittle/wordcamp-2010-im-a-scientist-get-me-out-of-here-mike-little">my presentation at WordCamp UK</a> in Manchester over the weekend are now on SlideShare. I presented on the fantastic <a href="http://imascientist.org.uk/">I&#8217;m a Scientist Get me Out of Here</a> project website I have built for <a href="http://www.gallomanor.com/">Gallomanor</a> this year.</p>
<p>It&#8217;s best to read the notes in the &#8220;Notes on slide x&#8221; tab so that everything makes sense! I also link to some of the plugins I used at the end.</p>
<p>Amazingly, the presentation features on the <a href="http://www.slideshare.net/">SlideShare home page</a> today along with a couple of other presentations from <a href="http://uk.wordcamp.org/">WordCamp UK</a>! See the &#8220;featured&#8221; section in the right hand column. Woo Hoo!</p>
<p>I have still to finish my write-up of the weekend, but will hopefully get that done &#8216;real soon&#8217;.</p>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2010/07/21/wordcamp-slides-featured-on-slideshare/">WordCamp slides featured on Slideshare</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 23:00:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:42:"Mike Little: WordCamp UK A Few Places Left";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=1519";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:153:"http://journalized.zed1.com/archives/2010/07/15/wordcamp-uk-a-few-tickets-left/?utm_source=rss&utm_medium=rss&utm_campaign=wordcamp-uk-a-few-tickets-left";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1313:"<p>For those of you thinking you may have missed out on this coming weekend&#8217;s WordPress fun at <a href="http://uk.wordcamp.org/">WordCamp UK</a> in Manchester, think again!</p>
<p>As the tickets did not completely sell out, we are making the last few available on the door, as we did last year.</p>
<p>You must email me (mike at my domain ) to reserve a ticket, and then turn up on Saturday morning with your £30 cash.</p>
<p>To recap, WordCamp UK is this weekend, July 17th and 18th, at the <a href="http://www.business.mmu.ac.uk/">Manchester Metropolitan University Business School</a> which is in Manchester city centre, a few minutes walk from the main Piccadilly train Station.</p>
<p>There are <a href="http://wiki.wordcampuk.tonyscott.org.uk/2010_running_order">four simultaneous tracks</a> : General &amp; user, Specialist &amp; developer, Miscellaneous &amp; spontaneous and a &#8216;Genius Bar&#8217; (a range of WordPress experts available to advice attendees on a one-to-one basis).</p>
<p>I look forward to seeing you there.</p>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2010/07/15/wordcamp-uk-a-few-tickets-left/">WordCamp UK A Few Places Left</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 23:00:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WPTavern: WordPress Projects Announced for Google Summer of Code 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21492";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:182:"http://wptavern.com/wordpress-projects-announced-for-google-summer-of-code-2014?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-projects-announced-for-google-summer-of-code-2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2585:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/gsoc2014.png" rel="prettyphoto[21492]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/gsoc2014.png?resize=924%2C156" alt="gsoc2014" class="aligncenter size-full wp-image-21501" /></a></p>
<p>Earlier this year, WordPress was <a href="http://wptavern.com/wordpress-accepted-as-a-mentoring-organization-for-google-summer-of-code-2014" target="_blank">accepted</a> as one of 190 mentoring organizations for <a href="http://www.google-melange.com/gsoc/homepage/google/gsoc2014" target="_blank">Google Summer of Code 2014</a>. This year marks the 10th annual GSoC and WordPress&#8217; 7th year participating in the program. Five students have been <a href="http://make.wordpress.org/community/2014/04/21/gsoc-students-accepted/" target="_blank">accepted</a> and will soon begin work on some exciting projects:</p>
<ul>
<li><a href="http://profiles.wordpress.org/secretmapper" target="_blank">Arian Allenson M. Valdez</a> — Working on GlotPress UI and profiles with Yoav Farhi and Marko Heijnen as mentors</li>
<li><a href="http://profiles.wordpress.org/gautamgupta" target="_blank">Gautam Gupta</a> — Working on bbPress improvements with John James Jacoby and Stephen Edgar as mentors</li>
<li><a href="http://profiles.wordpress.org/avryl" target="_blank">Janneke Van Dorpe</a> — Working on front-end editing/content blocks with Gregory Cornelius and Aaron Jorbin as mentors</li>
<li><a href="http://profiles.wordpress.org/celloexpressions" target="_blank">Nick Halsey</a> — Working on adding custom menus to the customizer with Erick Hitter and Konstantin Obenland as mentors</li>
<li><a href="http://profiles.wordpress.org/VarunAgw" target="_blank">Varun Agrawal</a> — Working on SupportPress as a plugin with Ian Dunn, Aaron Campbell, and Alex Mills as mentors</li>
</ul>
<p>The students selected to participate are all very talented and enthusiastic. In fact, several of them are already active in contributing to WordPress core and have several plugins hosted in the directory.</p>
<p>GSoC 2014 kicks off May 19th when the students will begin their summer coding adventures. In the meantime, they will be bonding with their mentoring teams and working to nail down the scope of their projects. Jen Mylo, who is coordinating WordPress&#8217; involvement in the GSoC, will be working with the teams to set up some livestreamed prototype demos at midterm. Students will also be posting on a weekly basis and we&#8217;ll be following the progress on their projects throughout the summer.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 20:15:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WPTavern: 13 Vagrant Resources for WordPress Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21194";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:156:"http://wptavern.com/13-vagrant-resources-for-wordpress-development?utm_source=rss&utm_medium=rss&utm_campaign=13-vagrant-resources-for-wordpress-development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8683:"<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/vagrant.png" rel="prettyphoto[21194]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/vagrant.png?resize=1025%2C463" alt="vagrant" class="aligncenter size-full wp-image-21435" /></a></p>
<p><a href="http://www.vagrantup.com/" target="_blank">Vagrant</a> is an open source tool that makes it easy to configure and distribute virtual development environments. The project was started in 2010 by Mitchell Hashimoto and John Bender who wanted to create a way to standardize development environments for teams. Vagrant was designed to put an end to the &#8220;works on my machine&#8221; frustration that often surfaces when teams develop on different environments.</p>
<p>Because it&#8217;s so lightweight and portable, many WordPress developers have adopted Vagrant for development, which has resulted in different tools and configurations for various project needs. We&#8217;ve collected a few WordPress-related Vagrant resources here that will help you get started.</p>
<h3>Varying Vagrant Vagrants</h3>
<p><a href="https://github.com/Varying-Vagrant-Vagrants/VVV" target="_blank">Varying Vagrant Vagrants</a> is one of the most widely used and best-supported Vagrant configurations for WordPress development. Originally created by the folks at <a href="http://10up.com/" target="_blank">10up</a>, the open source VVV project <a href="http://10up.com/blog/varying-vagrant-vagrants-future/" target="_blank">became a community organization</a> earlier this year. The company still contributes to its development and maintenance, helping to make it one of the most stable options for setting up a Vagrant-based WordPress development environment. VVV provides a comprehensive configuration for developing themes and plugins as well as for contributing to WordPress core.</p>
<h3>VVV Site Wizard</h3>
<p>If you&#8217;re a VVV user who is often creating and removing sites, then the <a href="https://github.com/aliso/vvv-site-wizard" target="_blank">VVV Site Wizard</a> may be able to save you some time. It completely automates the creation of new sites as well as the teardown of old ones.</p>
<h3>WordPress Theme Review VVV</h3>
<p>If you&#8217;re a VVV user who spends quite a bit of time developing WordPress themes, this is a quick Vagrant setup that adds all the necessary tools for reviewing themes. <a href="https://github.com/aubreypwd/wordpress-themereview-vvv" target="_blank">WordPress Theme Review VVV</a> creates a fresh WordPress site, installs and activates the Developer and Theme-Check plugins, and imports the Theme Unit Test data. Check out our <a href="http://wptavern.com/wordpress-theme-review-vvv-a-quick-vagrant-setup-for-testing-and-reviewing-themes" target="_blank">tutorial</a> for a quick walkthrough on setting it set up.</p>
<h3>Primary Vagrant</h3>
<p><a href="https://github.com/ChrisWiegman/Primary-Vagrant" target="_blank">Primary Vagrant</a> is a configuration created by Chris Wiegman. It&#8217;s similar to VVV but with a few important differences: it uses Apache instead of NGINX and Puppet instead of Bash. Wiegman used VVV and Puppet as a base for a new Vagrant configuration for WordPress plugin or theme development. Primary Vagrant supports Apache and MySQL on Ubuntu and allows for use of different major PHP versions (currently 5.3 – 5.5), which can be easily changed with one line of code.</p>
<h3>VagrantPress</h3>
<p><a href="https://github.com/chad-thompson/vagrantpress" target="_blank">VagrantPress</a> is a simple configuration that sets up a WordPress development environment using Apache with Vagrant/Puppet. It&#8217;s geared toward developing themes and plugins. VagrantPress currently does not allow for multiple installations but Chat Thompson, the project&#8217;s creator, <a href="http://wptavern.com/vagrantpress-a-wordpress-development-environment-for-themes-and-plugins#comment-53714" target="_blank">plans to add more features</a> related to automating the provisioning and maintenance of multiple WordPress installations.</p>
<h3>Chassis</h3>
<p><a href="https://github.com/Chassis/Chassis" target="_blank">Chassis</a> uses Vagrant and Puppet to create a development environment running Ubuntu, Ngnix, PHP 5.4, Imagick, MySQL, Xdebug, WP-CLI, and WordPress, a setup which more closely matches many managed WP hosting environments. Chassis makes it easy to add additional testing domains via a YAML configuration file. It also has support for WordPress multisite, which can be enabled in config.local.yaml or the project configuration file.</p>
<h3>WordPress and Vagrant Google Group</h3>
<p><a href="https://groups.google.com/forum/#!forum/wordpress-and-vagrant" target="_blank">WordPress and Vagrant</a> is a public Google group that you can join to post basic or advanced questions about using Vagrant for development. This can be a helpful resource for troubleshooting some unique issues concerning Vagrant-based WordPress development environments. Most of the threads seem to be about working with VVV, but the group isn&#8217;t specifically limited.</p>
<h3>WordPress Vagrant Boxes</h3>
<p><a href="https://github.com/tierra/wp-vagrant" target="_blank">WordPress Vagrant Boxes</a> is a Vagrant configuration that uses Apache. Although the web server is preconfigured to look for WordPress in a specific location, WordPress Vagrant Boxes is unique in that it doesn&#8217;t checkout or install WordPress at all. It&#8217;s up to you to unpack and install a WordPress ZIP, checkout from SVN, or clone from git.</p>
<h3>VCCW (vagrant-chef-centos-wordpress)</h3>
<p><a href="https://github.com/miya0001/vagrant-chef-centos-wordpress" target="_blank">VCCW</a> (Vagrant + Chef + CentOS + WordPress) was configured for those developing WordPress plugins, themes or websites. It includes 17 customizable constants for setting the WordPress version (or beta release), language, hostname, subdirectory, admin credentials, default plugins, default theme, multisite, SSL and other options. These constants give you a lot of flexibility in tailoring your development environment to your specific needs.</p>
<h3>Throwaway WordPress VMs with Vagrant and Ansible</h3>
<p><a href="https://github.com/jalefkowit/vagrant-ansible-wordpress" target="_blank">Throwaway WordPress VMs</a> uses Vagrant and <a href="http://www.ansible.com/home" target="_blank">Ansible</a> to automate the process of creating and provisioning local virtual machines for WordPress development. The scripts were designed for use with Ubuntu, but you can select any version of Ubuntu you wish to use, or a base box from <a href="http://www.vagrantbox.es/" target="_blank">vagrantbox.es</a>.</p>
<h3>WordPress Machine</h3>
<p><a href="https://github.com/audionerd/wordpress-machine" target="_blank">WordPress Machine</a> sets up WordPress on a LAMP stack. It also includes Composer, <a href="http://wp-cli.org/" target="_blank">WP-CLI</a>, and <a href="http://forge.thethemefoundry.com/" target="_blank">Forge</a> for WordPress theme setup and asset compilation (SCSS, CoffeeScript). This configuration runs <a href="http://ajk.fi/2013/wordpress-as-a-submodule/" target="_blank">WordPress as a submodule</a> using <a href="https://github.com/Darep/wordpress-boilerplate" target="_blank">WordPress Boilerplate</a>, which means that themes, plugins and uploads are separated from the WordPress installation so that WP can be easily updated as a git submodule.</p>
<h3>Monkey Rocket</h3>
<p>The developer who created <a href="https://github.com/Cikica/monkeyrocket" target="_blank">Monkey Rocket</a> used much of the code from VVV, which he found installed more things than he needed for a simple development environment. This Vagrant configuration is basically a stripped down version of VVV that will set you up with the latest stable version of WordPress at local.wordpress.dev on your machine.</p>
<h3>WordPress Kickstart</h3>
<p><a href="https://github.com/jnettome/wordpress_kickstart" target="_blank">WordPress Kickstart</a> is a Vagrant development environment provisioned by Puppet. It was created for use with production stacks that are hosted on <a href="https://www.digitalocean.com/" target="_blank">DigitalOcean</a>. Once you enter your DigitalOcean API credentials into the vagrantfile, you&#8217;ll have a command available for working on production deployment and provisioning. This command allows you to create a new droplet, setup your SSH key for authentication, create a new user account, and run the provisioners configured. You can easily switch back and forth from production to development by removing .vagrant/ from your project&#8217;s root folder.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 14:19:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WPTavern: WPWeekly Episode 146 – WordPress 3.9 With Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=21420&preview_id=21420";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:168:"http://wptavern.com/wpweekly-episode-146-wordpress-3-9-with-andrew-nacin?utm_source=rss&utm_medium=rss&utm_campaign=wpweekly-episode-146-wordpress-3-9-with-andrew-nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2175:"<p>In this weeks edition of WordPress Weekly, we discussed several topics with WordPress lead developer <a href="http://nacin.com/" title="http://nacin.com/">Andrew Nacin</a>. Ever since the release of WordPress 3.7, many have questioned why auto updates are turned on by default for minor and security updates. Nacin described the philosophy behind the auto update system and why the team will be sticking with its current implementation.</p>
<p>We also learned the details behind the release of a major security update to Jetpack. Last but not least, Nacin describes what it was like to lead the release of 3.9 and what he&#8217;ll be focusing on now that he won&#8217;t be leading a release cycle.</p>
<h2>Stories Discussed:</h2>
<p><a href="http://wptavern.com/wordpress-3-9-smith-released" title="http://wptavern.com/wordpress-3-9-smith-released">WordPress 3.9 “Smith” Released</a><br />
<a href="http://wptavern.com/wordpress-3-9-has-built-in-support-for-pasting-from-microsoft-word" title="http://wptavern.com/wordpress-3-9-has-built-in-support-for-pasting-from-microsoft-word">WordPress 3.9 Has Built-In Support for Pasting from Microsoft Word</a><br />
<a href="http://wptavern.com/buddypress-2-0-released-big-performance-improvements-and-new-administration-tools" title="http://wptavern.com/buddypress-2-0-released-big-performance-improvements-and-new-administration-tools">BuddyPress 2.0 Released: Big Performance Improvements and New Administration Tools</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Friday, April 25th 3 P.M. Eastern &#8211; Special Guest &#8211; Japh</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #146:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 19 Apr 2014 14:29:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"Andrew: Customizing TinyMCE 4.0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"http://azaozz.wordpress.com/?p=380";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://azaozz.wordpress.com/2014/04/19/customizing-tinymce-4-0/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2358:"<p>Many of the TinyMCE settings have changed in version 4.0. There is a new default theme: Modern, and all the UI settings for the former Advanced theme (<code>theme_advanced...)</code> are deprecated.</p>
<p>One often used setting was <code>theme_advanced_blockformats</code><strong><code>.</code></strong> It was renamed to <code>block_formats</code> and keeps the same formatting. To specify a different set of elements for the &#8216;blockformats&#8217; drop-down (second toolbar row in the WordPress Visual editor), you can set a string of name=value pairs separated by a semicolon in the initialization object:</p>
<pre class="brush: jscript; title: ; notranslate">block_formats: "Paragraph=p;Heading 1=h1;Heading 2=h2;Heading 3=h3"</pre>
<p>Another handy setting: <code>theme_advanced_styles</code> doesn&#8217;t exist any more. However there is a more powerful version: <code>style_formats</code>. Now it can replace or add items to the new &#8220;Formats&#8221; menu.The value is an array of objects each containing a name that is displayed as sub-menu and several settings: a CSS class name or an inline style, and optionally the wrapper element where the class or inline style will be set:</p>
<pre class="brush: jscript; title: ; notranslate">
toolbar3: \'styleselect\',
style_formats_merge: true,
style_formats: { name: \'Custom styles\', [
  {title: \'Red bold text\', inline: \'b\', styles: {color: \'#ff0000\'}},
  {title: \'Red text\', inline: \'span\', styles: {color: \'#ff0000\'}},
  {title: \'Red header\', block: \'h1\', styles: {color: \'#ff0000\'}},
  {title: \'Example 1\', inline: \'span\', classes: \'example1\'},
  {title: \'Example 2\', inline: \'span\', classes: \'example2\'}
]}
</pre>
<p>The above code will add another sub-menu to &#8220;Formats&#8221; without replacing the default menu items. There is <a href="http://www.tinymce.com/wiki.php/Configuration:style_formats">more information</a> and an <a href="http://www.tinymce.com/tryit/custom_formats.php">example</a> on the TinyMCE website.</p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/azaozz.wordpress.com/380/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/azaozz.wordpress.com/380/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=azaozz.wordpress.com&blog=3380945&post=380&subd=azaozz&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 19 Apr 2014 07:04:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Andrew Ozz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WPTavern: Quotable: Highlight and Share WordPress Posts on Twitter";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:174:"http://wptavern.com/quotable-highlight-and-share-wordpress-posts-on-twitter?utm_source=rss&utm_medium=rss&utm_campaign=quotable-highlight-and-share-wordpress-posts-on-twitter";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3084:"<p><a href="http://wptavern.com/wp-content/uploads/2014/04/quotable.png" rel="prettyphoto[21400]"><img src="http://wptavern.com/wp-content/uploads/2014/04/quotable.png" alt="quotable" width="772" height="250" class="aligncenter size-full wp-image-21403" /></a></p>
<p>Readers may not always identify with the title that you&#8217;ve chosen for your posts but they may find a gem within your article that is more &#8220;quotable&#8221; and worth sharing. <a href="http://wordpress.org/plugins/quotable/" target="_blank">Quotable</a> is a new WordPress plugin that capitalizes on this, allowing readers to highlight any text within your content to quote the article on Twitter.</p>
<p>The plugin, developed by <a href="http://josiahsprague.com/" target="_blank">Josiah Sprague</a>, was partially inspired by the toolbar on Medium.com that enables visitors to tweet or comment on the text they select. Sprague said that he created it out of his love for both WordPress and Twitter:</p>
<blockquote><p> I love how both platforms make it easy for people to share ideas and communicate openly and freely. I love that both serve as a sort of “public square” of the web and support discourse, democracy and free society.</p></blockquote>
<p>Quotable adds a tiny Twitter icon to the end of blockquotes for quick sharing.  It also works with text highlighting. Readers will often instinctively highlight text that they agree with or are wanting to share. When they do, they&#8217;ll naturally discover that it&#8217;s easy to share.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/04/quotable2.png" rel="prettyphoto[21400]"><img src="http://wptavern.com/wp-content/uploads/2014/04/quotable2.png" alt="quotable2" width="916" height="458" class="aligncenter size-full wp-image-21405" /></a></p>
<p>When you click the Twitter bird, a tweet modal will automatically launch with the quoted text inserted. Quotable also integrates with Twitter accounts configured via Yoast&#8217;s WordPress SEO, which allows you to include Twitter mentions for post authors and suggest following the website&#8217;s Twitter account.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/04/quotable-1.png" rel="prettyphoto[21400]"><img src="http://wptavern.com/wp-content/uploads/2014/04/quotable-1.png" alt="quotable-1" width="1400" height="1360" class="aligncenter size-full wp-image-21404" /></a></p>
<p>Let&#8217;s face it &#8211; the comments section of your post is not always the locus of the conversation sparked by your blog. Even if your post is the origin of a hotly debated topic, the conversation often moves to Twitter, and that&#8217;s OK. This plugin helps you to be ready to follow the conversation wherever it goes, especially if you configure it to automatically mention you, the post author, when a quote gets tweeted.</p>
<p>I tested Quotable with WordPress 3.9 and found that it works as advertised and fits naturally into any theme without being obtrusive. <a href="http://wordpress.org/plugins/quotable/" target="_blank">Download</a> it for free from WordPress.org.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Apr 2014 23:10:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"Akismet: New in 3.0: Activation with Jetpack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.akismet.com/?p=1308";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://blog.akismet.com/2014/04/18/activation-with-jetpack/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2091:"<p>We launched <a href="http://blog.akismet.com/2014/04/15/akismet-3-0-0/" title="Akismet 3.0.0 is Now Available">Akismet 3.0</a> just a few days ago and hope that you&#8217;ve already upgraded to enjoy its many new features. One of the nifty items we added to the mix is a seamless activation process using the popular <a href="http://wordpress.org/plugins/jetpack/" title="Jetpack by WordPress.com">Jetpack</a> plugin.</p>
<p>Let&#8217;s take a closer look.</p>
<p>If you have Jetpack and Akismet installed and activated on your site &#8211; and the Jetpack plugin connected to a <a href="http://wordpress.com" title="WordPress.com">WordPress.com</a> account &#8211; you will find this new feature in your dashboard via <strong>Jetpack &#8594; Akismet</strong>.</p>
<p>There, you will see which WordPress.com account is connected via Jetpack and an option to activate the Akismet plugin using that very same account.</p>
<p><a href="http://akismet.files.wordpress.com/2014/04/akismet-activation-with-jetpack.png"><img src="http://akismet.files.wordpress.com/2014/04/akismet-activation-with-jetpack.png?w=640&h=263" alt="Akismet Activation with Jetpack" class="alignnone size-large wp-image-1348" /></a></p>
<p>Click on <strong>Use this Akismet account</strong>, and you&#8217;re all set! Of course, you will have the option to disconnect the account at any time from the same page in your dashboard.</p>
<p>And if you want to use a different account to activate Akismet, no worries at all. Simply select the option to register a different email address or manually enter an existing API key.</p>
<p>Digging the new flow? Any problems with it? <a href="http://akismet.com/contact/" title="Contact Akismet">Drop us a line</a>.</p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1308/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1308/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=blog.akismet.com&blog=116920&post=1308&subd=akismet&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Apr 2014 19:40:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Anthony Bubel";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"WPTavern: WordPress 3.9 Has Built-in Support for Pasting from Microsoft Word";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21366";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:196:"http://wptavern.com/wordpress-3-9-has-built-in-support-for-pasting-from-microsoft-word?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-3-9-has-built-in-support-for-pasting-from-microsoft-word";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2744:"<div id="attachment_21384" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/04/paste.png" rel="prettyphoto[21366]"><img src="http://wptavern.com/wp-content/uploads/2014/04/paste.png" alt="photo credit: This Year\'s Love - cc" width="900" height="401" class="size-full wp-image-21384" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/hand-nor-glove/1481913840/">This Year&#8217;s Love</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-nd/2.0/">cc</a></p></div>
<p>A common support question that&#8217;s been popping up on the web after WordPress users update to 3.9: <strong>What happened to the &#8220;Paste from Word&#8221; button in the visual editor?</strong> If you find that the button is missing, don&#8217;t worry &#8211; it&#8217;s not a bug.  Prior to this update, the button was located in the kitchen sink of the visual editor:</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/04/paste-from-word.png" rel="prettyphoto[21366]"><img src="http://wptavern.com/wp-content/uploads/2014/04/paste-from-word.png" alt="paste-from-word" width="622" height="233" class="aligncenter size-full wp-image-21370" /></a></p>
<p>WordPress 3.9, however, <a href="https://core.trac.wordpress.org/changeset/28089" target="_blank">removes the &#8220;paste from word&#8221; button</a> entirely. It includes <a href="http://make.wordpress.org/core/2014/01/18/tinymce-4-0-is-in-core/" target="_blank">TinyMCE 4.0</a> and has better built-in support for pasting in blocks of text for Microsoft Word. The better your software gets, the more the magic happens behind the scenes. WordPress now detects if the pasted text is coming from MS Word and makes the appropriate changes.</p>
<p>Until I saw the <a href="http://www.reddit.com/r/Wordpress/comments/23ah5d/copy_from_word_button_went_missing/" target="_blank">question</a> on Reddit, indicating that the button had gone missing, I had no idea that anyone still used this feature. The missing button is actually an enhancement, not a bug. Hopefully this information has reached you before you started deactivating all your plugins.</p>
<p>Unless you had been closely following the posts at <a href="http://make.wordpress.org" target="_blank">make.wordpress.org</a>, this improvement might have been easy to miss. Check out our <a href="http://wptavern.com/wordpress-3-9-smith-released" target="_blank">summary of everything that&#8217;s new in WordPress 3.9</a>. If you&#8217;re having any problems with the update, you may want to review some of the <a href="http://wptavern.com/common-issues-and-troubleshooting-wordpress-3-9" target="_blank">known issues</a> with plugins before posting in the support forums.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Apr 2014 17:53:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"WPTavern: How to Limit Activity Comment Depth in BuddyPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21347";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:162:"http://wptavern.com/how-to-limit-activity-comment-depth-in-buddypress?utm_source=rss&utm_medium=rss&utm_campaign=how-to-limit-activity-comment-depth-in-buddypress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2642:"<p>BuddyPress 2.0 was <a href="http://wptavern.com/buddypress-2-0-released-big-performance-improvements-and-new-administration-tools" target="_blank">released</a> this week with many new administrative tools that make it easier to manage communities from the backend. One of the lesser known new features is the ability to limit comment depth in the activity stream.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/04/old-threaded-comments.png" rel="prettyphoto[21347]"><img src="http://wptavern.com/wp-content/uploads/2014/04/old-threaded-comments-300x258.png" alt="old-threaded-comments" width="300" height="258" class="alignright size-medium wp-image-21351" /></a>Activity threads can sometimes get out of control when it comes to replies, which results in the comments box getting progressively squished to an inconveniently small size.</p>
<p>In the past, the only way to change the comment depth was to filter the output of the bp_activity_can_comment_reply() function, but this wasn&#8217;t very user-friendly for community managers.</p>
<p>Since WordPress already has a built-in setting for comment depth, this was a natural fit for activity comments and did not require adding any new settings. BuddyPress 2.0 now <a href="https://buddypress.trac.wordpress.org/ticket/2768" target="_blank">respects WordPress&#8217; comment depth settings</a>. You can adjust them in the admin at <strong>Settings > Discussion > Other Comment Settings</strong>.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/04/threaded-comments.png" rel="prettyphoto[21347]"><img src="http://wptavern.com/wp-content/uploads/2014/04/threaded-comments.png" alt="threaded-comments" width="1200" height="397" class="aligncenter size-full wp-image-21349" /></a></p>
<p>In the following example, threaded comments have been set to three. You&#8217;ll notice that the third comment has no reply link beneath it. Members can still comment on the activity item itself but will not be able to add more than three replies.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/04/activity-comments.png" rel="prettyphoto[21347]"><img src="http://wptavern.com/wp-content/uploads/2014/04/activity-comments.png" alt="activity-comments" width="900" height="680" class="aligncenter size-full wp-image-21355" /></a></p>
<p>This update shouldn&#8217;t affect the structure of your previous activity comments/replies, but it will be in effect for threaded comments moving forward. If you&#8217;ve been itching to to limit activity comment depth on your BuddyPress site, this new setting makes it easy to set a limit, without having to touch any code.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Apr 2014 06:42:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WordPress.tv: Cédric Motte : Sans contenu, WordPress n’est rien";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34325";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.tv/2014/04/17/cedric-motte-sans-contenu-wordpress-nest-rien/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:673:"<div id="v-4WgeuUC1-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34325/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34325/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34325&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/04/17/cedric-motte-sans-contenu-wordpress-nest-rien/"><img alt="13 &#8211; Cedric Motte-Conf-WCParis2014.mp4" src="http://videos.videopress.com/4WgeuUC1/video-88337de484_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Apr 2014 21:58:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:91:"WPTavern: Automattic Publishes Transparency Report, Reaffirms Support for Freedom of Speech";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21275";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:224:"http://wptavern.com/automattic-publishes-transparency-report-reaffirms-support-for-freedom-of-speech?utm_source=rss&utm_medium=rss&utm_campaign=automattic-publishes-transparency-report-reaffirms-support-for-freedom-of-speech";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5451:"<p>Automattic was created to bring WordPress&#8217; open source publishing software to people on a larger scale. The company shares <a href="http://codex.wordpress.org/WordPress_Policies" target="_blank">WordPress&#8217; mission</a> to democratize publishing. As part of that mission, Automattic published a transparency report, which outlines the number of information requests, takedown demands, and national security requests it has received.</p>
<p>The <a href="http://transparency.automattic.com/" target="_blank">Transparency Report</a> is located on a new site which helps users to navigate what will likely become a large archive of information, as Automattic plans to publish a new report every six months. This report will keep users informed about which governments are making requests and policies for responding to them.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/04/transparency-report.jpg" rel="prettyphoto[21275]"><img src="http://wptavern.com/wp-content/uploads/2014/04/transparency-report.jpg" alt="transparency-report" width="1280" height="664" class="aligncenter size-full wp-image-21310" /></a></p>
<p>Writing on behalf of Automattic, Jenny Zhu <a href="http://en.blog.wordpress.com/2014/04/17/transparency-report/" target="_blank">summarized</a> the company&#8217;s policy regarding information requests:</p>
<blockquote><p>Our policy is to notify you of any information request we receive regarding your account, so that you may challenge the request. The only exception is if we are prohibited by law (not just asked nicely by the police) from making such a notification. </p></blockquote>
<h3>Automattic is Committed to Actively Pushing Back Against Requests That Violate Freedom of Speech</h3>
<p>Historically, Automattic has demonstrated its support for freedom of speech by <a href="http://en.blog.wordpress.com/2010/07/01/support-the-first-amendment-with-1-for-all/" target="_blank">raising awareness about the First Amendment</a>, even taking to the courts <a href="http://en.blog.wordpress.com/2013/11/21/striking-back-against-censorship/" target="_blank">to stand with users against DMCA abuse</a>. The company also recently joined forces with other organizations around the globe to <a href="http://wptavern.com/wordpress-com-joins-google-reddit-and-tumblr-in-protesting-nsa-surveillance" target="_blank">protest NSA surveillance</a>.</p>
<p>Through its statement today, Automattic emphasized that it will push back against requests that constitute infringements on freedom of speech:</p>
<blockquote><p>We also carefully review all legal requests we receive and actively push back on those that are procedurally deficient, overly-broad, or otherwise improper (i.e., those that target non-criminal free speech).</p></blockquote>
<h3>The US Government Represents 60% of the Information Requests</h3>
<p>Russia, not known for its support of free press, leads the way in <a href="http://transparency.automattic.com/takedown-demands/" target="_blank">takedown demands</a> with 88% of the total requests received by WordPress.com. The United States, however, far and away leads in the number of user <a href="http://transparency.automattic.com/information-requests/" target="_blank">information requests</a> from governments and law enforcement agencies from July 1 – December 31, 2013.</p>
<p>While most of the countries listed have submitted a handful of requests, the US government sent 20 requests, specifying 29 different sites. In 60% of those requests, some or all information was produced. The requests shown here do not include those related to litigation and civil proceedings.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/04/information-requests.jpg" rel="prettyphoto[21275]"><img src="http://wptavern.com/wp-content/uploads/2014/04/information-requests.jpg" alt="information-requests" width="753" height="736" class="aligncenter size-full wp-image-21315" /></a></p>
<p>Automattic specifies that the company will only turn over private user information upon receipt of valid US legal process. Requests that originate from outside the US are required to be served through a US court or enforcement agency.</p>
<p>The company is not permitted to disclose very much regarding national security requests, despite wishing they could:</p>
<blockquote><p>Finally, we’re reporting the maximum amount of information allowed by law about the number and type(s) of National Security Requests that we received. The disclosures we’re currently allowed to make are limited, and unfortunately, we’re not permitted to paint a more truthful picture.</p></blockquote>
<p>The <a href="http://transparency.automattic.com/" target="_blank">Transparency Report</a> makes it clear that Automattic will not tolerate censorship of its users and is committed to disclosing as much information related to government requests as they are permitted. Many governments are <a href="http://www.bloomberg.com/news/2014-04-11/nsa-said-to-have-used-heartbleed-bug-exposing-consumers.html" target="_blank">ruthless about extracting information from citizens</a>, even when it comes at the expense of the people they serve. Given that the United States leads the pack in information requests, it&#8217;s reassuring to know that WordPress.com, one of the most highly trafficked sites in the US and around the globe, is committed to standing against any request that violates users&#8217; freedom of speech.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Apr 2014 20:43:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"WPTavern: Common Issues and Troubleshooting WordPress 3.9";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21274";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:158:"http://wptavern.com/common-issues-and-troubleshooting-wordpress-3-9?utm_source=rss&utm_medium=rss&utm_campaign=common-issues-and-troubleshooting-wordpress-3-9";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8165:"<div id="attachment_21291" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/04/WP39Support.png" rel="prettyphoto[21274]"><img class="size-full wp-image-21291" src="http://wptavern.com/wp-content/uploads/2014/04/WP39Support.png" alt="WordPress 3.9 Featured Images" width="639" height="200" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/ironrodart/4154904299/">IronRodArt &#8211; Royce Bair (&#8220;Star Shooter&#8221;)</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-nd/2.0/">cc</a></p></div>
<p>After the release of WordPress 3.9, I decided to help out in the <a title="http://wordpress.org/support/" href="http://wordpress.org/support/">support forums</a> since they usually become busy soon after a release. Providing support in the WordPress.org forums gives you a clear indication on how well a release is being received and whether or not anything major broke. After spending five hours in the support forum, here are some common issues being reported by users.</p>
<h3>Visual Editor Disappeared Or Is Broken</h3>
<p>A lot of users are <a title="http://wordpress.org/tags/visual-editor" href="http://wordpress.org/tags/visual-editor">reporting that the visual editor</a> has either disappeared or is broken. Considering the <a title="http://make.wordpress.org/core/2014/01/18/tinymce-4-0-is-in-core/" href="http://make.wordpress.org/core/2014/01/18/tinymce-4-0-is-in-core/">number</a> of changes that took place with TinyMCE in 3.9, this is not surprising. In most cases, having users go through the following process solved the problem.</p>
<ol>
<li>Deactivate ALL plugins.</li>
<li>Switch to default TwentyFourteen theme.</li>
<li>Manually empty browser cache.</li>
</ol>
<p>If the visual editor doesn&#8217;t work after disabling all plugins and switching to the default theme, there could be a JavaScript issue. Follow <a title="http://codex.wordpress.org/Using_Your_Browser_to_Diagnose_JavaScript_Errors" href="http://codex.wordpress.org/Using_Your_Browser_to_Diagnose_JavaScript_Errors">these instructions</a> to diagnose JavaScript errors in your browser. Then, open up a new support forum thread and make sure to add the following information:</p>
<ul>
<li>the browsers that you are experiencing the problem in</li>
<li>whether SCRIPT_DEBUG fixed the error or not</li>
<li>the JavaScript error</li>
<li>the location of the error &#8211; both the file name and the line number</li>
<li>the context of the error &#8211; including the whole error stack will help developers</li>
</ul>
<p>This detailed information will help volunteer moderators determine the best way to solve your problem.</p>
<h3>Master List Of Known Issues</h3>
<p>Themes and plugins confirmed to be the cause of the problem are documented and added to the <a title="http://wordpress.org/support/topic/wordpress-39-master-list?replies=4" href="http://wordpress.org/support/topic/wordpress-39-master-list?replies=4">master list</a> of known issues with WordPress 3.9. So far, the list of plugins is up to eight with at least one in the process of being fixed.</p>
<ul>
<li><a href="http://wordpress.org/plugins/wysija-newsletters/">MailPoet Newsletters</a> &#8211; Issue with <a href="https://wordpress.org/support/topic/39-update-tinymce-disappeared?replies=6#post-5465005">outdated TinyMCE plugin in version 2.6.3</a>, disabling plugin fixed Visual Editor problem. MailPoet is already working on a fix for the TinyMCE issue in the next versions 2.6.4 (for post editor screen) and 2.6.5 (for newsletter editor).</li>
<li><a href="https://wordpress.org/plugins/ziplist-recipe-plugin/">ZipList Recipe Plugin</a> &#8211; Version 2.2 has a problem with the post editor in <a href="https://wordpress.org/support/topic/plugin-causes-posts-to-not-be-editable?replies=2">both Visual and Text mode</a>.</li>
<li><a href="http://wordpress.org/plugins/zedity/">Zedity</a> &#8211; Version 3.1.0 causes the Visual Editor to break.</li>
<li><a href="https://wordpress.org/plugins/enhanced-media-library/">Enhanced Media Library</a> &#8211; Version 1.0.4 doesn&#8217;t show any media in the media library when the Add Media button is clicked</li>
<li><a href="http://wordpress.org/plugins/soundcloud-is-gold/">SoundCloud Is Gold</a> &#8211; Version 2.2.1 disables the Visual editor and prevents text from being entered</li>
<li><a href="https://wordpress.org/plugins/nofollow/">Ultimate NoFollow</a> &#8211; Version 1.4.1 doesn&#8217;t allow links to be inserted in the visual editor</li>
<li><a href="https://wordpress.org/plugins/many-tips-together/">Admin Tweaks</a> &#8211; version 2.3.8 causes the visual editor to white out.</li>
<li><a href="http://wordpress.org/plugins/qtranslate/">Qtranslate</a> &#8211; version 2.5.39 causes the media uploaded not to function</li>
</ul>
<p>The support team tries their best to help everyone with any WordPress problem even if it&#8217;s for a commercial theme or plugin. However, due to the great variety of existing themes and plugins it is nearly impossible to know everything. Your best option is to contact the developer for support. It’s always best to go to where the theme/plugin is officially supported when trying to get support.</p>
<h3>How To Create An Audio Playlist</h3>
<p>A few users have asked where the link is to create an audio playlist. In order to see the link to create an audio playlist, you either need existing audio files within the media library or you need to add them. It&#8217;s worth noting that if you host your media files on a content delivery network that&#8217;s not synchronized with the WordPress media library, you won&#8217;t be able to take advantage of the playlist feature.</p>
<h3>Easy Way To Add Borders and Padding To Images Removed</h3>
<p>Although WordPress 3.9 has refined the media editing experience, it did so at the cost of removing a feature users appreciated. In WordPress 3.8, users could easily add a border, vertical, and horizontal padding to images. WordPress 3.9 has removed this from the advanced image settings screen.</p>
<div id="attachment_21279" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/04/WP38ImageProperties.png" rel="prettyphoto[21274]"><img class="size-full wp-image-21279" src="http://wptavern.com/wp-content/uploads/2014/04/WP38ImageProperties.png" alt="Image Properties In WordPress 3.8" width="620" height="476" /></a><p class="wp-caption-text">Image Properties In WordPress 3.8</p></div>
<p>It&#8217;s not just those who use the self-hosted version of WordPress that are upset with the change. A WordPress.com <a title="http://en.forums.wordpress.com/topic/image-resize-1?replies=430" href="http://en.forums.wordpress.com/topic/image-resize-1?replies=430">support forum thread</a> with over 430 posts is filled with users asking why the feature was removed. In some cases, WordPress.com staff are explaining how to use HTML code to add or remove borders to images. It&#8217;s possible that a plugin will soon be released that will restore this feature.</p>
<h3>Use Patience When Asking For Support</h3>
<p>Since WordPress 3.9 is a major upgrade, please exercise patience when requesting support on the forum. This <a title="https://codex.wordpress.org/Using_the_Support_Forums#Getting_Your_Questions_Answered_on_the_Forum" href="https://codex.wordpress.org/Using_the_Support_Forums#Getting_Your_Questions_Answered_on_the_Forum">guide on the Codex</a> does a great job explaining how to get your question answered. Last but not least, if a volunteer helps solve your problem, say thank you. During my five-hour support stint, I realized first-hand that providing support is a thankless job. Reading thank you notes and seeing users express joy from having their problem solved gave me the energy to keep on going.</p>
<p>I encourage you to take 15-20 minutes to browse the support forum and help out where you can. Not only will you get a better understanding of problems users are facing, but you&#8217;ll learn a lot in the process. To anyone who&#8217;s taken the time to answer a support question on the forum, <strong>thank you!</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Apr 2014 19:45:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"WordPress.tv: Introducing WordPress 3.9 “Smith”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34317";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.tv/2014/04/16/introducing-wordpress-3-9-smith/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:635:"<div id="v-sAiXhCfV-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34317/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34317/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34317&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/04/16/introducing-wordpress-3-9-smith/"><img alt="WordPress3-9-Smith" src="http://videos.videopress.com/sAiXhCfV/wordpress3-9-smith_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 21:10:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"WPTavern: How To Set Up 1 Or 2 Columns For WordPress Dashboard Widgets";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21030";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:184:"http://wptavern.com/how-to-set-up-1-or-2-columns-for-wordpress-dashboard-widgets?utm_source=rss&utm_medium=rss&utm_campaign=how-to-set-up-1-or-2-columns-for-wordpress-dashboard-widgets";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3932:"<p>One of the improvements in <a title="http://wordpress.org/news/2013/12/parker/" href="http://wordpress.org/news/2013/12/parker/">WordPress 3.8</a> was the responsive dashboard. Thanks to this improvement, the option to select the number of columns to display dashboard widgets <a title="http://make.wordpress.org/ui/2013/10/11/dash-update-4/" href="http://make.wordpress.org/ui/2013/10/11/dash-update-4/">was removed</a>. The dashboard now shows the appropriate number of columns using the available screen real estate. Unfortunately, for those using wide-screen monitors, this usually means 4-5 skinny columns. In the screenshot below, you can see that even if a column doesn&#8217;t have a widget assigned to it, the column remains in place.</p>
<div id="attachment_21233" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/04/DashboardWithFourColumns.png" rel="prettyphoto[21030]"><img class="size-full wp-image-21233" src="http://wptavern.com/wp-content/uploads/2014/04/DashboardWithFourColumns.png" alt="The Result Of A Responsive Dashboard" width="1724" height="417" /></a><p class="wp-caption-text">The Result Of A Responsive Dashboard</p></div>
<p>The issue was <a title="http://imtheirwebguy.com/dont-hit-update-just-yet-wp-3-8-overhauls-ui-breaks-dashboard-widgets/" href="http://imtheirwebguy.com/dont-hit-update-just-yet-wp-3-8-overhauls-ui-breaks-dashboard-widgets/">brought up by Chris Jenkins</a> shortly after the release of WordPress 3.8. WordPress core developer Mark Jaquith agreed that &#8220;dashboard widgets should be able to specify a min-width, such that they span multiple columns if WordPress tries to make them smaller than that.&#8221; Jaquith <a title="https://core.trac.wordpress.org/ticket/26575" href="https://core.trac.wordpress.org/ticket/26575">created a ticket</a> suggesting a fix but so far, a patch has not been created.</p>
<p>Since the ticket was created, Jenkins has developed and released a plugin called <a title="http://wordpress.org/plugins/two-column-admin/" href="http://wordpress.org/plugins/two-column-admin/">Two Column Admin</a>. When activated, the plugin restores the ability to select 1 or 2 columns to the screen options tab. The downside to using this plugin is that selecting two columns will disable the responsiveness of the dashboard widgets. Instead of merging into one column when the screen size gets smaller, the two columns will crash into each other.</p>
<div id="attachment_21234" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/04/TwoColumnUnresponsiveWidgets.png" rel="prettyphoto[21030]"><img class="size-full wp-image-21234" src="http://wptavern.com/wp-content/uploads/2014/04/TwoColumnUnresponsiveWidgets.png" alt="Two Column Unresponsive Widgets" width="500" height="447" /></a><p class="wp-caption-text">Two Column Unresponsive Widgets</p></div>
<p>Matt Beck <a title="https://core.trac.wordpress.org/ticket/26575#comment:1" href="https://core.trac.wordpress.org/ticket/26575#comment:1">responded to the ticket</a> with a good suggestion in lieu of the column option returning:</p>
<blockquote><p>Best case scenario would be for the number/width of columns to adjust to the number of active dashboard widgets instead of displaying the empty drag/drop areas. In lieu of that, some mechanism to specify either column-count of a widget intended to be wide and/or better yet &#8211; maximum number of columns to display on the dashboard would be great.</p></blockquote>
<p>After being stuck with four columns since the release of 3.8, I&#8217;ve forgotten how nice it is to have wide dashboard widgets. I&#8217;m hopeful that in the future, the ability to specify the number of columns in the dashboard returns as I prefer three, not four columns.</p>
<p><strong>How many of you would like to be able to specify a specific amount of columns versus the current implementation?</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 19:30:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"WPTavern: BuddyPress Development Trunk to Adopt a Grunt-Powered Build System";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21231";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:196:"http://wptavern.com/buddypress-development-trunk-to-adopt-a-grunt-powered-build-system?utm_source=rss&utm_medium=rss&utm_campaign=buddypress-development-trunk-to-adopt-a-grunt-powered-build-system";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3238:"<p><a href="http://wptavern.com/wp-content/uploads/2014/04/grunt.jpg" rel="prettyphoto[21231]"><img src="http://wptavern.com/wp-content/uploads/2014/04/grunt.jpg" alt="grunt" width="916" height="360" class="aligncenter size-full wp-image-21245" /></a></p>
<p>Now that <a href="http://wptavern.com/buddypress-2-0-released-big-performance-improvements-and-new-administration-tools" target="_blank">BuddyPress 2.0</a> has been released, the core development team is refining its workflow to make use of <a href="http://gruntjs.com/" target="_blank">Grunt</a>, the Javascript task runner that the WordPress project <a href="http://make.wordpress.org/core/2013/08/06/a-new-frontier-for-core-development/" target="_blank">adopted</a> last year. The <a href="http://buddypress.svn.wordpress.org/trunk" target="_blank">BuddyPress development trunk</a> will be adopting a similar Grunt-powered build system that will automate many tedious tasks.</p>
<p>The BuddyPress trunk will be reorganized to include a <strong>/src</strong> directory for BuddyPress, minus bbPress 1.1 and the BP-Default theme, which will be removed. The <strong>/tests</strong> directory will house the phpUnit tests. <a href="https://travis-ci.org/buddypress/BuddyPress" target="_blank">Travis-CI</a> and configuration files for tests will be moved to the root.</p>
<h3>Who Is Affected?</h3>
<p>The reorganization of the trunk will not affect production releases of BuddyPress, so for most ordinary users nothing will change. BuddyPress core contributor Paul Gibbs specified who will be affected by the changes in his <a href="http://bpdevel.wordpress.com/2014/04/16/grunt-coming-to-buddypress/" target="_blank">post</a> on the development blog. The changes concern you if:</p>
<ul>
<li>You develop plugins for BuddyPress</li>
<li>You are a core contributor</li>
<li>You run a checkout of trunk on a production site</li>
</ul>
<p>While this cross section of affected users represents just a handful of BuddyPress developers, the good news for everyone is that both core and extension development will become more efficient. That means that improvements and new plugins are likely to reach you faster than before.</p>
<h3>How Will Grunt Make BuddyPress Development More Efficient?</h3>
<p>Grunt will reduce the amount of manual labor that developers put into contributing to the BuddyPress core and creating plugins. The task runner will handle all of the following:</p>
<ul>
<li>Validate and lint CSS/JS</li>
<li>Generate right-to-left CSS</li>
<li>Compress images</li>
<li>Run unit tests</li>
<li>Generate the .pot file for internationalization</li>
<li>Check for missing text domains</li>
<li>Make it easier for developers to apply patches from BuddyPress Trac for testing</li>
</ul>
<p>The core team may add to this list in the future. If you want to get involved in the discussion or keep an eye on the &#8220;grunt-ification&#8221; of the BuddyPress trunk, there&#8217;s a <a href="https://buddypress.trac.wordpress.org/ticket/5160" target="_blank">trac ticket</a> open where updates will be posted. Core contributors and developers running a checkout of trunk on production/development sites will want to stay tuned for any changes that might affect your workflow.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 19:16:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Wed, 30 Apr 2014 01:27:16 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"204027";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Wed, 30 Apr 2014 01:15:19 GMT";s:4:"x-nc";s:11:"HIT lax 250";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20130911110210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (1082, '_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1398864438', 'no') ; 
INSERT INTO `wp_options` VALUES (1083, '_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1398821238', 'no') ; 
INSERT INTO `wp_options` VALUES (1084, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1398864438', 'no') ; 
INSERT INTO `wp_options` VALUES (1085, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 30 Apr 2014 01:24:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"15@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8321@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using the WordPress SEO plugin by Yoast.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2141@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"132@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"753@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"23862@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"WP-Optimize";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://wordpress.org/plugins/wp-optimize/#post-8691";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 21 Jan 2009 04:28:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8691@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:150:"Simple but effective plugin allows you to extensively clean up your WordPress database and optimize it without doing manual queries.
This simple but e";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"ruhanirabin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"iThemes Security (formerly Better WP Security)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/better-wp-security/#post-21738";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Oct 2010 22:06:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"21738@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"The easiest, most effective way to secure WordPress in seconds.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Chris Wiegman";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"TinyMCE Advanced";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/plugins/tinymce-advanced/#post-2082";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Jun 2007 15:00:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2082@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Andrew Ozz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"MailPoet Newsletters";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wysija-newsletters/#post-32629";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 Dec 2011 17:09:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"32629@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:94:"Send newsletters, post notifications or autoresponders from WordPress easily, and beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"MailPoet Staff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"18101@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29860@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"WPtouch Mobile Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"http://wordpress.org/plugins/wptouch/#post-5468";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 May 2008 04:58:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"5468@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"Create a slick mobile WordPress website with just a few clicks.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"BraveNewCode Inc.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29832@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:121:"Wordfence Security is a free enterprise class security plugin that makes your site up to 50 times faster and more secure.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"1169@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:120:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 9 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:45:"http://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:7:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Wed, 30 Apr 2014 01:27:19 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Fri, 09 Mar 2007 22:11:30 GMT";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20130911110210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (1086, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1398864438', 'no') ; 
INSERT INTO `wp_options` VALUES (1087, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1398821238', 'no') ; 
INSERT INTO `wp_options` VALUES (1088, '_transient_timeout_plugin_slugs', '1398907638', 'no') ; 
INSERT INTO `wp_options` VALUES (1089, '_transient_plugin_slugs', 'a:6:{i:0;s:19:"akismet/akismet.php";i:1;s:35:"backupwordpress/backupwordpress.php";i:2;s:39:"contact-form-to-email/form-to-email.php";i:3;s:9:"hello.php";i:4;s:21:"newsletter/plugin.php";i:5;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (1090, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1398864438', 'no') ; 
INSERT INTO `wp_options` VALUES (1091, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2014/04/smith/\' title=\'Version 3.9 of WordPress, named “Smith” in honor of jazz organist Jimmy Smith, is available for download or update in your WordPress dashboard. This release features a number of refinements that we hope you’ll love. A smoother media editing experience Improved visual editing The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the […]\'>WordPress 3.9 “Smith”</a> <span class="rss-date">April 16, 2014</span><div class=\'rssSummary\'>Version 3.9 of WordPress, named “Smith” in honor of jazz organist Jimmy Smith, is available for download or update in your WordPress dashboard. This release features a number of refinements that we hope you’ll love. A smoother media editing experience Improved visual editing The updated visual editor has improved speed, accessibility, and mobile support. You [&hellip;]</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wptavern.com/would-anyone-be-interested-in-a-wordcamp-badges-plugin?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=would-anyone-be-interested-in-a-wordcamp-badges-plugin\' title=\'Wordcamp Miami Badges is a new plugin in the WordPress directory today. It allows speakers, attendees and volunteers to easily display badges indicating their participation in the 2014 event, which is estimated to surpass 700 this year. The badges plugin was created by Myles McNamara, a self-described “geek who loves open source, writing code, and helping others out.” After searching the directory for a plugin that would display an event-specific WordCamp badge, he couldn’t find a suitable option and was inspired to create a new plugin. WordCamp Miami Badges makes it easy to place a badge on your website using a configurable shortcode or widget.  The Possibility of a Generic WordCamp Badges Plugin I got in touch with McNamara to find out how difficult it would be for other WordCamp organizers to adapt the plugin for their own events. He said that it’s possible to restructure it for use as a generic WordCamp badges plugin. “As of right now this will only work for the Miami one as I hard coded the images into the plugin, but it would be very easy to add an option for the user to specify the image, or even just set it as a variable in one of the files that others could change to what they want,” he said. McNamara has a few ideas for enhancements to the plugin that he’d like to add, if there’s enough interest in converting this beta version into a widespread WordCamp plugin:  A Countdown Clock A Ribbon throughout entire site (like the GitHub fork me one) A Sticky footer throughout entire site A More customization for image (resizing, floating (absolute positing) image Add animations using animate.css  McNamara contributes to a number of open source projects on Github, including ownCloud and the Pods Framework for WordPress. If he gets enough interest in a generic WordCamp badges plugin, he’d be happy to adapt the WordCamp Miami plugin for broader use. If you’d like to get involved, you can contribute code and localizations to the plugin via GitHub. What do you think? Would a WordCamp Badges plugin be useful for promoting events? Do you like McNamara’s list of proposed enhancements? Or is it just as easy to upload a badge to your website?\'>WPTavern: Would Anyone Be Interested in a WordCamp Badges Plugin?</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/how-to-archive-a-site-you-dont-have-access-to?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=how-to-archive-a-site-you-dont-have-access-to\' title=\'There are several options when it comes to backing up a WordPress site. Depending on the type of access you have, retrieving the database or an XML backup is easy. But what if you don’t have access to the database or the backend? Consider the following scenario presented on the WordPress subreddit: A relative who used WordPress recently passed away and you have no way to access the backend of their site. Their site is filled with memorable posts you’d like to archive. One option is to use WGET. WGET is a free, open source software package used for retrieving files using HTTP, HTTPS and FTP, the most widely used Internet protocols. I used version 1.10.2 of this WGET package put together by HHerold which worked successfully on my Windows 7 64-bit desktop. Once installed, you’ll need to activate the command prompt and navigate to the folder where WGET.exe is installed. WGET In Action In the example below, I used four different parameters. GNU.org has an excellent guide available that explains what each parameter does. Alternatively, you can use the wget — help command to see a list of commands.  HTML Extension – This will save the retrieved files as .HTML Convert Links – After the download is complete, this will convert the links in the document to make them suitable for local viewing. This affects not only the visible hyperlinks, but any part of the document that links to external content, such as embedded images, links to style sheets, hyperlinks to non-HTML content, etc. -m – This turns on the options suitable for mirroring. -w 20 – This command puts 20 seconds in between each file retrieved so it doesn’t hammer the server with traffic.  wget –html-extension –convert-links -m -w 20 http://example.com Using this command, each post and page will be saved as an HTML file. The site will be mirrored and links will be converted so I can browse them locally. The last parameter places 20 second intervals between each file retrieved to help prevent overloading the web server. Keep in mind that this is saving the output of a post or page into an HTML file. This method should not be used as the primary means of backing up a website. Results Of The WGET Command The Command Line Proves Superior To The GUI A popular alternative to WGET is WinHTTrack. Unfortunately, I couldn’t figure out how to get it to provide me with more than just the index.html of the site.  I found WinHTTrack to be confusing and hard to use. I spent a few hours trying several different programs to archive the output of websites. Most were hard to use or didn’t provide an easy to use interface. While I normally don’t use the command line to accomplish a task, it was superior in this case. Going back to our scenario, it’s entirely possible to archive a site you don’t have access to thanks to WGET and similar tools. What tools or software do you recommend for archiving the output of a website?\'>WPTavern: How To Archive A Site You Don’t Have Access To</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/how-to-share-beer-recipes-in-wordpress?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=how-to-share-beer-recipes-in-wordpress\' title=\'photo credit: adambarhan – cc Whether lager or ale, malty or hoppy, ice cold or room temperature, from a bottle, can, pint or stein, there’s no bad way to enjoy a brewski (unless you’ve had one too many). From ancient Egypt and Mesopotamia to all corners of the globe today, there is no denying beer’s popularity, as can also be observed by the continued rise in the craft brew movement and the homebrewing community. The American Homebrewers Association has registered over 1,700 homebrew clubs with individual memberships estimated in the millions. Part of the joy of homebrewing is the art of putting different recipes together and discovering new flavors, exploring new styles of beer and tinkering with ingredients. This recipe creation process used to require quite a few calculations and a rather expansive knowledge of ingredients, hops, yeasts and brewing techniques in order to brew a particular style. However, creating and saving beer recipes is much easier today, thanks to programs like BeerSmith and websites like Brewtoad that combine extensive databases of ingredients with built-in calculators that can help novice brewers create and share their recipes. And now, it’s easy to share homebrew recipes on your WordPress site, thanks to the BeerXML Shortcode plugin. Derek Springer, the plugin’s creator, is currently a Code Wrangler at Automattic and an avid homebrewer. His plugin takes an XML beer recipe and displays it nicely on the page via a shortcode.  The BeerXML Shortcode plugin features the following:  Link to a BeerXML document to display recipe details, style details, fermentables, hops, miscs, yeast, and notes Allows you to easily switch between U.S. and Metric measurements Control if and how long recipe is cached Allow readers to download the recipe directly  BeerXML Shortcode makes it possible for you to create your own library of recipes on your site and open them up for visitor feedback in WordPress posts or pages. Since WordPress is search engine friendly, adding recipes to posts makes easier for others to discover and try. The plugin also lets you provide a recipe for download as an XML file, which can easily be imported into BeerSmith and/or other brewing programs where the next brewer can tweak and change it as necessary. The open source software community and homebrewers have a good deal in common. Sharing a beer recipe is like open sourcing happiness. The days of secret family recipes hidden away from the competition have fallen aside with the explosion of craft brew culture, which values sharing and openness. Recipe sharing gets more people brewing and promotes the appreciation of craft beer. As the saying goes: “Give a man a beer and he’ll waste an hour. Teach a man to homebrew and he’ll waste a lifetime.” The BeerXML Shortcode plugin is available for free from the WordPress plugin directory. Add it to your site to start sharing your beer recipes with the world.\'>WPTavern: How to Share Beer Recipes in WordPress</a></li></ul></div><div class="rss-widget"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'http://wordpress.org/plugins/better-wp-security/\' class=\'dashboard-news-plugin-link\'>iThemes Security (formerly Better WP Security)</a></h5>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=better-wp-security&amp;_wpnonce=b7830f8e67&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'iThemes Security (formerly Better WP Security)\'>Install</a>)</span></li></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (1108, '_site_transient_timeout_browser_0f5d8990db4df2d31f9107f57dccea47', '1399427196', 'yes') ; 
INSERT INTO `wp_options` VALUES (1109, '_site_transient_browser_0f5d8990db4df2d31f9107f57dccea47', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:7:"Firefox";s:7:"version";s:4:"28.0";s:10:"update_url";s:23:"http://www.firefox.com/";s:7:"img_src";s:50:"http://s.wordpress.org/images/browsers/firefox.png";s:11:"img_src_ssl";s:49:"https://wordpress.org/images/browsers/firefox.png";s:15:"current_version";s:2:"16";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1110, 'rewrite_rules', 'a:110:{s:10:"project/?$";s:27:"index.php?post_type=project";s:40:"project/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=project&feed=$matches[1]";s:35:"project/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=project&feed=$matches[1]";s:27:"project/page/([0-9]{1,})/?$";s:45:"index.php?post_type=project&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:35:"project/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"project/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"project/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"project/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"project/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"project/([^/]+)/trackback/?$";s:34:"index.php?project=$matches[1]&tb=1";s:48:"project/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?project=$matches[1]&feed=$matches[2]";s:43:"project/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?project=$matches[1]&feed=$matches[2]";s:36:"project/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?project=$matches[1]&paged=$matches[2]";s:43:"project/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?project=$matches[1]&cpage=$matches[2]";s:28:"project/([^/]+)(/[0-9]+)?/?$";s:46:"index.php?project=$matches[1]&page=$matches[2]";s:24:"project/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"project/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"project/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"project/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"project/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:57:"project_category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:55:"index.php?project_category=$matches[1]&feed=$matches[2]";s:52:"project_category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:55:"index.php?project_category=$matches[1]&feed=$matches[2]";s:45:"project_category/([^/]+)/page/?([0-9]{1,})/?$";s:56:"index.php?project_category=$matches[1]&paged=$matches[2]";s:27:"project_category/([^/]+)/?$";s:38:"index.php?project_category=$matches[1]";s:52:"project_tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?project_tag=$matches[1]&feed=$matches[2]";s:47:"project_tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?project_tag=$matches[1]&feed=$matches[2]";s:40:"project_tag/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?project_tag=$matches[1]&paged=$matches[2]";s:22:"project_tag/([^/]+)/?$";s:33:"index.php?project_tag=$matches[1]";s:40:"et_pb_layout/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:50:"et_pb_layout/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:70:"et_pb_layout/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"et_pb_layout/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"et_pb_layout/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"et_pb_layout/([^/]+)/trackback/?$";s:54:"index.php?post_type=et_pb_layout&name=$matches[1]&tb=1";s:41:"et_pb_layout/([^/]+)/page/?([0-9]{1,})/?$";s:67:"index.php?post_type=et_pb_layout&name=$matches[1]&paged=$matches[2]";s:48:"et_pb_layout/([^/]+)/comment-page-([0-9]{1,})/?$";s:67:"index.php?post_type=et_pb_layout&name=$matches[1]&cpage=$matches[2]";s:33:"et_pb_layout/([^/]+)(/[0-9]+)?/?$";s:66:"index.php?post_type=et_pb_layout&name=$matches[1]&page=$matches[2]";s:29:"et_pb_layout/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:39:"et_pb_layout/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:59:"et_pb_layout/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"et_pb_layout/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"et_pb_layout/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=50&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1127, '_site_transient_timeout_theme_roots', '1398830031', 'yes') ; 
INSERT INTO `wp_options` VALUES (1128, '_site_transient_theme_roots', 'a:5:{s:10:"Divi-Child";s:7:"/themes";s:4:"Divi";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";s:12:"twentytwelve";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1129, '_transient_doing_cron', '1398828428.3972010612487792968750', 'yes') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://localhost:8080/fixitall MySQL database backup
#
# Generated: Wednesday 30. April 2014 03:27 UTC
# Hostname: localhost
# Database: `fixitall`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_messages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_emails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_stats`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_postmeta (117 records)
#
 
INSERT INTO `wp_postmeta` VALUES (4, 5, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (5, 6, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (6, 7, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (7, 8, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (8, 9, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (9, 10, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (10, 11, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (11, 12, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (12, 13, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (13, 14, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (14, 15, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (15, 16, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (16, 17, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (17, 18, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (18, 19, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (19, 20, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (20, 21, '_wp_attached_file', '2014/02/vmax.png') ; 
INSERT INTO `wp_postmeta` VALUES (21, 21, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:150;s:6:"height";i:43;s:4:"file";s:16:"2014/02/vmax.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (22, 22, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (23, 23, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (24, 24, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (25, 25, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (26, 26, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (27, 27, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (28, 28, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (29, 29, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (30, 30, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (31, 31, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (32, 32, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (33, 33, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (34, 34, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (35, 35, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (36, 36, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (37, 37, '_et_pb_predefined_layout', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (38, 38, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (39, 38, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (40, 38, '_menu_item_object_id', '38') ; 
INSERT INTO `wp_postmeta` VALUES (41, 38, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (42, 38, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (43, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (44, 38, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (45, 38, '_menu_item_url', 'http://localhost:8080/fixitall//') ; 
INSERT INTO `wp_postmeta` VALUES (56, 41, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (57, 41, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (58, 41, '_edit_lock', '1398793975:1') ; 
INSERT INTO `wp_postmeta` VALUES (59, 41, '_et_pb_page_layout', 'et_right_sidebar') ; 
INSERT INTO `wp_postmeta` VALUES (60, 41, '_et_pb_use_builder', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (61, 41, '_et_pb_old_content', '<p>page 1 text</p>') ; 
INSERT INTO `wp_postmeta` VALUES (92, 49, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (93, 49, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (94, 49, '_menu_item_object_id', '41') ; 
INSERT INTO `wp_postmeta` VALUES (95, 49, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (96, 49, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (97, 49, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (98, 49, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (99, 49, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (101, 50, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (102, 50, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (103, 50, '_edit_lock', '1398794228:1') ; 
INSERT INTO `wp_postmeta` VALUES (104, 50, '_et_pb_page_layout', 'et_right_sidebar') ; 
INSERT INTO `wp_postmeta` VALUES (105, 50, '_et_pb_use_builder', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (106, 50, '_et_pb_old_content', '') ; 
INSERT INTO `wp_postmeta` VALUES (109, 53, '_wp_attached_file', '2014/02/plumaxlogo1.png') ; 
INSERT INTO `wp_postmeta` VALUES (110, 53, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:214;s:6:"height";i:43;s:4:"file";s:23:"2014/02/plumaxlogo1.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"plumaxlogo1-150x43.png";s:5:"width";i:150;s:6:"height";i:43;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (111, 54, '_wp_attached_file', '2014/02/plumaxfavicon1.png') ; 
INSERT INTO `wp_postmeta` VALUES (112, 54, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:64;s:6:"height";i:64;s:4:"file";s:26:"2014/02/plumaxfavicon1.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (113, 58, '_wp_attached_file', '2014/02/plumber-guy.jpeg') ; 
INSERT INTO `wp_postmeta` VALUES (114, 58, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1497;s:6:"height";i:1131;s:4:"file";s:24:"2014/02/plumber-guy.jpeg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"plumber-guy-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"plumber-guy-300x226.jpeg";s:5:"width";i:300;s:6:"height";i:226;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"plumber-guy-1024x773.jpeg";s:5:"width";i:1024;s:6:"height";i:773;s:9:"mime-type";s:10:"image/jpeg";}s:21:"et-pb-post-main-image";a:4:{s:4:"file";s:24:"plumber-guy-400x302.jpeg";s:5:"width";i:400;s:6:"height";i:302;s:9:"mime-type";s:10:"image/jpeg";}s:31:"et-pb-post-main-image-fullwidth";a:4:{s:4:"file";s:26:"plumber-guy-1080x1131.jpeg";s:5:"width";i:1080;s:6:"height";i:1131;s:9:"mime-type";s:10:"image/jpeg";}s:21:"et-pb-portfolio-image";a:4:{s:4:"file";s:24:"plumber-guy-400x284.jpeg";s:5:"width";i:400;s:6:"height";i:284;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (115, 60, '_wp_attached_file', '2014/02/plumber-guy2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (116, 60, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1080;s:6:"height";i:461;s:4:"file";s:24:"2014/02/plumber-guy2.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"plumber-guy2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"plumber-guy2-300x128.jpg";s:5:"width";i:300;s:6:"height";i:128;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"plumber-guy2-1024x437.jpg";s:5:"width";i:1024;s:6:"height";i:437;s:9:"mime-type";s:10:"image/jpeg";}s:21:"et-pb-post-main-image";a:4:{s:4:"file";s:24:"plumber-guy2-400x170.jpg";s:5:"width";i:400;s:6:"height";i:170;s:9:"mime-type";s:10:"image/jpeg";}s:21:"et-pb-portfolio-image";a:4:{s:4:"file";s:24:"plumber-guy2-400x284.jpg";s:5:"width";i:400;s:6:"height";i:284;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (117, 62, '_wp_attached_file', '2014/02/plumbing-slide2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (118, 62, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1080;s:6:"height";i:461;s:4:"file";s:27:"2014/02/plumbing-slide2.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"plumbing-slide2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"plumbing-slide2-300x128.jpg";s:5:"width";i:300;s:6:"height";i:128;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"plumbing-slide2-1024x437.jpg";s:5:"width";i:1024;s:6:"height";i:437;s:9:"mime-type";s:10:"image/jpeg";}s:21:"et-pb-post-main-image";a:4:{s:4:"file";s:27:"plumbing-slide2-400x170.jpg";s:5:"width";i:400;s:6:"height";i:170;s:9:"mime-type";s:10:"image/jpeg";}s:21:"et-pb-portfolio-image";a:4:{s:4:"file";s:27:"plumbing-slide2-400x284.jpg";s:5:"width";i:400;s:6:"height";i:284;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (119, 64, '_wp_attached_file', '2014/02/plumbing-slide3.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (120, 64, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1080;s:6:"height";i:461;s:4:"file";s:27:"2014/02/plumbing-slide3.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"plumbing-slide3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"plumbing-slide3-300x128.jpg";s:5:"width";i:300;s:6:"height";i:128;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"plumbing-slide3-1024x437.jpg";s:5:"width";i:1024;s:6:"height";i:437;s:9:"mime-type";s:10:"image/jpeg";}s:21:"et-pb-post-main-image";a:4:{s:4:"file";s:27:"plumbing-slide3-400x170.jpg";s:5:"width";i:400;s:6:"height";i:170;s:9:"mime-type";s:10:"image/jpeg";}s:21:"et-pb-portfolio-image";a:4:{s:4:"file";s:27:"plumbing-slide3-400x284.jpg";s:5:"width";i:400;s:6:"height";i:284;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (121, 50, '_thumbnail_id', '58') ; 
INSERT INTO `wp_postmeta` VALUES (126, 71, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (127, 71, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (128, 71, '_et_pb_page_layout', 'et_right_sidebar') ; 
INSERT INTO `wp_postmeta` VALUES (129, 71, '_et_pb_use_builder', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (130, 71, '_et_pb_old_content', '') ; 
INSERT INTO `wp_postmeta` VALUES (131, 71, '_edit_lock', '1392576204:1') ; 
INSERT INTO `wp_postmeta` VALUES (132, 73, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (133, 73, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (134, 73, '_et_pb_page_layout', 'et_right_sidebar') ; 
INSERT INTO `wp_postmeta` VALUES (135, 73, '_et_pb_use_builder', '') ; 
INSERT INTO `wp_postmeta` VALUES (136, 73, '_et_pb_old_content', '') ; 
INSERT INTO `wp_postmeta` VALUES (137, 73, '_edit_lock', '1392325675:1') ; 
INSERT INTO `wp_postmeta` VALUES (138, 75, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (139, 75, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (140, 75, '_menu_item_object_id', '73') ; 
INSERT INTO `wp_postmeta` VALUES (141, 75, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (142, 75, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (143, 75, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (144, 75, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (145, 75, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (147, 76, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (148, 76, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (149, 76, '_menu_item_object_id', '71') ; 
INSERT INTO `wp_postmeta` VALUES (150, 76, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (151, 76, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (152, 76, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (153, 76, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (154, 76, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (156, 93, '_wp_attached_file', '2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (157, 93, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:200;s:4:"file";s:46:"2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:46:"Drain-by-Seannnnnnn-e1374301069177-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (158, 107, '_wp_attached_file', '2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (159, 107, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:200;s:4:"file";s:58:"2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:58:"Root-Intrusion-by-Wilf-Ratzburg-e1374302277479-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (160, 114, '_wp_attached_file', '2014/02/Gas-leak-by-Crow-Girl-e1374331227435.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (161, 114, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:200;s:4:"file";s:48:"2014/02/Gas-leak-by-Crow-Girl-e1374331227435.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:48:"Gas-leak-by-Crow-Girl-e1374331227435-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (162, 117, '_wp_attached_file', '2014/02/Reinstall-Pipes-by-Michaela-Kobyakov-V-Max-plumbing-e1374362282501.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (163, 117, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:200;s:4:"file";s:78:"2014/02/Reinstall-Pipes-by-Michaela-Kobyakov-V-Max-plumbing-e1374362282501.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:78:"Reinstall-Pipes-by-Michaela-Kobyakov-V-Max-plumbing-e1374362282501-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (166, 1, '_edit_lock', '1392332593:1') ; 
INSERT INTO `wp_postmeta` VALUES (167, 1, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (169, 1, '_et_pb_page_layout', 'et_right_sidebar') ; 
INSERT INTO `wp_postmeta` VALUES (174, 133, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (175, 133, '_edit_lock', '1398799020:1') ; 
INSERT INTO `wp_postmeta` VALUES (177, 133, '_et_pb_page_layout', 'et_right_sidebar') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://localhost:8080/fixitall MySQL database backup
#
# Generated: Wednesday 30. April 2014 03:27 UTC
# Hostname: localhost
# Database: `fixitall`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_messages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_emails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_stats`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_posts (137 records)
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2014-02-13 15:22:52', '2014-02-13 15:22:52', 'CHARLESTON, W.Va. -- West Virginia will fund an independent team of experts to test water in homes to try to determine long-term effects of the Elk River chemical spill, Gov. Earl Ray Tomblin announced Tuesday.

Over the next three weeks, the team will test water in the home plumbing systems of 10 private homes: one in each of the nine affected counties, plus an extra home in Kanawha County.

The study -- called the West Virginia Testing Assessment Project, or WVTAP -- will have three main objectives. The team will convene a group of independent experts to evaluate the West Virginia\'s testing threshold of 10 parts per billion of Crude MCHM in water -- its usefulness as well as its limitations.

Second, a team of four scientists, let by Andrew Whelton, an environmental scientist from the University of South Alabama, will test water in homes to try to determine how Crude MCHM, and the other spilled chemical, PPH, interact with, and potentially stick to, different types of pipes.

Finally, the study also wants to find out the odor threshold of Crude MCHM -- how little of the chemical can be in the water in order for people to be able to smell it.

"The scale of chemical contamination of the drinking water in Charleston, W.Va., has been unprecedented," Whelton said at a Tuesday-evening news conference with Tomblin. "There is so little data available, many federal and state agencies could not and still cannot answer all the questions West Virginians are demanding to be answered."

Jeffrey Rosen, of Corona Environmental Consulting, will help Whelton conduct the study.

The 10 homes already have been selected. They are homes of people Whelton has been in touch with since he first arrived in West Virginia to do water crisis-related research three weeks ago.

Whelton\'s team will go into the homes accompanied by staff from local volunteer fire departments. They will sample hot and cold water -- about 21 gallons -- from the kitchen and the most commonly used bathroom. They will examine the plumbing, as different homes may have copper, iron, PVC or other plastic pipes.

Testing will be done at independent labs, and Whelton\'s team will not report to any state agency.

Once the initial round of 10 home tests is complete, the team will release preliminary results. They will then do more than 100 tests in additional homes around the region, Whelton said.

Tomblin has committed $650,000 from the state budget to fund the study, but he admitted Tuesday that that probably would not be nearly enough money. He said he has asked West Virginia\'s congressional delegation for help in securing federal money to further fund the study.

Asked how much federal money he thought would be needed, Tomblin said, "A lot."

"To be frank, this is an unprecedented disaster," Whelton said, adding that "$650,000 is a lot of money, but long-term monitoring is needed."

He said that with the help of the National Science Foundation and the National Institutes of Health, researchers need to begin more toxicological studies and animal studies as soon as possible.

Tomblin said West Virginia American Water President Jeff McIntyre told him at their last meeting that the company would offer money for home testing if the state needed it. The governor said they have not yet requested any financial assistance.', 'Study to test home plumbing for MCHM', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2014-02-13 23:02:55', '2014-02-13 23:02:55', '', 0, 'http://localhost:8080/fixitall//?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (5, 1, '2014-02-13 15:25:09', '2014-02-13 15:25:09', '
[et_pb_section fullwidth="on"]
[et_pb_fullwidth_slider show_arrows="on" show_pagination="on" parallax="on" auto="off" auto_speed="7000"]
[et_pb_slide heading="Designed With Passion" background_image="http://www.elegantthemesimages.com/images/premade_bg.jpg" button_text="Join Today" background_color="#492144" button_link="http://elegantthemes.com"]No matter how you use Divi, your website is going to look great. Everything about Divi has been built beautifully and purposefully by our passionate team. We are so excited to release this labor of love to our community.[/et_pb_slide]
[et_pb_slide heading="Elegantly Responsive" button_text="Join Today" background_color="#6aceb6" button_link="http://elegantthemes.com" image="http://www.elegantthemesimages.com/images/premade_iphone_slider.png" image_alt="Alt text for the image"]Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl. Cras venenatis.[/et_pb_slide]
[/et_pb_fullwidth_slider]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_1.png" title="Advanced Page Builder"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_2.png" title="Elegant Shortcodes"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_3.png" title="Fully Responsive"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_4.png" title="Perpetual Updates"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#f5f5f5" inner_shadow="on"]
[et_pb_row]
[et_pb_column type="2_3"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_iphone_half.png" animation="left"][/et_pb_image]
[/et_pb_column]
[et_pb_column type="1_3"]
[et_pb_divider color="#eee" show_divider="off" height="120"][/et_pb_divider]
[et_pb_text]
<h2>It\'s Elegantly Responsive</h2>
Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante. In vitae tempus nunc. Etiam adipiscing enim sed condimentum ultrices. Cras rutrum blandit sem, molestie consequat erat luctus vel. Cras nunc est, laoreet sit amet ligula et, eleifend commodo dui. Vivamus id blandit nisi, eu mattis odio.
[/et_pb_text]
[et_pb_counters]
[et_pb_counter percent="50"]Smart[/et_pb_counter]
[et_pb_counter percent="80"]Flexible[/et_pb_counter]
[et_pb_counter percent="40"]Beautiful[/et_pb_counter]
[/et_pb_counters]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="1_4"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_logo-1.jpg" animation="top"][/et_pb_image]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_logo-2.jpg" animation="top"][/et_pb_image]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_logo-3.jpg" animation="top"][/et_pb_image]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_logo-4.jpg" animation="top"][/et_pb_image]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#f5f5f5" inner_shadow="on"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_text text_orientation="center"]
<h2>With Our Most Advanced Page Builder Yet.</h2>
Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus dolor ipsum amet sit.
[/et_pb_text]
[/et_pb_column]
[/et_pb_row]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_macbook.png" animation="top"][/et_pb_image]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#7cbec6"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_cta title="Signup Today For Instant Access" button_url="http://elegantthemes.com/preview/Divi/join/" button_text="Join Today" background_layout="dark" background_color="none"]
Join today and get access to Divi, as well as our other countless themes and plugins.
[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Homepage', '', 'publish', 'open', 'open', '', 'homepage', '', '', '2014-02-13 15:25:09', '2014-02-13 15:25:09', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=5', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6, 1, '2014-02-13 15:25:09', '2014-02-13 15:25:09', '
[et_pb_section]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_slider show_arrows="on" show_pagination="on" parallax="off" auto="off" auto_speed="7000"]
[et_pb_slide heading="Divi" button_text="Join Today" background_color="#444b5d" background_image="http://www.elegantthemesimages.com/images/premade_bg.jpg" button_link="http://elegantthemes.com" image="http://www.elegantthemesimages.com/images/premade-logo.png" image_alt="Alt text for the image"]Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl.[/et_pb_slide]
[et_pb_slide heading="Divi" button_text="Join Today" background_color="#144d6a" background_image="http://www.elegantthemesimages.com/images/premade_bg_2.jpg" button_link="http://elegantthemes.com"]The only theme you will ever need.[/et_pb_slide]
[/et_pb_slider]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_1.png"  title="Advanced Page Builder"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_2.png"  title="Elegant Shortcodes"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_3.png"  title="Fully Responsive"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_4.png"  title="Perpetual Updates"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[/et_pb_row]


[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_divider height="1" show_divider="on"][/et_pb_divider]
[/et_pb_column]
[/et_pb_row]

[et_pb_row]
[et_pb_column type="1_3"]
[et_pb_text]<h1 style="font-size: 32px;">STUNNING PORTFOLIOS</h1>[/et_pb_text]
[/et_pb_column]
[et_pb_column type="1_3"]
[et_pb_text]With Divi’s portfolio module, you can show off your work anywhere on your site. Choose from our premade portfolio layouts, or create one entirely from scratch![/et_pb_text]
[/et_pb_column]
[et_pb_column type="1_3"]
[et_pb_image src="http://elegantthemesimages.com/images/premade-portfolios.gif" animation="right"][/et_pb_image]
[/et_pb_column]
[/et_pb_row]

[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_divider height="1" show_divider="on"][/et_pb_divider]
[/et_pb_column]
[/et_pb_row]

[et_pb_row]
[et_pb_column type="1_3"]
[et_pb_text]<h1 style="font-size: 32px;">ECOMMERCE INTEGRATION</h1>[/et_pb_text]
[/et_pb_column]
[et_pb_column type="1_3"]
[et_pb_text]Divi has what you need to get an online store up and running in no time. We’ve included a couple of premade store layouts, and the store module lets you sell anywhere on your site.[/et_pb_text]
[/et_pb_column]
[et_pb_column type="1_3"]
[et_pb_image src="http://elegantthemesimages.com/images/premade-ecommerce.gif" animation="right"][/et_pb_image]
[/et_pb_column]
[/et_pb_row]


[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_cta title="Signup Today For Instant Access" button_url="http://elegantthemes.com/preview/Divi/join/" button_text="Join Today" background_layout="dark" background_color="#7EBEC5"]
Join today and get access to Divi, as well as our other countless themes and plugins.
[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Homepage Simple', '', 'publish', 'open', 'open', '', 'homepage-simple', '', '', '2014-02-13 15:25:09', '2014-02-13 15:25:09', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=6', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7, 1, '2014-02-13 15:25:09', '2014-02-13 15:25:09', '
[et_pb_section fullwidth="on"]
[et_pb_fullwidth_slider show_arrows="on" show_pagination="on" parallax="on" auto="off" auto_speed="7000"]
[et_pb_slide heading="Welcome To Our Store" background_image="http://www.elegantthemesimages.com/images/premade_bg.jpg" button_text="View Special Offers" background_color="#492144" button_link="http://elegantthemes.com"]No matter how you use Divi, your website is going to look great. Everything about Divi has been built beautifully and purposefully by our passionate team. We are so excited to release this labor of love to our community.[/et_pb_slide]
[et_pb_slide heading="Today\'s Sale Items" button_text="Order Today" background_color="#6aceb6" button_link="http://elegantthemes.com" image="http://www.elegantthemesimages.com/images/premade_image_800x600.png" image_alt="Alt text for the image"]Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl. Cras venenatis.[/et_pb_slide]
[/et_pb_fullwidth_slider]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_shop posts_number="12" type="recent"][/et_pb_shop]
[/et_pb_column]
[/et_pb_row]
[et_pb_row]
[et_pb_column type="1_2"]
[et_pb_cta title="The Holiday Special Sale" button_url="http://elegantthemes.com/preview/Divi/join/" button_text="Redeem This Offer" background_layout="dark" background_color="#7ebec5"]
For a limited time only, all of our holiday products are 50% off! Don\'t miss your chance to save big on these wonderful items.[/et_pb_cta]
[/et_pb_column]
[et_pb_column type="1_2"]
[et_pb_cta title="The Holiday Special Sale" button_url="http://elegantthemes.com/preview/Divi/join/" button_text="Redeem This Offer" background_layout="light" background_color="#fff"]
For a limited time only, all of our holiday products are 50% off! Don\'t miss your chance to save big on these wonderful items.[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#f5f5f5" inner_shadow="on"]
[et_pb_row]
[et_pb_column type="1_2"]
[et_pb_text]
<h2>Products On Sale</h2>
Take a look at these special offers.
[/et_pb_text]
[et_pb_shop posts_number="4" type="sale" columns="2"][/et_pb_shop]
[/et_pb_column]
[et_pb_column type="1_2"]
[et_pb_text]
<h2>Top Rated Products</h2>
A list of our latest products.[/et_pb_text]
[et_pb_shop posts_number="4" type="top_rated" columns="2"][/et_pb_shop]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#7EBEC5"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_cta title="Signup Today For Instant Access" button_url="http://elegantthemes.com/preview/Divi/join/" button_text="Join Today" background_layout="dark" background_color="none"]
Join today and get access to Divi, as well as our other countless themes and plugins.
[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Homepage Store', '', 'publish', 'open', 'open', '', 'homepage-store', '', '', '2014-02-13 15:25:09', '2014-02-13 15:25:09', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=7', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8, 1, '2014-02-13 15:25:10', '2014-02-13 15:25:10', '
[et_pb_section background_color="#6aceb6" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="Contact Our Company" subhead="If you have any questions, we would love to help." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="1_2"]
[et_pb_contact_form title="Get In Touch"][/et_pb_contact_form]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_text]
<h3>Contact Information</h3>
<p>Cras rutrum blandit sem, molestie consequat erat luctus vel. Cras nunc est, laoreet sit amet ligula et, eleifend commodo dui.</p>
[/et_pb_text]
[et_pb_text]
<p>
<strong>Phone:</strong> 343.554.2466
<strong>Fax:</strong> 888.343.3467
<strong>eMail:</strong> contact@somewebsite.com
</p>
[/et_pb_text]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_text]
<h3>Location & Hours</h3>
<p>Vivamus id blandit nisi, eu mattis odio. Nulla facilisi. Aenean in mi. Cras rutrum blandit sem, molestie consequat erat luctus vel.</p>
[/et_pb_text]
[et_pb_text]
<p>
<strong>Address:</strong> 4323 Divi Street
Some City, California, 33432
<strong>Hours:</strong> Mon-Fri, 9:00AM-6:00PM
</p>
[/et_pb_text]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Contact', '', 'publish', 'open', 'open', '', 'contact', '', '', '2014-02-13 15:25:10', '2014-02-13 15:25:10', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=8', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (9, 1, '2014-02-13 15:25:10', '2014-02-13 15:25:10', '
[et_pb_section fullwidth="on"]
[et_pb_fullwidth_slider show_arrows="on" show_pagination="on" parallax="on" auto="off" auto_speed="7000"]
[et_pb_slide heading="Join Today" background_image="http://www.elegantthemesimages.com/images/premade_bg_2.jpg" button_text="Join Today" background_color="#144d6a" button_link="http://elegantthemes.com"]No matter how you use Divi, your website is going to look great. Everything about Divi has been built beautifully and purposefully by our passionate team. We are so excited to release this labor of love to our community.[/et_pb_slide]
[et_pb_slide heading="The Best Deal" button_text="Join Today" background_color="#6aceb6" button_link="http://elegantthemes.com" image="http://www.elegantthemesimages.com/images/premade_iphone_slider.png" image_alt="Alt text for the image"]Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl. Cras venenatis.[/et_pb_slide]
[/et_pb_fullwidth_slider]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_1.png"  title="Advanced Page Builder"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_2.png"  title="Elegant Shortcodes"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_3.png"  title="Fully Responsive"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_4.png"  title="Perpetual Updates"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#f7f7f7"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_divider height="60"][/et_pb_divider]
[et_pb_pricing_tables]
[et_pb_pricing_table title="Beginnger" currency="$" per="yr" sum="19" button_url="http://elegantthemes.com" button_text="Sign Up!"]
Access to <a href="#">All Themes</a>
Perpetual Theme Updates
-Premium Technical Support
-Access to <a href="#">All Plugins</a>
-Layered Photoshop Files
-No Yearly Fees
[/et_pb_pricing_table]
[et_pb_pricing_table title="Personal" currency="$" per="yr" sum="39" button_url="http://elegantthemes.com" button_text="Sign Up!"]
Access to <a href="#">All Themes</a>
Perpetual Theme Updates
Premium Technical Support
-Access to <a href="#">All Plugins</a>
-Layered Photoshop Files
-No Yearly Fees
[/et_pb_pricing_table]
[et_pb_pricing_table featured="on" title="Developer" subtitle="The Best Deal" currency="$" per="yr" sum="89" button_url="http://elegantthemes.com" button_text="Sign Up!"]
Access to <a href="#">All Themes</a>
Perpetual Theme Updates
Premium Technical Support
Access to <a href="#">All Plugins</a>
Layered Photoshop Files
-No Yearly Fees
[/et_pb_pricing_table]
[et_pb_pricing_table title="Lifetime" currency="$" per="yr" sum="249" button_url="http://elegantthemes.com" button_text="Sign Up!"]
Access to <a href="#">All Themes</a>
Perpetual Theme Updates
Premium Technical Support
Access to <a href="#">All Plugins</a>
Layered Photoshop Files
No Yearly Fees
[/et_pb_pricing_table]
[/et_pb_pricing_tables]
[et_pb_divider height="60"][/et_pb_divider]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section inner_shadow="on" background_color="#eeeeee"]
[et_pb_row]
[et_pb_column type="1_4"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_logo-1.jpg" animation="top"][/et_pb_image]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_logo-2.jpg" animation="top"][/et_pb_image]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_logo-3.jpg" animation="top"][/et_pb_image]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_logo-4.jpg" animation="top"][/et_pb_image]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_text text_orientation="center" background_layout="light"]
<h2>What Our Customers Are Saying.</h2>
Don\'t just take it from us, let our customers do the talking!
[/et_pb_text]
[/et_pb_column]
[/et_pb_row]
[et_pb_row]
[et_pb_column type="1_3"]
[et_pb_testimonial author="John Doe"]<p>"Aliquam pellentesque hendrerit commodo. Sed hendrerit blandit justo quis feugiat. Curabitur ut consequat odio. Nunc risus mi, consectetur et dolor a, dignissim vehicula nibh. Vestibulum adipiscing adipiscing consectetur. Vestibulum aliquam dignissim volutpat. Curabitur dictum, quam vitae fringilla aliquet, ligula justo placerat nisi, ut semper sapien elit eget augue. Maecenas et feugiat nisi. Nulla in velit et orci dictum gravida. Donec sagittis cursus luctus. Aliquam vel convallis leo. Donec urna sapien, suscipit et ultricies at, sodales in dui."</p>[/et_pb_testimonial]
[/et_pb_column]
[et_pb_column type="1_3"]
[et_pb_testimonial author="John Doe"]<p>"Aliquam pellentesque hendrerit commodo. Sed hendrerit blandit justo quis feugiat. Curabitur ut consequat odio. Nunc risus mi, consectetur et dolor a, dignissim vehicula nibh. Vestibulum adipiscing adipiscing consectetur. Vestibulum aliquam dignissim volutpat. Curabitur dictum, quam vitae fringilla aliquet, ligula justo placerat nisi, ut semper sapien elit eget augue. Maecenas et feugiat nisi. Nulla in velit et orci dictum gravida. Donec sagittis cursus luctus. Aliquam vel convallis leo. Donec urna sapien, suscipit et ultricies at, sodales in dui."</p>[/et_pb_testimonial]
[/et_pb_column]
[et_pb_column type="1_3"]
[et_pb_testimonial author="John Doe"]<p>"Aliquam pellentesque hendrerit commodo. Sed hendrerit blandit justo quis feugiat. Curabitur ut consequat odio. Nunc risus mi, consectetur et dolor a, dignissim vehicula nibh. Vestibulum adipiscing adipiscing consectetur. Vestibulum aliquam dignissim volutpat. Curabitur dictum, quam vitae fringilla aliquet, ligula justo placerat nisi, ut semper sapien elit eget augue. Maecenas et feugiat nisi. Nulla in velit et orci dictum gravida. Donec sagittis cursus luctus. Aliquam vel convallis leo. Donec urna sapien, suscipit et ultricies at, sodales in dui."</p>[/et_pb_testimonial]
[/et_pb_column]
[/et_pb_row]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_toggle title="Can I use the themes on multiple sites?"]
Yes, you are free to use our themes on as many websites as you like. We do not place any restrictions on how many times you can download or use a theme, nor do we limit the number of domains that you can install our themes to.
[/et_pb_toggle]
[et_pb_toggle open="on" title="What is your refund policy?"]
We offer no-questions-asked refunds to all customers within 30 days of your purchase. If you are not satisfied with our product, then simply send us an email and we will refund your purchase right away. Our goal has always been to create a happy, thriving community. If you are not thrilled with the product or are not enjoying the experience, then we have no interest in forcing you to stay an unhappy member.
[/et_pb_toggle]
[et_pb_toggle title="What are Photoshop Files?"]
Elegant Themes offers two different packages: Personal and Developer. The Personal Subscription is ideal for the average user while the Developers License is meant for experienced designers who wish to customize their themes using the original Photoshop files. Photoshop files are the original design files that were used to create the theme. They can be opened using Adobe Photoshop and edited, and prove very useful for customers wishing to change their theme\'s design in some way.
[/et_pb_toggle]
[et_pb_toggle title="Can I upgrade after signing up?"]
Yes, you can upgrade at any time after signing up. When you log in as a "personal" subscriber, you will see a notice regarding your current package and instructions on how to upgrade.
[/et_pb_toggle]
[et_pb_toggle title="Can I use your themes with WP.com?"]
Unfortunately WordPress.com does not allow the use of custom themes. If you would like to use a custom theme of any kind, you will need to purchase your own hosting account and install the free software from WordPress.org. If you are looking for great WordPress hosting, we recommend giving HostGator a try.[/et_pb_toggle]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#7EBEC5"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_cta title="Join Today For Instant Access." button_url="#" button_text="Contact Me" background_layout="dark" background_color="none"]
We have the best product around. Don\'t miss out on this great opportunity!
[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Join', '', 'publish', 'open', 'open', '', 'join', '', '', '2014-02-13 15:25:10', '2014-02-13 15:25:10', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=9', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (10, 1, '2014-02-13 15:25:10', '2014-02-13 15:25:10', '
[et_pb_section background_color="#6aceb6" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="My Portfolio" subhead="Your subtitle goes right here." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_portfolio fullwidth="off"][/et_pb_portfolio]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#7EBEC5"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_cta title="Don\'t Be Shy. Get In Touch." button_url="#" button_text="Contact Me" background_layout="dark" background_color="none"]
If you are interested in working together, send me an inquiry and I will get back to you as soon as I can!
[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Portfolio', '', 'publish', 'open', 'open', '', 'portfolio', '', '', '2014-02-13 15:25:10', '2014-02-13 15:25:10', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=10', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (11, 1, '2014-02-13 15:25:10', '2014-02-13 15:25:10', '
[et_pb_section background_color="#ef8f61" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="Welcome To Our Shop" subhead="Your subtitle goes right here." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_shop posts_number="12" type="recent"][/et_pb_shop]
[/et_pb_column]
[/et_pb_row]
[et_pb_row]
[et_pb_column type="1_2"]
[et_pb_cta title="The Holiday Special Sale" button_url="http://elegantthemes.com/preview/Divi/join/" button_text="Redeem This Offer" background_layout="dark" background_color="#7ebec5"]
For a limited time only, all of our holiday products are 50% off! Don\'t miss your chance to save big on these wonderful items.[/et_pb_cta]
[/et_pb_column]
[et_pb_column type="1_2"]
[et_pb_cta title="The Holiday Special Sale" button_url="http://elegantthemes.com/preview/Divi/join/" button_text="Redeem This Offer" background_layout="light" background_color="#fff"]
For a limited time only, all of our holiday products are 50% off! Don\'t miss your chance to save big on these wonderful items.[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#f5f5f5" inner_shadow="on"]
[et_pb_row]
[et_pb_column type="1_2"]
[et_pb_text]<h2>Products On Sale</h2>
Take a look at these special offers.
[/et_pb_text]
[et_pb_shop posts_number="4" type="sale" columns="2"][/et_pb_shop]
[/et_pb_column]
[et_pb_column type="1_2"]
[et_pb_text]<h2>Top Rated Products</h2>
A list of our latest products.[/et_pb_text]
[et_pb_shop posts_number="4" type="top_rated" columns="2"][/et_pb_shop]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#7EBEC5"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_cta title="Signup Today For Instant Access" button_url="http://elegantthemes.com/preview/Divi/join/" button_text="Join Today" background_layout="dark" background_color="none"]
Join today and get access to Divi, as well as our other countless themes and plugins.
[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Shop Extended', '', 'publish', 'open', 'open', '', 'shop-extended', '', '', '2014-02-13 15:25:10', '2014-02-13 15:25:10', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=11', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (12, 1, '2014-02-13 15:25:10', '2014-02-13 15:25:10', '
[et_pb_section background_color="#ef8f61" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="Welcome To Our Shop" subhead="Your subtitle goes right here." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_shop posts_number="12" type="recent"][/et_pb_shop]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#7EBEC5"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_cta title="Signup Today For Instant Access" button_url="http://elegantthemes.com/preview/Divi/join/" button_text="Join Today" background_layout="dark" background_color="none"]
Join today and get access to Divi, as well as our other countless themes and plugins.
[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Shop Basic', '', 'publish', 'open', 'open', '', 'shop-basic', '', '', '2014-02-13 15:25:10', '2014-02-13 15:25:10', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=12', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (13, 1, '2014-02-13 15:25:10', '2014-02-13 15:25:10', '
[et_pb_section background_color="#7ebec5" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="Tiled Blog Layout" subhead="Your subtitle goes right here." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="2_3"]
[et_pb_blog fullwidth="off" posts_number="6" meta_date="M j, Y" show_thumbnail="on" show_content="off" show_author="on" show_date="on" show_categories="on"][/et_pb_blog]
[/et_pb_column]
[et_pb_column type="1_3"]
[et_pb_sidebar area="sidebar-1" orientation="right"][/et_pb_sidebar]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Blog Tiled', '', 'publish', 'open', 'open', '', 'blog-tiled', '', '', '2014-02-13 15:25:10', '2014-02-13 15:25:10', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=13', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (14, 1, '2014-02-13 15:25:10', '2014-02-13 15:25:10', '
[et_pb_section background_color="#7ebec5" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="Standard Blog Layout" subhead="Your subtitle goes right here." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="1_4"]
[et_pb_sidebar area="sidebar-1" orientation="left"][/et_pb_sidebar]
[/et_pb_column]
[et_pb_column type="3_4"]
[et_pb_blog fullwidth="on" posts_number="6" meta_date="M j, Y" show_thumbnail="on" show_content="off" show_author="on" show_date="on" show_categories="on"][/et_pb_blog]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Blog Standard', '', 'publish', 'open', 'open', '', 'blog-standard', '', '', '2014-02-13 15:25:10', '2014-02-13 15:25:10', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=14', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (15, 1, '2014-02-13 15:25:10', '2014-02-13 15:25:10', '
[et_pb_section background_color="#6aceb6" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="About Our Team" subhead="Your subtitle goes right here." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="1_3"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_image_800x600.png" animation="left"][/et_pb_image]
[et_pb_text]
<h2>Nick Roach</h2>
<em>President, CEO, Theme UI/UX Designer</em>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent mattis nec nisi non luctus. Donec aliquam non nisi ut rutrum. In sit amet vestibulum felis, id aliquet ipsum. Vestibulum feugiat lacinia aliquet.
[/et_pb_text]
[et_pb_counters]
[et_pb_counter percent="50"]Design & UX[/et_pb_counter]
[et_pb_counter percent="80"]Web Programming[/et_pb_counter]
[et_pb_counter percent="10"]Internet Marketing[/et_pb_counter]
[/et_pb_counters]
[/et_pb_column]

[et_pb_column type="1_3"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_image_800x600.png" animation="top"][/et_pb_image]
[et_pb_text]
<h2>Kenny Sing</h2>
<em>Lead Graphic Designers</em>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent mattis nec nisi non luctus. Donec aliquam non nisi ut rutrum. In sit amet vestibulum felis, id aliquet ipsum. Vestibulum feugiat lacinia aliquet.
[/et_pb_text]
[et_pb_counters]
[et_pb_counter percent="85"]Photoshop[/et_pb_counter]
[et_pb_counter percent="70"]After Effects[/et_pb_counter]
[et_pb_counter percent="50"]Illustrator[/et_pb_counter]
[/et_pb_counters]
[/et_pb_column]

[et_pb_column type="1_3"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_image_800x600.png" animation="right"][/et_pb_image]
[et_pb_text]
<h2>Mitch Skolnik</h2>
<em>Community Manager</em>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent mattis nec nisi non luctus. Donec aliquam non nisi ut rutrum. In sit amet vestibulum felis, id aliquet ipsum. Vestibulum feugiat lacinia aliquet.
[/et_pb_text]
[et_pb_counters]
[et_pb_counter percent="80"]Customer Happiness[/et_pb_counter]
[et_pb_counter percent="30"]Tech Support[/et_pb_counter]
[et_pb_counter percent="50"]Community Management[/et_pb_counter]
[/et_pb_counters]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#2d3743" inner_shadow="on"]
[et_pb_row]
[et_pb_column type="1_4"]
[et_pb_blurb background_layout="dark" image="http://www.elegantthemesimages.com/images/premade_blurb_5.png"  title="Timely Support"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb background_layout="dark" image="http://www.elegantthemesimages.com/images/premade_blurb_6.png"  title="Innovative Ideas"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb background_layout="dark" image="http://www.elegantthemesimages.com/images/premade_blurb_7.png"  title="Advanced Technology"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb background_layout="dark" image="http://www.elegantthemesimages.com/images/premade_blurb_8.png"  title="Clear Communication"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#f5f5f5" inner_shadow="on"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_text text_orientation="center"]<h2>Recent Blog Posts</h2>
Learn from the top thought leaders in the industry.
[/et_pb_text]
[/et_pb_column]
[/et_pb_row]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_blog fullwidth="off" show_pagination="off" posts_number="3" meta_date="M j, Y" show_thumbnail="on" show_content="off" show_author="on" show_date="on" show_categories="on"][/et_pb_blog]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_text text_orientation="center"]<h2>Recent Projects</h2>
Learn from the top thought leaders in the industry.
[/et_pb_text]
[/et_pb_column]
[/et_pb_row]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_portfolio categories="Portfolio" fullwidth="off"][/et_pb_portfolio]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#7EBEC5"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_cta title="Don\'t Be Shy. Get In Touch." button_url="#" button_text="Contact Us" background_layout="dark" background_color="none"]
If you are interested in working together, send us an inquiry and we will get back to you as soon as we can!
[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Our Team', '', 'publish', 'open', 'open', '', 'our-team', '', '', '2014-02-13 15:25:10', '2014-02-13 15:25:10', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=15', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (16, 1, '2014-02-13 15:25:10', '2014-02-13 15:25:10', '
[et_pb_section background_color="#6aceb6" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="About me" subhead="Your subtitle goes right here." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="1_2"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_image_800x600.png" animation="left"][/et_pb_image]
[/et_pb_column]
[et_pb_column type="1_2"]
[et_pb_text]
<h2>This Is My Story</h2>
Curabitur quis dui volutpat, cursus eros ut, commodo elit. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Ut id est euismod, rhoncus nunc quis, lobortis turpis. Tam sociis natoque. Curabitur quis dui volutpat, cursus eros ut, commodo elit. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Ut id est euismod, rhoncus nunc quis.
[/et_pb_text]
[et_pb_counters]
[et_pb_counter percent="50"]Counter Name[/et_pb_counter]
[et_pb_counter percent="80"]Portfolio Themes[/et_pb_counter]
[et_pb_counter percent="10"]Themes[/et_pb_counter]
[/et_pb_counters]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#2d3743" inner_shadow="on"]
[et_pb_row]
[et_pb_column type="1_4"]
[et_pb_blurb background_layout="dark" image="http://www.elegantthemesimages.com/images/premade_blurb_5.png"  title="Timely Support"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb background_layout="dark" image="http://www.elegantthemesimages.com/images/premade_blurb_6.png"  title="Innovative Ideas"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb background_layout="dark" image="http://www.elegantthemesimages.com/images/premade_blurb_7.png"  title="Advanced Technology"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb background_layout="dark" image="http://www.elegantthemesimages.com/images/premade_blurb_8.png"  title="Clear Communication"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#f5f5f5"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_text text_orientation="center"]<h2>Recent Blog Posts</h2>
Learn from the top thought leaders in the industry.
[/et_pb_text]
[/et_pb_column]
[/et_pb_row]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_blog fullwidth="off" show_pagination="off" posts_number="3" meta_date="M j, Y" show_thumbnail="on" show_content="off" show_author="on" show_date="on" show_categories="on"][/et_pb_blog]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#7EBEC5"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_cta title="Don\'t Be Shy. Get In Touch." button_url="#" button_text="Contact Me" background_layout="dark" background_color="none"]
If you are interested in working together, send me an inquiry and I will get back to you as soon as I can!
[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'About Me', '', 'publish', 'open', 'open', '', 'about-me', '', '', '2014-02-13 15:25:10', '2014-02-13 15:25:10', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=16', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (17, 1, '2014-02-13 15:25:10', '2014-02-13 15:25:10', '
[et_pb_section background_color="#7ebec5" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="Page With Dual Sidebars" subhead="Here is a basic page layout." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="1_4"]
[et_pb_sidebar area="sidebar-1" orientation="left"][/et_pb_sidebar]
[/et_pb_column]
[et_pb_column type="1_2"]
[et_pb_text]
<h3>Just A Standard Page</h3>
<p>Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.</p>

<p>Sed sit amet blandit ipsum, et consectetur libero. Integer convallis at metus quis molestie. Morbi vitae odio ut ante molestie scelerisque. Aliquam erat volutpat. Vivamus dignissim fringilla semper. Aliquam imperdiet dui a purus pellentesque, non ornare ipsum blandit. Sed imperdiet elit in quam egestas lacinia nec sit amet dui. Cras malesuada tincidunt ante, in luctus tellus hendrerit at. Duis massa mauris, bibendum a mollis a, laoreet quis elit. Nulla pulvinar vestibulum est, in viverra nisi malesuada vel. Nam ut ipsum quis est faucibus mattis eu ut turpis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas nunc felis, venenatis in fringilla vel, tempus in turpis. Mauris aliquam dictum dolor at varius. Fusce sed vestibulum metus. Vestibulum dictum ultrices nulla sit amet fermentum.</p>

<h3>Fusce feugiat quis nunc</h3>
<p>Suspendisse non lorem eget tellus posuere ornare ut in diam. Quisque dictum libero non luctus malesuada. Mauris pellentesque risus ipsum, at venenatis elit dignissim id. Aenean at porta mauris. Phasellus nec tellus aliquam, vehicula elit sed, pulvinar nulla. Sed eleifend leo adipiscing sem dictum lobortis. Praesent nunc ante, feugiat vitae dignissim vel, porta at arcu. Fusce feugiat quis nunc sit amet malesuada. Suspendisse iaculis neque sed nibh dictum, vitae tempus nisi consequat. In consectetur vitae tellus sed condimentum. Suspendisse et nulla in neque rutrum vulputate. Morbi sodales sodales hendrerit. Suspendisse potenti. Sed adipiscing ante gravida rutrum commodo. Etiam malesuada suscipit augue et cursus. Vivamus pharetra bibendum gravida.</p>

<p>Maecenas mauris urna, fringilla id risus a, pulvinar lobortis purus. Integer suscipit risus in est condimentum dapibus. Nunc aliquet, purus convallis venenatis pretium, est neque elementum risus, non accumsan orci nisl at leo. Vivamus dignissim lacus in mauris auctor aliquam. Sed a velit id nunc bibendum tincidunt. Pellentesque vitae massa nunc. Aenean sagittis nulla mauris, ut porttitor mi varius at. Nam quis congue metus. Cras consectetur fringilla ultricies. Quisque odio orci, tincidunt vitae placerat id, rhoncus sit amet sapien. In a lorem vitae justo aliquet porttitor. Vestibulum et enim commodo, vestibulum nibh ullamcorper, auctor felis. Nulla facilisi. Nullam facilisis posuere metus id imperdiet. In iaculis elementum suscipit. Praesent dignissim turpis at leo sollicitudin, eu ultricies metus consectetur.</p>
[/et_pb_text]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_sidebar area="sidebar-1" orientation="right"][/et_pb_sidebar]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Page Dual Sidebars', '', 'publish', 'open', 'open', '', 'page-dual-sidebars', '', '', '2014-02-13 15:25:10', '2014-02-13 15:25:10', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=17', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (18, 1, '2014-02-13 15:25:11', '2014-02-13 15:25:11', '
[et_pb_section background_color="#7ebec5" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="Page With Left Sidebar" subhead="Here is a basic page layout." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="1_4"]
[et_pb_sidebar area="sidebar-1" orientation="left"][/et_pb_sidebar]
[/et_pb_column]
[et_pb_column type="3_4"]
[et_pb_text]
<h3>Just A Standard Page</h3>
<p>Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.</p>

<p>Sed sit amet blandit ipsum, et consectetur libero. Integer convallis at metus quis molestie. Morbi vitae odio ut ante molestie scelerisque. Aliquam erat volutpat. Vivamus dignissim fringilla semper. Aliquam imperdiet dui a purus pellentesque, non ornare ipsum blandit. Sed imperdiet elit in quam egestas lacinia nec sit amet dui. Cras malesuada tincidunt ante, in luctus tellus hendrerit at. Duis massa mauris, bibendum a mollis a, laoreet quis elit. Nulla pulvinar vestibulum est, in viverra nisi malesuada vel. Nam ut ipsum quis est faucibus mattis eu ut turpis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas nunc felis, venenatis in fringilla vel, tempus in turpis. Mauris aliquam dictum dolor at varius. Fusce sed vestibulum metus. Vestibulum dictum ultrices nulla sit amet fermentum.</p>

<h3>Fusce feugiat quis nunc</h3>
<p>Suspendisse non lorem eget tellus posuere ornare ut in diam. Quisque dictum libero non luctus malesuada. Mauris pellentesque risus ipsum, at venenatis elit dignissim id. Aenean at porta mauris. Phasellus nec tellus aliquam, vehicula elit sed, pulvinar nulla. Sed eleifend leo adipiscing sem dictum lobortis. Praesent nunc ante, feugiat vitae dignissim vel, porta at arcu. Fusce feugiat quis nunc sit amet malesuada. Suspendisse iaculis neque sed nibh dictum, vitae tempus nisi consequat. In consectetur vitae tellus sed condimentum. Suspendisse et nulla in neque rutrum vulputate. Morbi sodales sodales hendrerit. Suspendisse potenti. Sed adipiscing ante gravida rutrum commodo. Etiam malesuada suscipit augue et cursus. Vivamus pharetra bibendum gravida.</p>

<p>Maecenas mauris urna, fringilla id risus a, pulvinar lobortis purus. Integer suscipit risus in est condimentum dapibus. Nunc aliquet, purus convallis venenatis pretium, est neque elementum risus, non accumsan orci nisl at leo. Vivamus dignissim lacus in mauris auctor aliquam. Sed a velit id nunc bibendum tincidunt. Pellentesque vitae massa nunc. Aenean sagittis nulla mauris, ut porttitor mi varius at. Nam quis congue metus. Cras consectetur fringilla ultricies. Quisque odio orci, tincidunt vitae placerat id, rhoncus sit amet sapien. In a lorem vitae justo aliquet porttitor. Vestibulum et enim commodo, vestibulum nibh ullamcorper, auctor felis. Nulla facilisi. Nullam facilisis posuere metus id imperdiet. In iaculis elementum suscipit. Praesent dignissim turpis at leo sollicitudin, eu ultricies metus consectetur.</p>

<p>Donec diam magna, adipiscing vitae mi a, aliquet condimentum nunc. Pellentesque id augue imperdiet, fringilla ante eget, ornare elit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Proin in lectus quis dolor gravida rhoncus condimentum nec mi. Suspendisse urna massa, eleifend vel arcu ac, facilisis malesuada sem. Ut a eros ut nisl tempus luctus. Nam pharetra quis dui sed tristique. Duis ultrices cursus rhoncus. Proin tortor lorem, scelerisque quis cursus ac, sodales tempor nisl. Vestibulum posuere quis elit nec faucibus.</p>

<p>Maecenas nec lectus lacus. Proin quis lectus vitae nisi vehicula vulputate bibendum et purus. Aenean vulputate aliquet justo, quis auctor nunc. Curabitur ut mi nibh. Cras consectetur sem a felis tempor, id pretium mauris rhoncus. Sed sodales, turpis eu facilisis dapibus, lectus mi ullamcorper justo, sit amet rutrum ante ligula lobortis libero. Curabitur consequat et neque id malesuada.</p>
[/et_pb_text]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Page Left Sidebar', '', 'publish', 'open', 'open', '', 'page-left-sidebar', '', '', '2014-02-13 15:25:11', '2014-02-13 15:25:11', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=18', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (19, 1, '2014-02-13 15:25:11', '2014-02-13 15:25:11', '
[et_pb_section background_color="#7ebec5" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="Page With Right Sidebar" subhead="Here is a basic page layout." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="3_4"]
[et_pb_text]
<h3>Just A Standard Page</h3>
<p>Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.</p>

<p>Sed sit amet blandit ipsum, et consectetur libero. Integer convallis at metus quis molestie. Morbi vitae odio ut ante molestie scelerisque. Aliquam erat volutpat. Vivamus dignissim fringilla semper. Aliquam imperdiet dui a purus pellentesque, non ornare ipsum blandit. Sed imperdiet elit in quam egestas lacinia nec sit amet dui. Cras malesuada tincidunt ante, in luctus tellus hendrerit at. Duis massa mauris, bibendum a mollis a, laoreet quis elit. Nulla pulvinar vestibulum est, in viverra nisi malesuada vel. Nam ut ipsum quis est faucibus mattis eu ut turpis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas nunc felis, venenatis in fringilla vel, tempus in turpis. Mauris aliquam dictum dolor at varius. Fusce sed vestibulum metus. Vestibulum dictum ultrices nulla sit amet fermentum.</p>

<h3>Fusce feugiat quis nunc</h3>
<p>Suspendisse non lorem eget tellus posuere ornare ut in diam. Quisque dictum libero non luctus malesuada. Mauris pellentesque risus ipsum, at venenatis elit dignissim id. Aenean at porta mauris. Phasellus nec tellus aliquam, vehicula elit sed, pulvinar nulla. Sed eleifend leo adipiscing sem dictum lobortis. Praesent nunc ante, feugiat vitae dignissim vel, porta at arcu. Fusce feugiat quis nunc sit amet malesuada. Suspendisse iaculis neque sed nibh dictum, vitae tempus nisi consequat. In consectetur vitae tellus sed condimentum. Suspendisse et nulla in neque rutrum vulputate. Morbi sodales sodales hendrerit. Suspendisse potenti. Sed adipiscing ante gravida rutrum commodo. Etiam malesuada suscipit augue et cursus. Vivamus pharetra bibendum gravida.</p>

<p>Maecenas mauris urna, fringilla id risus a, pulvinar lobortis purus. Integer suscipit risus in est condimentum dapibus. Nunc aliquet, purus convallis venenatis pretium, est neque elementum risus, non accumsan orci nisl at leo. Vivamus dignissim lacus in mauris auctor aliquam. Sed a velit id nunc bibendum tincidunt. Pellentesque vitae massa nunc. Aenean sagittis nulla mauris, ut porttitor mi varius at. Nam quis congue metus. Cras consectetur fringilla ultricies. Quisque odio orci, tincidunt vitae placerat id, rhoncus sit amet sapien. In a lorem vitae justo aliquet porttitor. Vestibulum et enim commodo, vestibulum nibh ullamcorper, auctor felis. Nulla facilisi. Nullam facilisis posuere metus id imperdiet. In iaculis elementum suscipit. Praesent dignissim turpis at leo sollicitudin, eu ultricies metus consectetur.</p>

<p>Donec diam magna, adipiscing vitae mi a, aliquet condimentum nunc. Pellentesque id augue imperdiet, fringilla ante eget, ornare elit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Proin in lectus quis dolor gravida rhoncus condimentum nec mi. Suspendisse urna massa, eleifend vel arcu ac, facilisis malesuada sem. Ut a eros ut nisl tempus luctus. Nam pharetra quis dui sed tristique. Duis ultrices cursus rhoncus. Proin tortor lorem, scelerisque quis cursus ac, sodales tempor nisl. Vestibulum posuere quis elit nec faucibus.</p>

<p>Maecenas nec lectus lacus. Proin quis lectus vitae nisi vehicula vulputate bibendum et purus. Aenean vulputate aliquet justo, quis auctor nunc. Curabitur ut mi nibh. Cras consectetur sem a felis tempor, id pretium mauris rhoncus. Sed sodales, turpis eu facilisis dapibus, lectus mi ullamcorper justo, sit amet rutrum ante ligula lobortis libero. Curabitur consequat et neque id malesuada.</p>
[/et_pb_text]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_sidebar area="sidebar-1" orientation="right"][/et_pb_sidebar]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Page Right Sidebar', '', 'publish', 'open', 'open', '', 'page-right-sidebar', '', '', '2014-02-13 15:25:11', '2014-02-13 15:25:11', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=19', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (20, 1, '2014-02-13 15:25:11', '2014-02-13 15:25:11', '
[et_pb_section background_color="#6aceb6" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="Frequently Asked Questions" subhead="Before contacting us, please browse our FAQ." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_toggle title="Can I use the themes on multiple sites?"]
Yes, you are free to use our themes on as many websites as you like. We do not place any restrictions on how many times you can download or use a theme, nor do we limit the number of domains that you can install our themes to.
[/et_pb_toggle]
[et_pb_toggle open="on" title="What is your refund policy?"]
We offer no-questions-asked refunds to all customers within 30 days of your purchase. If you are not satisfied with our product, then simply send us an email and we will refund your purchase right away. Our goal has always been to create a happy, thriving community. If you are not thrilled with the product or are not enjoying the experience, then we have no interest in forcing you to stay an unhappy member.
[/et_pb_toggle]
[et_pb_toggle title="What are Photoshop Files?"]
Elegant Themes offers two different packages: Personal and Developer. The Personal Subscription is ideal for the average user while the Developers License is meant for experienced designers who wish to customize their themes using the original Photoshop files. Photoshop files are the original design files that were used to create the theme. They can be opened using Adobe Photoshop and edited, and prove very useful for customers wishing to change their theme\'s design in some way.
[/et_pb_toggle]
[et_pb_toggle title="Can I upgrade after signing up?"]
Yes, you can upgrade at any time after signing up. When you log in as a "personal" subscriber, you will see a notice regarding your current package and instructions on how to upgrade.
[/et_pb_toggle]
[et_pb_toggle title="Can I use your themes with WP.com?"]
Unfortunately WordPress.com does not allow the use of custom themes. If you would like to use a custom theme of any kind, you will need to purchase your own hosting account and install the free software from WordPress.org. If you are looking for great WordPress hosting, we recommend giving HostGator a try.[/et_pb_toggle]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'FAQ Page', '', 'publish', 'open', 'open', '', 'faq-page', '', '', '2014-02-13 15:25:11', '2014-02-13 15:25:11', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=20', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (21, 1, '2014-02-13 15:30:40', '2014-02-13 15:30:40', '', 'vmax', '', 'inherit', 'open', 'open', '', 'vmax', '', '', '2014-02-13 15:30:40', '2014-02-13 15:30:40', '', 0, 'http://localhost:8080/fixitall//wp-content/uploads/2014/02/vmax.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (22, 1, '2014-02-13 15:33:20', '2014-02-13 15:33:20', '
[et_pb_section fullwidth="on"]
[et_pb_fullwidth_slider show_arrows="on" show_pagination="on" parallax="on" auto="off" auto_speed="7000"]
[et_pb_slide heading="Designed With Passion" background_image="http://www.elegantthemesimages.com/images/premade_bg.jpg" button_text="Join Today" background_color="#492144" button_link="http://elegantthemes.com"]No matter how you use Divi, your website is going to look great. Everything about Divi has been built beautifully and purposefully by our passionate team. We are so excited to release this labor of love to our community.[/et_pb_slide]
[et_pb_slide heading="Elegantly Responsive" button_text="Join Today" background_color="#6aceb6" button_link="http://elegantthemes.com" image="http://www.elegantthemesimages.com/images/premade_iphone_slider.png" image_alt="Alt text for the image"]Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl. Cras venenatis.[/et_pb_slide]
[/et_pb_fullwidth_slider]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_1.png" title="Advanced Page Builder"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_2.png" title="Elegant Shortcodes"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_3.png" title="Fully Responsive"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_4.png" title="Perpetual Updates"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#f5f5f5" inner_shadow="on"]
[et_pb_row]
[et_pb_column type="2_3"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_iphone_half.png" animation="left"][/et_pb_image]
[/et_pb_column]
[et_pb_column type="1_3"]
[et_pb_divider color="#eee" show_divider="off" height="120"][/et_pb_divider]
[et_pb_text]
<h2>It\'s Elegantly Responsive</h2>
Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante. In vitae tempus nunc. Etiam adipiscing enim sed condimentum ultrices. Cras rutrum blandit sem, molestie consequat erat luctus vel. Cras nunc est, laoreet sit amet ligula et, eleifend commodo dui. Vivamus id blandit nisi, eu mattis odio.
[/et_pb_text]
[et_pb_counters]
[et_pb_counter percent="50"]Smart[/et_pb_counter]
[et_pb_counter percent="80"]Flexible[/et_pb_counter]
[et_pb_counter percent="40"]Beautiful[/et_pb_counter]
[/et_pb_counters]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="1_4"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_logo-1.jpg" animation="top"][/et_pb_image]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_logo-2.jpg" animation="top"][/et_pb_image]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_logo-3.jpg" animation="top"][/et_pb_image]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_logo-4.jpg" animation="top"][/et_pb_image]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#f5f5f5" inner_shadow="on"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_text text_orientation="center"]
<h2>With Our Most Advanced Page Builder Yet.</h2>
Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus dolor ipsum amet sit.
[/et_pb_text]
[/et_pb_column]
[/et_pb_row]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_macbook.png" animation="top"][/et_pb_image]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#7cbec6"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_cta title="Signup Today For Instant Access" button_url="http://elegantthemes.com/preview/Divi/join/" button_text="Join Today" background_layout="dark" background_color="none"]
Join today and get access to Divi, as well as our other countless themes and plugins.
[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Homepage', '', 'publish', 'open', 'open', '', 'homepage-2', '', '', '2014-02-13 15:33:20', '2014-02-13 15:33:20', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=22', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (23, 1, '2014-02-13 15:33:20', '2014-02-13 15:33:20', '
[et_pb_section]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_slider show_arrows="on" show_pagination="on" parallax="off" auto="off" auto_speed="7000"]
[et_pb_slide heading="Divi" button_text="Join Today" background_color="#444b5d" background_image="http://www.elegantthemesimages.com/images/premade_bg.jpg" button_link="http://elegantthemes.com" image="http://www.elegantthemesimages.com/images/premade-logo.png" image_alt="Alt text for the image"]Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl.[/et_pb_slide]
[et_pb_slide heading="Divi" button_text="Join Today" background_color="#144d6a" background_image="http://www.elegantthemesimages.com/images/premade_bg_2.jpg" button_link="http://elegantthemes.com"]The only theme you will ever need.[/et_pb_slide]
[/et_pb_slider]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_1.png"  title="Advanced Page Builder"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_2.png"  title="Elegant Shortcodes"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_3.png"  title="Fully Responsive"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_4.png"  title="Perpetual Updates"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[/et_pb_row]


[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_divider height="1" show_divider="on"][/et_pb_divider]
[/et_pb_column]
[/et_pb_row]

[et_pb_row]
[et_pb_column type="1_3"]
[et_pb_text]<h1 style="font-size: 32px;">STUNNING PORTFOLIOS</h1>[/et_pb_text]
[/et_pb_column]
[et_pb_column type="1_3"]
[et_pb_text]With Divi’s portfolio module, you can show off your work anywhere on your site. Choose from our premade portfolio layouts, or create one entirely from scratch![/et_pb_text]
[/et_pb_column]
[et_pb_column type="1_3"]
[et_pb_image src="http://elegantthemesimages.com/images/premade-portfolios.gif" animation="right"][/et_pb_image]
[/et_pb_column]
[/et_pb_row]

[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_divider height="1" show_divider="on"][/et_pb_divider]
[/et_pb_column]
[/et_pb_row]

[et_pb_row]
[et_pb_column type="1_3"]
[et_pb_text]<h1 style="font-size: 32px;">ECOMMERCE INTEGRATION</h1>[/et_pb_text]
[/et_pb_column]
[et_pb_column type="1_3"]
[et_pb_text]Divi has what you need to get an online store up and running in no time. We’ve included a couple of premade store layouts, and the store module lets you sell anywhere on your site.[/et_pb_text]
[/et_pb_column]
[et_pb_column type="1_3"]
[et_pb_image src="http://elegantthemesimages.com/images/premade-ecommerce.gif" animation="right"][/et_pb_image]
[/et_pb_column]
[/et_pb_row]


[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_cta title="Signup Today For Instant Access" button_url="http://elegantthemes.com/preview/Divi/join/" button_text="Join Today" background_layout="dark" background_color="#7EBEC5"]
Join today and get access to Divi, as well as our other countless themes and plugins.
[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Homepage Simple', '', 'publish', 'open', 'open', '', 'homepage-simple-2', '', '', '2014-02-13 15:33:20', '2014-02-13 15:33:20', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=23', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (24, 1, '2014-02-13 15:33:20', '2014-02-13 15:33:20', '
[et_pb_section fullwidth="on"]
[et_pb_fullwidth_slider show_arrows="on" show_pagination="on" parallax="on" auto="off" auto_speed="7000"]
[et_pb_slide heading="Welcome To Our Store" background_image="http://www.elegantthemesimages.com/images/premade_bg.jpg" button_text="View Special Offers" background_color="#492144" button_link="http://elegantthemes.com"]No matter how you use Divi, your website is going to look great. Everything about Divi has been built beautifully and purposefully by our passionate team. We are so excited to release this labor of love to our community.[/et_pb_slide]
[et_pb_slide heading="Today\'s Sale Items" button_text="Order Today" background_color="#6aceb6" button_link="http://elegantthemes.com" image="http://www.elegantthemesimages.com/images/premade_image_800x600.png" image_alt="Alt text for the image"]Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl. Cras venenatis.[/et_pb_slide]
[/et_pb_fullwidth_slider]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_shop posts_number="12" type="recent"][/et_pb_shop]
[/et_pb_column]
[/et_pb_row]
[et_pb_row]
[et_pb_column type="1_2"]
[et_pb_cta title="The Holiday Special Sale" button_url="http://elegantthemes.com/preview/Divi/join/" button_text="Redeem This Offer" background_layout="dark" background_color="#7ebec5"]
For a limited time only, all of our holiday products are 50% off! Don\'t miss your chance to save big on these wonderful items.[/et_pb_cta]
[/et_pb_column]
[et_pb_column type="1_2"]
[et_pb_cta title="The Holiday Special Sale" button_url="http://elegantthemes.com/preview/Divi/join/" button_text="Redeem This Offer" background_layout="light" background_color="#fff"]
For a limited time only, all of our holiday products are 50% off! Don\'t miss your chance to save big on these wonderful items.[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#f5f5f5" inner_shadow="on"]
[et_pb_row]
[et_pb_column type="1_2"]
[et_pb_text]
<h2>Products On Sale</h2>
Take a look at these special offers.
[/et_pb_text]
[et_pb_shop posts_number="4" type="sale" columns="2"][/et_pb_shop]
[/et_pb_column]
[et_pb_column type="1_2"]
[et_pb_text]
<h2>Top Rated Products</h2>
A list of our latest products.[/et_pb_text]
[et_pb_shop posts_number="4" type="top_rated" columns="2"][/et_pb_shop]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#7EBEC5"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_cta title="Signup Today For Instant Access" button_url="http://elegantthemes.com/preview/Divi/join/" button_text="Join Today" background_layout="dark" background_color="none"]
Join today and get access to Divi, as well as our other countless themes and plugins.
[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Homepage Store', '', 'publish', 'open', 'open', '', 'homepage-store-2', '', '', '2014-02-13 15:33:20', '2014-02-13 15:33:20', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=24', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (25, 1, '2014-02-13 15:33:20', '2014-02-13 15:33:20', '
[et_pb_section background_color="#6aceb6" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="Contact Our Company" subhead="If you have any questions, we would love to help." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="1_2"]
[et_pb_contact_form title="Get In Touch"][/et_pb_contact_form]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_text]
<h3>Contact Information</h3>
<p>Cras rutrum blandit sem, molestie consequat erat luctus vel. Cras nunc est, laoreet sit amet ligula et, eleifend commodo dui.</p>
[/et_pb_text]
[et_pb_text]
<p>
<strong>Phone:</strong> 343.554.2466
<strong>Fax:</strong> 888.343.3467
<strong>eMail:</strong> contact@somewebsite.com
</p>
[/et_pb_text]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_text]
<h3>Location & Hours</h3>
<p>Vivamus id blandit nisi, eu mattis odio. Nulla facilisi. Aenean in mi. Cras rutrum blandit sem, molestie consequat erat luctus vel.</p>
[/et_pb_text]
[et_pb_text]
<p>
<strong>Address:</strong> 4323 Divi Street
Some City, California, 33432
<strong>Hours:</strong> Mon-Fri, 9:00AM-6:00PM
</p>
[/et_pb_text]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Contact', '', 'publish', 'open', 'open', '', 'contact-2', '', '', '2014-02-13 15:33:20', '2014-02-13 15:33:20', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=25', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (26, 1, '2014-02-13 15:33:20', '2014-02-13 15:33:20', '
[et_pb_section fullwidth="on"]
[et_pb_fullwidth_slider show_arrows="on" show_pagination="on" parallax="on" auto="off" auto_speed="7000"]
[et_pb_slide heading="Join Today" background_image="http://www.elegantthemesimages.com/images/premade_bg_2.jpg" button_text="Join Today" background_color="#144d6a" button_link="http://elegantthemes.com"]No matter how you use Divi, your website is going to look great. Everything about Divi has been built beautifully and purposefully by our passionate team. We are so excited to release this labor of love to our community.[/et_pb_slide]
[et_pb_slide heading="The Best Deal" button_text="Join Today" background_color="#6aceb6" button_link="http://elegantthemes.com" image="http://www.elegantthemesimages.com/images/premade_iphone_slider.png" image_alt="Alt text for the image"]Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl. Cras venenatis.[/et_pb_slide]
[/et_pb_fullwidth_slider]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_1.png"  title="Advanced Page Builder"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_2.png"  title="Elegant Shortcodes"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_3.png"  title="Fully Responsive"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb image="http://www.elegantthemesimages.com/images/premade_blurb_4.png"  title="Perpetual Updates"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#f7f7f7"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_divider height="60"][/et_pb_divider]
[et_pb_pricing_tables]
[et_pb_pricing_table title="Beginnger" currency="$" per="yr" sum="19" button_url="http://elegantthemes.com" button_text="Sign Up!"]
Access to <a href="#">All Themes</a>
Perpetual Theme Updates
-Premium Technical Support
-Access to <a href="#">All Plugins</a>
-Layered Photoshop Files
-No Yearly Fees
[/et_pb_pricing_table]
[et_pb_pricing_table title="Personal" currency="$" per="yr" sum="39" button_url="http://elegantthemes.com" button_text="Sign Up!"]
Access to <a href="#">All Themes</a>
Perpetual Theme Updates
Premium Technical Support
-Access to <a href="#">All Plugins</a>
-Layered Photoshop Files
-No Yearly Fees
[/et_pb_pricing_table]
[et_pb_pricing_table featured="on" title="Developer" subtitle="The Best Deal" currency="$" per="yr" sum="89" button_url="http://elegantthemes.com" button_text="Sign Up!"]
Access to <a href="#">All Themes</a>
Perpetual Theme Updates
Premium Technical Support
Access to <a href="#">All Plugins</a>
Layered Photoshop Files
-No Yearly Fees
[/et_pb_pricing_table]
[et_pb_pricing_table title="Lifetime" currency="$" per="yr" sum="249" button_url="http://elegantthemes.com" button_text="Sign Up!"]
Access to <a href="#">All Themes</a>
Perpetual Theme Updates
Premium Technical Support
Access to <a href="#">All Plugins</a>
Layered Photoshop Files
No Yearly Fees
[/et_pb_pricing_table]
[/et_pb_pricing_tables]
[et_pb_divider height="60"][/et_pb_divider]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section inner_shadow="on" background_color="#eeeeee"]
[et_pb_row]
[et_pb_column type="1_4"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_logo-1.jpg" animation="top"][/et_pb_image]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_logo-2.jpg" animation="top"][/et_pb_image]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_logo-3.jpg" animation="top"][/et_pb_image]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_logo-4.jpg" animation="top"][/et_pb_image]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_text text_orientation="center" background_layout="light"]
<h2>What Our Customers Are Saying.</h2>
Don\'t just take it from us, let our customers do the talking!
[/et_pb_text]
[/et_pb_column]
[/et_pb_row]
[et_pb_row]
[et_pb_column type="1_3"]
[et_pb_testimonial author="John Doe"]<p>"Aliquam pellentesque hendrerit commodo. Sed hendrerit blandit justo quis feugiat. Curabitur ut consequat odio. Nunc risus mi, consectetur et dolor a, dignissim vehicula nibh. Vestibulum adipiscing adipiscing consectetur. Vestibulum aliquam dignissim volutpat. Curabitur dictum, quam vitae fringilla aliquet, ligula justo placerat nisi, ut semper sapien elit eget augue. Maecenas et feugiat nisi. Nulla in velit et orci dictum gravida. Donec sagittis cursus luctus. Aliquam vel convallis leo. Donec urna sapien, suscipit et ultricies at, sodales in dui."</p>[/et_pb_testimonial]
[/et_pb_column]
[et_pb_column type="1_3"]
[et_pb_testimonial author="John Doe"]<p>"Aliquam pellentesque hendrerit commodo. Sed hendrerit blandit justo quis feugiat. Curabitur ut consequat odio. Nunc risus mi, consectetur et dolor a, dignissim vehicula nibh. Vestibulum adipiscing adipiscing consectetur. Vestibulum aliquam dignissim volutpat. Curabitur dictum, quam vitae fringilla aliquet, ligula justo placerat nisi, ut semper sapien elit eget augue. Maecenas et feugiat nisi. Nulla in velit et orci dictum gravida. Donec sagittis cursus luctus. Aliquam vel convallis leo. Donec urna sapien, suscipit et ultricies at, sodales in dui."</p>[/et_pb_testimonial]
[/et_pb_column]
[et_pb_column type="1_3"]
[et_pb_testimonial author="John Doe"]<p>"Aliquam pellentesque hendrerit commodo. Sed hendrerit blandit justo quis feugiat. Curabitur ut consequat odio. Nunc risus mi, consectetur et dolor a, dignissim vehicula nibh. Vestibulum adipiscing adipiscing consectetur. Vestibulum aliquam dignissim volutpat. Curabitur dictum, quam vitae fringilla aliquet, ligula justo placerat nisi, ut semper sapien elit eget augue. Maecenas et feugiat nisi. Nulla in velit et orci dictum gravida. Donec sagittis cursus luctus. Aliquam vel convallis leo. Donec urna sapien, suscipit et ultricies at, sodales in dui."</p>[/et_pb_testimonial]
[/et_pb_column]
[/et_pb_row]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_toggle title="Can I use the themes on multiple sites?"]
Yes, you are free to use our themes on as many websites as you like. We do not place any restrictions on how many times you can download or use a theme, nor do we limit the number of domains that you can install our themes to.
[/et_pb_toggle]
[et_pb_toggle open="on" title="What is your refund policy?"]
We offer no-questions-asked refunds to all customers within 30 days of your purchase. If you are not satisfied with our product, then simply send us an email and we will refund your purchase right away. Our goal has always been to create a happy, thriving community. If you are not thrilled with the product or are not enjoying the experience, then we have no interest in forcing you to stay an unhappy member.
[/et_pb_toggle]
[et_pb_toggle title="What are Photoshop Files?"]
Elegant Themes offers two different packages: Personal and Developer. The Personal Subscription is ideal for the average user while the Developers License is meant for experienced designers who wish to customize their themes using the original Photoshop files. Photoshop files are the original design files that were used to create the theme. They can be opened using Adobe Photoshop and edited, and prove very useful for customers wishing to change their theme\'s design in some way.
[/et_pb_toggle]
[et_pb_toggle title="Can I upgrade after signing up?"]
Yes, you can upgrade at any time after signing up. When you log in as a "personal" subscriber, you will see a notice regarding your current package and instructions on how to upgrade.
[/et_pb_toggle]
[et_pb_toggle title="Can I use your themes with WP.com?"]
Unfortunately WordPress.com does not allow the use of custom themes. If you would like to use a custom theme of any kind, you will need to purchase your own hosting account and install the free software from WordPress.org. If you are looking for great WordPress hosting, we recommend giving HostGator a try.[/et_pb_toggle]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#7EBEC5"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_cta title="Join Today For Instant Access." button_url="#" button_text="Contact Me" background_layout="dark" background_color="none"]
We have the best product around. Don\'t miss out on this great opportunity!
[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Join', '', 'publish', 'open', 'open', '', 'join-2', '', '', '2014-02-13 15:33:20', '2014-02-13 15:33:20', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=26', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (27, 1, '2014-02-13 15:33:21', '2014-02-13 15:33:21', '
[et_pb_section background_color="#6aceb6" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="My Portfolio" subhead="Your subtitle goes right here." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_portfolio fullwidth="off"][/et_pb_portfolio]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#7EBEC5"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_cta title="Don\'t Be Shy. Get In Touch." button_url="#" button_text="Contact Me" background_layout="dark" background_color="none"]
If you are interested in working together, send me an inquiry and I will get back to you as soon as I can!
[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Portfolio', '', 'publish', 'open', 'open', '', 'portfolio-2', '', '', '2014-02-13 15:33:21', '2014-02-13 15:33:21', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=27', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (28, 1, '2014-02-13 15:33:21', '2014-02-13 15:33:21', '
[et_pb_section background_color="#ef8f61" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="Welcome To Our Shop" subhead="Your subtitle goes right here." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_shop posts_number="12" type="recent"][/et_pb_shop]
[/et_pb_column]
[/et_pb_row]
[et_pb_row]
[et_pb_column type="1_2"]
[et_pb_cta title="The Holiday Special Sale" button_url="http://elegantthemes.com/preview/Divi/join/" button_text="Redeem This Offer" background_layout="dark" background_color="#7ebec5"]
For a limited time only, all of our holiday products are 50% off! Don\'t miss your chance to save big on these wonderful items.[/et_pb_cta]
[/et_pb_column]
[et_pb_column type="1_2"]
[et_pb_cta title="The Holiday Special Sale" button_url="http://elegantthemes.com/preview/Divi/join/" button_text="Redeem This Offer" background_layout="light" background_color="#fff"]
For a limited time only, all of our holiday products are 50% off! Don\'t miss your chance to save big on these wonderful items.[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#f5f5f5" inner_shadow="on"]
[et_pb_row]
[et_pb_column type="1_2"]
[et_pb_text]<h2>Products On Sale</h2>
Take a look at these special offers.
[/et_pb_text]
[et_pb_shop posts_number="4" type="sale" columns="2"][/et_pb_shop]
[/et_pb_column]
[et_pb_column type="1_2"]
[et_pb_text]<h2>Top Rated Products</h2>
A list of our latest products.[/et_pb_text]
[et_pb_shop posts_number="4" type="top_rated" columns="2"][/et_pb_shop]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#7EBEC5"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_cta title="Signup Today For Instant Access" button_url="http://elegantthemes.com/preview/Divi/join/" button_text="Join Today" background_layout="dark" background_color="none"]
Join today and get access to Divi, as well as our other countless themes and plugins.
[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Shop Extended', '', 'publish', 'open', 'open', '', 'shop-extended-2', '', '', '2014-02-13 15:33:21', '2014-02-13 15:33:21', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=28', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (29, 1, '2014-02-13 15:33:21', '2014-02-13 15:33:21', '
[et_pb_section background_color="#ef8f61" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="Welcome To Our Shop" subhead="Your subtitle goes right here." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_shop posts_number="12" type="recent"][/et_pb_shop]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#7EBEC5"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_cta title="Signup Today For Instant Access" button_url="http://elegantthemes.com/preview/Divi/join/" button_text="Join Today" background_layout="dark" background_color="none"]
Join today and get access to Divi, as well as our other countless themes and plugins.
[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Shop Basic', '', 'publish', 'open', 'open', '', 'shop-basic-2', '', '', '2014-02-13 15:33:21', '2014-02-13 15:33:21', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=29', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (30, 1, '2014-02-13 15:33:21', '2014-02-13 15:33:21', '
[et_pb_section background_color="#7ebec5" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="Tiled Blog Layout" subhead="Your subtitle goes right here." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="2_3"]
[et_pb_blog fullwidth="off" posts_number="6" meta_date="M j, Y" show_thumbnail="on" show_content="off" show_author="on" show_date="on" show_categories="on"][/et_pb_blog]
[/et_pb_column]
[et_pb_column type="1_3"]
[et_pb_sidebar area="sidebar-1" orientation="right"][/et_pb_sidebar]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Blog Tiled', '', 'publish', 'open', 'open', '', 'blog-tiled-2', '', '', '2014-02-13 15:33:21', '2014-02-13 15:33:21', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=30', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (31, 1, '2014-02-13 15:33:21', '2014-02-13 15:33:21', '
[et_pb_section background_color="#7ebec5" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="Standard Blog Layout" subhead="Your subtitle goes right here." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="1_4"]
[et_pb_sidebar area="sidebar-1" orientation="left"][/et_pb_sidebar]
[/et_pb_column]
[et_pb_column type="3_4"]
[et_pb_blog fullwidth="on" posts_number="6" meta_date="M j, Y" show_thumbnail="on" show_content="off" show_author="on" show_date="on" show_categories="on"][/et_pb_blog]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Blog Standard', '', 'publish', 'open', 'open', '', 'blog-standard-2', '', '', '2014-02-13 15:33:21', '2014-02-13 15:33:21', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=31', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (32, 1, '2014-02-13 15:33:22', '2014-02-13 15:33:22', '
[et_pb_section background_color="#6aceb6" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="About Our Team" subhead="Your subtitle goes right here." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="1_3"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_image_800x600.png" animation="left"][/et_pb_image]
[et_pb_text]
<h2>Nick Roach</h2>
<em>President, CEO, Theme UI/UX Designer</em>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent mattis nec nisi non luctus. Donec aliquam non nisi ut rutrum. In sit amet vestibulum felis, id aliquet ipsum. Vestibulum feugiat lacinia aliquet.
[/et_pb_text]
[et_pb_counters]
[et_pb_counter percent="50"]Design & UX[/et_pb_counter]
[et_pb_counter percent="80"]Web Programming[/et_pb_counter]
[et_pb_counter percent="10"]Internet Marketing[/et_pb_counter]
[/et_pb_counters]
[/et_pb_column]

[et_pb_column type="1_3"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_image_800x600.png" animation="top"][/et_pb_image]
[et_pb_text]
<h2>Kenny Sing</h2>
<em>Lead Graphic Designers</em>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent mattis nec nisi non luctus. Donec aliquam non nisi ut rutrum. In sit amet vestibulum felis, id aliquet ipsum. Vestibulum feugiat lacinia aliquet.
[/et_pb_text]
[et_pb_counters]
[et_pb_counter percent="85"]Photoshop[/et_pb_counter]
[et_pb_counter percent="70"]After Effects[/et_pb_counter]
[et_pb_counter percent="50"]Illustrator[/et_pb_counter]
[/et_pb_counters]
[/et_pb_column]

[et_pb_column type="1_3"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_image_800x600.png" animation="right"][/et_pb_image]
[et_pb_text]
<h2>Mitch Skolnik</h2>
<em>Community Manager</em>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent mattis nec nisi non luctus. Donec aliquam non nisi ut rutrum. In sit amet vestibulum felis, id aliquet ipsum. Vestibulum feugiat lacinia aliquet.
[/et_pb_text]
[et_pb_counters]
[et_pb_counter percent="80"]Customer Happiness[/et_pb_counter]
[et_pb_counter percent="30"]Tech Support[/et_pb_counter]
[et_pb_counter percent="50"]Community Management[/et_pb_counter]
[/et_pb_counters]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#2d3743" inner_shadow="on"]
[et_pb_row]
[et_pb_column type="1_4"]
[et_pb_blurb background_layout="dark" image="http://www.elegantthemesimages.com/images/premade_blurb_5.png"  title="Timely Support"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb background_layout="dark" image="http://www.elegantthemesimages.com/images/premade_blurb_6.png"  title="Innovative Ideas"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb background_layout="dark" image="http://www.elegantthemesimages.com/images/premade_blurb_7.png"  title="Advanced Technology"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb background_layout="dark" image="http://www.elegantthemesimages.com/images/premade_blurb_8.png"  title="Clear Communication"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#f5f5f5" inner_shadow="on"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_text text_orientation="center"]<h2>Recent Blog Posts</h2>
Learn from the top thought leaders in the industry.
[/et_pb_text]
[/et_pb_column]
[/et_pb_row]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_blog fullwidth="off" show_pagination="off" posts_number="3" meta_date="M j, Y" show_thumbnail="on" show_content="off" show_author="on" show_date="on" show_categories="on"][/et_pb_blog]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_text text_orientation="center"]<h2>Recent Projects</h2>
Learn from the top thought leaders in the industry.
[/et_pb_text]
[/et_pb_column]
[/et_pb_row]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_portfolio categories="Portfolio" fullwidth="off"][/et_pb_portfolio]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#7EBEC5"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_cta title="Don\'t Be Shy. Get In Touch." button_url="#" button_text="Contact Us" background_layout="dark" background_color="none"]
If you are interested in working together, send us an inquiry and we will get back to you as soon as we can!
[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Our Team', '', 'publish', 'open', 'open', '', 'our-team-2', '', '', '2014-02-13 15:33:22', '2014-02-13 15:33:22', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=32', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (33, 1, '2014-02-13 15:33:22', '2014-02-13 15:33:22', '
[et_pb_section background_color="#6aceb6" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="About me" subhead="Your subtitle goes right here." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="1_2"]
[et_pb_image src="http://www.elegantthemesimages.com/images/premade_image_800x600.png" animation="left"][/et_pb_image]
[/et_pb_column]
[et_pb_column type="1_2"]
[et_pb_text]
<h2>This Is My Story</h2>
Curabitur quis dui volutpat, cursus eros ut, commodo elit. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Ut id est euismod, rhoncus nunc quis, lobortis turpis. Tam sociis natoque. Curabitur quis dui volutpat, cursus eros ut, commodo elit. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Ut id est euismod, rhoncus nunc quis.
[/et_pb_text]
[et_pb_counters]
[et_pb_counter percent="50"]Counter Name[/et_pb_counter]
[et_pb_counter percent="80"]Portfolio Themes[/et_pb_counter]
[et_pb_counter percent="10"]Themes[/et_pb_counter]
[/et_pb_counters]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#2d3743" inner_shadow="on"]
[et_pb_row]
[et_pb_column type="1_4"]
[et_pb_blurb background_layout="dark" image="http://www.elegantthemesimages.com/images/premade_blurb_5.png"  title="Timely Support"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb background_layout="dark" image="http://www.elegantthemesimages.com/images/premade_blurb_6.png"  title="Innovative Ideas"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb background_layout="dark" image="http://www.elegantthemesimages.com/images/premade_blurb_7.png"  title="Advanced Technology"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_blurb background_layout="dark" image="http://www.elegantthemesimages.com/images/premade_blurb_8.png"  title="Clear Communication"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#f5f5f5"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_text text_orientation="center"]<h2>Recent Blog Posts</h2>
Learn from the top thought leaders in the industry.
[/et_pb_text]
[/et_pb_column]
[/et_pb_row]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_blog fullwidth="off" show_pagination="off" posts_number="3" meta_date="M j, Y" show_thumbnail="on" show_content="off" show_author="on" show_date="on" show_categories="on"][/et_pb_blog]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color="#7EBEC5"]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_cta title="Don\'t Be Shy. Get In Touch." button_url="#" button_text="Contact Me" background_layout="dark" background_color="none"]
If you are interested in working together, send me an inquiry and I will get back to you as soon as I can!
[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'About Me', '', 'publish', 'open', 'open', '', 'about-me-2', '', '', '2014-02-13 15:33:22', '2014-02-13 15:33:22', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=33', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (34, 1, '2014-02-13 15:33:22', '2014-02-13 15:33:22', '
[et_pb_section background_color="#7ebec5" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="Page With Dual Sidebars" subhead="Here is a basic page layout." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="1_4"]
[et_pb_sidebar area="sidebar-1" orientation="left"][/et_pb_sidebar]
[/et_pb_column]
[et_pb_column type="1_2"]
[et_pb_text]
<h3>Just A Standard Page</h3>
<p>Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.</p>

<p>Sed sit amet blandit ipsum, et consectetur libero. Integer convallis at metus quis molestie. Morbi vitae odio ut ante molestie scelerisque. Aliquam erat volutpat. Vivamus dignissim fringilla semper. Aliquam imperdiet dui a purus pellentesque, non ornare ipsum blandit. Sed imperdiet elit in quam egestas lacinia nec sit amet dui. Cras malesuada tincidunt ante, in luctus tellus hendrerit at. Duis massa mauris, bibendum a mollis a, laoreet quis elit. Nulla pulvinar vestibulum est, in viverra nisi malesuada vel. Nam ut ipsum quis est faucibus mattis eu ut turpis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas nunc felis, venenatis in fringilla vel, tempus in turpis. Mauris aliquam dictum dolor at varius. Fusce sed vestibulum metus. Vestibulum dictum ultrices nulla sit amet fermentum.</p>

<h3>Fusce feugiat quis nunc</h3>
<p>Suspendisse non lorem eget tellus posuere ornare ut in diam. Quisque dictum libero non luctus malesuada. Mauris pellentesque risus ipsum, at venenatis elit dignissim id. Aenean at porta mauris. Phasellus nec tellus aliquam, vehicula elit sed, pulvinar nulla. Sed eleifend leo adipiscing sem dictum lobortis. Praesent nunc ante, feugiat vitae dignissim vel, porta at arcu. Fusce feugiat quis nunc sit amet malesuada. Suspendisse iaculis neque sed nibh dictum, vitae tempus nisi consequat. In consectetur vitae tellus sed condimentum. Suspendisse et nulla in neque rutrum vulputate. Morbi sodales sodales hendrerit. Suspendisse potenti. Sed adipiscing ante gravida rutrum commodo. Etiam malesuada suscipit augue et cursus. Vivamus pharetra bibendum gravida.</p>

<p>Maecenas mauris urna, fringilla id risus a, pulvinar lobortis purus. Integer suscipit risus in est condimentum dapibus. Nunc aliquet, purus convallis venenatis pretium, est neque elementum risus, non accumsan orci nisl at leo. Vivamus dignissim lacus in mauris auctor aliquam. Sed a velit id nunc bibendum tincidunt. Pellentesque vitae massa nunc. Aenean sagittis nulla mauris, ut porttitor mi varius at. Nam quis congue metus. Cras consectetur fringilla ultricies. Quisque odio orci, tincidunt vitae placerat id, rhoncus sit amet sapien. In a lorem vitae justo aliquet porttitor. Vestibulum et enim commodo, vestibulum nibh ullamcorper, auctor felis. Nulla facilisi. Nullam facilisis posuere metus id imperdiet. In iaculis elementum suscipit. Praesent dignissim turpis at leo sollicitudin, eu ultricies metus consectetur.</p>
[/et_pb_text]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_sidebar area="sidebar-1" orientation="right"][/et_pb_sidebar]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Page Dual Sidebars', '', 'publish', 'open', 'open', '', 'page-dual-sidebars-2', '', '', '2014-02-13 15:33:22', '2014-02-13 15:33:22', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=34', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (35, 1, '2014-02-13 15:33:22', '2014-02-13 15:33:22', '
[et_pb_section background_color="#7ebec5" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="Page With Left Sidebar" subhead="Here is a basic page layout." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="1_4"]
[et_pb_sidebar area="sidebar-1" orientation="left"][/et_pb_sidebar]
[/et_pb_column]
[et_pb_column type="3_4"]
[et_pb_text]
<h3>Just A Standard Page</h3>
<p>Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.</p>

<p>Sed sit amet blandit ipsum, et consectetur libero. Integer convallis at metus quis molestie. Morbi vitae odio ut ante molestie scelerisque. Aliquam erat volutpat. Vivamus dignissim fringilla semper. Aliquam imperdiet dui a purus pellentesque, non ornare ipsum blandit. Sed imperdiet elit in quam egestas lacinia nec sit amet dui. Cras malesuada tincidunt ante, in luctus tellus hendrerit at. Duis massa mauris, bibendum a mollis a, laoreet quis elit. Nulla pulvinar vestibulum est, in viverra nisi malesuada vel. Nam ut ipsum quis est faucibus mattis eu ut turpis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas nunc felis, venenatis in fringilla vel, tempus in turpis. Mauris aliquam dictum dolor at varius. Fusce sed vestibulum metus. Vestibulum dictum ultrices nulla sit amet fermentum.</p>

<h3>Fusce feugiat quis nunc</h3>
<p>Suspendisse non lorem eget tellus posuere ornare ut in diam. Quisque dictum libero non luctus malesuada. Mauris pellentesque risus ipsum, at venenatis elit dignissim id. Aenean at porta mauris. Phasellus nec tellus aliquam, vehicula elit sed, pulvinar nulla. Sed eleifend leo adipiscing sem dictum lobortis. Praesent nunc ante, feugiat vitae dignissim vel, porta at arcu. Fusce feugiat quis nunc sit amet malesuada. Suspendisse iaculis neque sed nibh dictum, vitae tempus nisi consequat. In consectetur vitae tellus sed condimentum. Suspendisse et nulla in neque rutrum vulputate. Morbi sodales sodales hendrerit. Suspendisse potenti. Sed adipiscing ante gravida rutrum commodo. Etiam malesuada suscipit augue et cursus. Vivamus pharetra bibendum gravida.</p>

<p>Maecenas mauris urna, fringilla id risus a, pulvinar lobortis purus. Integer suscipit risus in est condimentum dapibus. Nunc aliquet, purus convallis venenatis pretium, est neque elementum risus, non accumsan orci nisl at leo. Vivamus dignissim lacus in mauris auctor aliquam. Sed a velit id nunc bibendum tincidunt. Pellentesque vitae massa nunc. Aenean sagittis nulla mauris, ut porttitor mi varius at. Nam quis congue metus. Cras consectetur fringilla ultricies. Quisque odio orci, tincidunt vitae placerat id, rhoncus sit amet sapien. In a lorem vitae justo aliquet porttitor. Vestibulum et enim commodo, vestibulum nibh ullamcorper, auctor felis. Nulla facilisi. Nullam facilisis posuere metus id imperdiet. In iaculis elementum suscipit. Praesent dignissim turpis at leo sollicitudin, eu ultricies metus consectetur.</p>

<p>Donec diam magna, adipiscing vitae mi a, aliquet condimentum nunc. Pellentesque id augue imperdiet, fringilla ante eget, ornare elit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Proin in lectus quis dolor gravida rhoncus condimentum nec mi. Suspendisse urna massa, eleifend vel arcu ac, facilisis malesuada sem. Ut a eros ut nisl tempus luctus. Nam pharetra quis dui sed tristique. Duis ultrices cursus rhoncus. Proin tortor lorem, scelerisque quis cursus ac, sodales tempor nisl. Vestibulum posuere quis elit nec faucibus.</p>

<p>Maecenas nec lectus lacus. Proin quis lectus vitae nisi vehicula vulputate bibendum et purus. Aenean vulputate aliquet justo, quis auctor nunc. Curabitur ut mi nibh. Cras consectetur sem a felis tempor, id pretium mauris rhoncus. Sed sodales, turpis eu facilisis dapibus, lectus mi ullamcorper justo, sit amet rutrum ante ligula lobortis libero. Curabitur consequat et neque id malesuada.</p>
[/et_pb_text]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Page Left Sidebar', '', 'publish', 'open', 'open', '', 'page-left-sidebar-2', '', '', '2014-02-13 15:33:22', '2014-02-13 15:33:22', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=35', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (36, 1, '2014-02-13 15:33:22', '2014-02-13 15:33:22', '
[et_pb_section background_color="#7ebec5" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="Page With Right Sidebar" subhead="Here is a basic page layout." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="3_4"]
[et_pb_text]
<h3>Just A Standard Page</h3>
<p>Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.</p>

<p>Sed sit amet blandit ipsum, et consectetur libero. Integer convallis at metus quis molestie. Morbi vitae odio ut ante molestie scelerisque. Aliquam erat volutpat. Vivamus dignissim fringilla semper. Aliquam imperdiet dui a purus pellentesque, non ornare ipsum blandit. Sed imperdiet elit in quam egestas lacinia nec sit amet dui. Cras malesuada tincidunt ante, in luctus tellus hendrerit at. Duis massa mauris, bibendum a mollis a, laoreet quis elit. Nulla pulvinar vestibulum est, in viverra nisi malesuada vel. Nam ut ipsum quis est faucibus mattis eu ut turpis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas nunc felis, venenatis in fringilla vel, tempus in turpis. Mauris aliquam dictum dolor at varius. Fusce sed vestibulum metus. Vestibulum dictum ultrices nulla sit amet fermentum.</p>

<h3>Fusce feugiat quis nunc</h3>
<p>Suspendisse non lorem eget tellus posuere ornare ut in diam. Quisque dictum libero non luctus malesuada. Mauris pellentesque risus ipsum, at venenatis elit dignissim id. Aenean at porta mauris. Phasellus nec tellus aliquam, vehicula elit sed, pulvinar nulla. Sed eleifend leo adipiscing sem dictum lobortis. Praesent nunc ante, feugiat vitae dignissim vel, porta at arcu. Fusce feugiat quis nunc sit amet malesuada. Suspendisse iaculis neque sed nibh dictum, vitae tempus nisi consequat. In consectetur vitae tellus sed condimentum. Suspendisse et nulla in neque rutrum vulputate. Morbi sodales sodales hendrerit. Suspendisse potenti. Sed adipiscing ante gravida rutrum commodo. Etiam malesuada suscipit augue et cursus. Vivamus pharetra bibendum gravida.</p>

<p>Maecenas mauris urna, fringilla id risus a, pulvinar lobortis purus. Integer suscipit risus in est condimentum dapibus. Nunc aliquet, purus convallis venenatis pretium, est neque elementum risus, non accumsan orci nisl at leo. Vivamus dignissim lacus in mauris auctor aliquam. Sed a velit id nunc bibendum tincidunt. Pellentesque vitae massa nunc. Aenean sagittis nulla mauris, ut porttitor mi varius at. Nam quis congue metus. Cras consectetur fringilla ultricies. Quisque odio orci, tincidunt vitae placerat id, rhoncus sit amet sapien. In a lorem vitae justo aliquet porttitor. Vestibulum et enim commodo, vestibulum nibh ullamcorper, auctor felis. Nulla facilisi. Nullam facilisis posuere metus id imperdiet. In iaculis elementum suscipit. Praesent dignissim turpis at leo sollicitudin, eu ultricies metus consectetur.</p>

<p>Donec diam magna, adipiscing vitae mi a, aliquet condimentum nunc. Pellentesque id augue imperdiet, fringilla ante eget, ornare elit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Proin in lectus quis dolor gravida rhoncus condimentum nec mi. Suspendisse urna massa, eleifend vel arcu ac, facilisis malesuada sem. Ut a eros ut nisl tempus luctus. Nam pharetra quis dui sed tristique. Duis ultrices cursus rhoncus. Proin tortor lorem, scelerisque quis cursus ac, sodales tempor nisl. Vestibulum posuere quis elit nec faucibus.</p>

<p>Maecenas nec lectus lacus. Proin quis lectus vitae nisi vehicula vulputate bibendum et purus. Aenean vulputate aliquet justo, quis auctor nunc. Curabitur ut mi nibh. Cras consectetur sem a felis tempor, id pretium mauris rhoncus. Sed sodales, turpis eu facilisis dapibus, lectus mi ullamcorper justo, sit amet rutrum ante ligula lobortis libero. Curabitur consequat et neque id malesuada.</p>
[/et_pb_text]
[/et_pb_column]
[et_pb_column type="1_4"]
[et_pb_sidebar area="sidebar-1" orientation="right"][/et_pb_sidebar]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'Page Right Sidebar', '', 'publish', 'open', 'open', '', 'page-right-sidebar-2', '', '', '2014-02-13 15:33:22', '2014-02-13 15:33:22', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=36', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (37, 1, '2014-02-13 15:33:22', '2014-02-13 15:33:22', '
[et_pb_section background_color="#6aceb6" inner_shadow="on" fullwidth="on"]
[et_pb_fullwidth_header title="Frequently Asked Questions" subhead="Before contacting us, please browse our FAQ." background_layout="dark"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type="4_4"]
[et_pb_toggle title="Can I use the themes on multiple sites?"]
Yes, you are free to use our themes on as many websites as you like. We do not place any restrictions on how many times you can download or use a theme, nor do we limit the number of domains that you can install our themes to.
[/et_pb_toggle]
[et_pb_toggle open="on" title="What is your refund policy?"]
We offer no-questions-asked refunds to all customers within 30 days of your purchase. If you are not satisfied with our product, then simply send us an email and we will refund your purchase right away. Our goal has always been to create a happy, thriving community. If you are not thrilled with the product or are not enjoying the experience, then we have no interest in forcing you to stay an unhappy member.
[/et_pb_toggle]
[et_pb_toggle title="What are Photoshop Files?"]
Elegant Themes offers two different packages: Personal and Developer. The Personal Subscription is ideal for the average user while the Developers License is meant for experienced designers who wish to customize their themes using the original Photoshop files. Photoshop files are the original design files that were used to create the theme. They can be opened using Adobe Photoshop and edited, and prove very useful for customers wishing to change their theme\'s design in some way.
[/et_pb_toggle]
[et_pb_toggle title="Can I upgrade after signing up?"]
Yes, you can upgrade at any time after signing up. When you log in as a "personal" subscriber, you will see a notice regarding your current package and instructions on how to upgrade.
[/et_pb_toggle]
[et_pb_toggle title="Can I use your themes with WP.com?"]
Unfortunately WordPress.com does not allow the use of custom themes. If you would like to use a custom theme of any kind, you will need to purchase your own hosting account and install the free software from WordPress.org. If you are looking for great WordPress hosting, we recommend giving HostGator a try.[/et_pb_toggle]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]', 'FAQ Page', '', 'publish', 'open', 'open', '', 'faq-page-2', '', '', '2014-02-13 15:33:22', '2014-02-13 15:33:22', '', 0, 'http://localhost:8080/fixitall//?post_type=et_pb_layout&p=37', 0, 'et_pb_layout', '', 0) ; 
INSERT INTO `wp_posts` VALUES (38, 1, '2014-02-13 16:00:15', '2014-02-13 16:00:15', '', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2014-02-13 22:30:41', '2014-02-13 22:30:41', '', 0, 'http://localhost:8080/fixitall//?p=38', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (41, 1, '2014-02-13 16:04:07', '2014-02-13 16:04:07', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At PluMax Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

<hr />



<hr />
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>
<h4>Unclog Your Drain</h4>
We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479.jpg"><img class="size-thumbnail wp-image-107 alignleft" alt="Root-Intrusion-by-Wilf-Ratzburg-e1374302277479" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479-150x150.jpg" width="150" height="150" /></a>
<h4>Fix Root Intrusions</h4>
We’ll get to the root of the problem! Old clay pipes can be damaged and leak because of inferior materials used in older construction.

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Gas-leak-by-Crow-Girl-e1374331227435.jpg"><img class="size-thumbnail wp-image-114 alignleft" alt="Gas-leak-by-Crow-Girl-e1374331227435" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Gas-leak-by-Crow-Girl-e1374331227435-150x150.jpg" width="150" height="150" /></a>
<h4>Detect Gas Leaks</h4>
We can test your office/retail location for a gas leak, shut-off a gas leak and repair a gas leak.

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Reinstall-Pipes-by-Michaela-Kobyakov-V-Max-plumbing-e1374362282501.jpg"><img class="size-thumbnail wp-image-117 alignleft" alt="Reinstall-Pipes-by-Michaela-Kobyakov-V-Max-plumbing-e1374362282501" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Reinstall-Pipes-by-Michaela-Kobyakov-V-Max-plumbing-e1374362282501-150x150.jpg" width="150" height="150" /></a>
<h4>Reinstall Pipes</h4>
We can reinstall pipes in your walls, including removing your old galvanized pipes and replacing them with modern, type “L”, copper pipes.

[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial/Residential', '', 'publish', 'open', 'open', '', 'commercial-residential', '', '', '2014-02-16 19:52:11', '2014-02-16 19:52:11', '', 0, 'http://localhost:8080/fixitall//?page_id=41', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (42, 1, '2014-02-13 16:04:07', '2014-02-13 16:04:07', 'page 1 text', 'page1', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 16:04:07', '2014-02-13 16:04:07', '', 41, 'http://localhost:8080/fixitall//?p=42', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (49, 1, '2014-02-13 16:05:18', '2014-02-13 16:05:18', ' ', '', '', 'publish', 'open', 'open', '', '49', '', '', '2014-02-13 22:30:41', '2014-02-13 22:30:41', '', 0, 'http://localhost:8080/fixitall//?p=49', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (50, 1, '2014-02-13 17:02:32', '2014-02-13 17:02:32', '[et_pb_section][et_pb_row][et_pb_column type="1_3"][et_pb_cta admin_label="Call To Action" title="Call Now!" background_color="#7EBEC5" use_background_color="on" background_layout="dark" text_orientation="center"]
<h1>(310) 555-1212[/et_pb_cta][/et_pb_column][et_pb_column type="2_3"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]<h1>Why choose us</h1><p>There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and PluMax Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.</p>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][et_pb_divider admin_label="Divider" color="#ffffff" show_divider="on" /][et_pb_blurb admin_label="Blurb" title="Locally Owned and Operated" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing is locally owned, based and operated. The founders of the company, the staffs and everyone associated with the organization are from the city and surrounding areas of Paramount in California. While there is no standard rule that says locally owned companies are better than those having a nationwide presence or than the franchisees that are often catering to distant areas where they do not have a base, but the reality is that knowledge and awareness helps. When plumbers cater to areas that they are personal extremely familiar with, they are more aware of the challenges that a home, office or commercial property faces. For instance, if you are planning to install a new plumbing system, a local plumbing company would be helpful as they wouldn’t have to find out the building regulations. They would already know. At PluMax Plumbing, we already know the kinds of problems that residents, business owners and property managers face in Paramount and surrounding areas in California. Seldom do we need a briefing from our clients because of the knowledge and albeit due to our expertise.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="24/7 Emergency Plumbing" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Satisfaction Guarenteed" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has a unique offering where you are not only happy with the quality of work done but you would also be extremely satisfied with the entire experience. Right from the initial consultation through the schedule to the post service relation that we cherish with our clients, you would be completely satiated with every facet of our service and that is a guarantee.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Quality at an Affordable Price" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

Quality doesn’t come cheap and what comes cheap cannot be of great quality – such is the reality in many cases. With PluMax Plumbing, you experience an exception. We are one of the very few plumbing companies in the state that offers quality work at inexpensive rates.

[/et_pb_blurb][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="David Bodner" url_new_window="off"]

I wholeheartedly recommend PluMax Plumbing for your residential plumbing needs. I have used their services on two occasions now. They are prompt, perform excellent work and charge fair prices. They clean up after their work and leave your house in excellent condition. Will use their services again.

[/et_pb_testimonial][/et_pb_column][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="Michael Bilnik" url_new_window="off"]

We have called Plumax Plumbing on two separation occasions. The first was a flooded basement. Josh gave us a competitive quote and installed a sump pump that works great. It was great to find a reliable, honest plumber who wouldn\'t take advantage of your dire situation. PluMax Plumbing also installed our hot water tank. And they did it quick and with respect for our property - leaving no mess behind. In both cases, we received professional installation. And more importantly, both projects stayed within the estimate, and our budget. If you\'re looking for a plumber you can trust, and afford, I highly recommend PluMax Plumbing!

[/et_pb_testimonial][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2014-02-16 18:40:12', '2014-02-16 18:40:12', '', 0, 'http://localhost:8080/fixitall//?page_id=50', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (51, 1, '2014-02-13 17:02:32', '2014-02-13 17:02:32', 'home text', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 17:02:32', '2014-02-13 17:02:32', '', 50, 'http://localhost:8080/fixitall//?p=51', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (53, 1, '2014-02-13 20:15:32', '2014-02-13 20:15:32', '', 'plumax(logo1)', '', 'inherit', 'open', 'open', '', 'plumaxlogo1', '', '', '2014-02-13 20:15:32', '2014-02-13 20:15:32', '', 0, 'http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumaxlogo1.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (54, 1, '2014-02-13 20:22:13', '2014-02-13 20:22:13', '', 'plumax(favicon1)', '', 'inherit', 'open', 'open', '', 'plumaxfavicon1', '', '', '2014-02-13 20:22:13', '2014-02-13 20:22:13', '', 0, 'http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumaxfavicon1.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (55, 1, '2014-02-13 20:29:11', '2014-02-13 20:29:11', '<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 20:29:11', '2014-02-13 20:29:11', '', 50, 'http://localhost:8080/fixitall//?p=55', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (56, 1, '2014-02-13 20:30:06', '2014-02-13 20:30:06', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 20:30:06', '2014-02-13 20:30:06', '', 50, 'http://localhost:8080/fixitall//?p=56', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (57, 1, '2014-04-29 17:55:58', '2014-04-29 17:55:58', '[et_pb_section][et_pb_row][et_pb_column type="1_3"][et_pb_cta admin_label="Call To Action" title="Call Now!" background_color="#7EBEC5" use_background_color="on" background_layout="dark" text_orientation="center"]
<h1>(310) 555-1212[/et_pb_cta][/et_pb_column][et_pb_column type="2_3"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]</h1>
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and PluMax Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][et_pb_divider admin_label="Divider" color="#ffffff" show_divider="on" /][et_pb_blurb admin_label="Blurb" title="Locally Owned and Operated" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing is locally owned, based and operated. The founders of the company, the staffs and everyone associated with the organization are from the city and surrounding areas of Paramount in California. While there is no standard rule that says locally owned companies are better than those having a nationwide presence or than the franchisees that are often catering to distant areas where they do not have a base, but the reality is that knowledge and awareness helps. When plumbers cater to areas that they are personal extremely familiar with, they are more aware of the challenges that a home, office or commercial property faces. For instance, if you are planning to install a new plumbing system, a local plumbing company would be helpful as they wouldn’t have to find out the building regulations. They would already know. At PluMax Plumbing, we already know the kinds of problems that residents, business owners and property managers face in Paramount and surrounding areas in California. Seldom do we need a briefing from our clients because of the knowledge and albeit due to our expertise.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="24/7 Emergency Plumbing" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Satisfaction Guarenteed" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has a unique offering where you are not only happy with the quality of work done but you would also be extremely satisfied with the entire experience. Right from the initial consultation through the schedule to the post service relation that we cherish with our clients, you would be completely satiated with every facet of our service and that is a guarantee.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Quality at an Affordable Price" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

Quality doesn’t come cheap and what comes cheap cannot be of great quality – such is the reality in many cases. With PluMax Plumbing, you experience an exception. We are one of the very few plumbing companies in the state that offers quality work at inexpensive rates.

[/et_pb_blurb][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="David Bodner" url_new_window="off"]

I wholeheartedly recommend PluMax Plumbing for your residential plumbing needs. I have used their services on two occasions now. They are prompt, perform excellent work and charge fair prices. They clean up after their work and leave your house in excellent condition. Will use their services again.

[/et_pb_testimonial][/et_pb_column][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="Michael Bilnik" url_new_window="off"]

We have called Plumax Plumbing on two separation occasions. The first was a flooded basement. Josh gave us a competitive quote and installed a sump pump that works great. It was great to find a reliable, honest plumber who wouldn\'t take advantage of your dire situation. PluMax Plumbing also installed our hot water tank. And they did it quick and with respect for our property - leaving no mess behind. In both cases, we received professional installation. And more importantly, both projects stayed within the estimate, and our budget. If you\'re looking for a plumber you can trust, and afford, I highly recommend PluMax Plumbing!

[/et_pb_testimonial][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-autosave-v1', '', '', '2014-04-29 17:55:58', '2014-04-29 17:55:58', '', 50, 'http://localhost:8080/fixitall//?p=57', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (58, 1, '2014-02-13 20:36:11', '2014-02-13 20:36:11', '', 'plumber-guy', '', 'inherit', 'open', 'open', '', 'plumber-guy', '', '', '2014-02-13 20:36:11', '2014-02-13 20:36:11', '', 50, 'http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy.jpeg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (59, 1, '2014-02-13 20:36:21', '2014-02-13 20:36:21', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off"][et_pb_slide heading="slider1" background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy.jpeg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 20:36:21', '2014-02-13 20:36:21', '', 50, 'http://localhost:8080/fixitall//?p=59', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (60, 1, '2014-02-13 20:48:42', '2014-02-13 20:48:42', '', 'plumber-guy2', '', 'inherit', 'open', 'open', '', 'plumber-guy2', '', '', '2014-02-13 20:48:42', '2014-02-13 20:48:42', '', 50, 'http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (61, 1, '2014-02-13 20:48:49', '2014-02-13 20:48:49', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off"][et_pb_slide heading="slider1" background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 20:48:49', '2014-02-13 20:48:49', '', 50, 'http://localhost:8080/fixitall//?p=61', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (62, 1, '2014-02-13 20:52:51', '2014-02-13 20:52:51', '', 'plumbing-slide2', '', 'inherit', 'open', 'open', '', 'plumbing-slide2', '', '', '2014-02-13 20:52:51', '2014-02-13 20:52:51', '', 50, 'http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (63, 1, '2014-02-13 20:52:57', '2014-02-13 20:52:57', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off"][et_pb_slide heading="slider1" background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide heading="slide2" background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 20:52:57', '2014-02-13 20:52:57', '', 50, 'http://localhost:8080/fixitall//?p=63', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (64, 1, '2014-02-13 20:56:22', '2014-02-13 20:56:22', '', 'plumbing-slide3', '', 'inherit', 'open', 'open', '', 'plumbing-slide3', '', '', '2014-02-13 20:56:22', '2014-02-13 20:56:22', '', 50, 'http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (65, 1, '2014-02-13 20:56:50', '2014-02-13 20:56:50', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off"][et_pb_slide heading="slider1" background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide heading="slide2" background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide heading="slide3" background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 20:56:50', '2014-02-13 20:56:50', '', 50, 'http://localhost:8080/fixitall//?p=65', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (66, 1, '2014-02-13 20:58:43', '2014-02-13 20:58:43', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 20:58:43', '2014-02-13 20:58:43', '', 50, 'http://localhost:8080/fixitall//?p=66', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (67, 1, '2014-02-13 21:04:55', '2014-02-13 21:04:55', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 21:04:55', '2014-02-13 21:04:55', '', 50, 'http://localhost:8080/fixitall//?p=67', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (69, 1, '2014-02-13 21:08:26', '2014-02-13 21:08:26', 'page 1 text', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 21:08:26', '2014-02-13 21:08:26', '', 41, 'http://localhost:8080/fixitall//?p=69', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (71, 1, '2014-02-13 21:09:10', '2014-02-13 21:09:10', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h2>The Most Reliable Plumber In Southern California</h2>
[box]

Over the years, the quality, efficacy, affordability and longevity of the work done by PluMax Plumbing has made us the most trusted and favorite plumbers for homeowners as well as commercial property owners. PluMax Plumbing specializes in all kinds of plumbing tasks.

Whether you need a particular plumbing fixture repaired or you are looking for a complete overhaul of your plumbing systems, PluMax Plumbing is the best choice at your discretion. No job is too big and no task is too small for us at PluMax Plumbing.

[/box]

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h2>Experienced Combined With Unparalleled Service</h2>
[box] PluMax Plumbing has always put customers first. While dealing with us, right from the first phone call or email to the invoicing and post service interactions or consultations, you would experience unparallel service.
<ul>
	<li>PluMax Plumbing offers prompt and dependable service. Our teams would be at your site at the time that is promised and would get the job done as promised.</li>
	<li>You have the luxury to opt for a schedule that is convenient for you. You can take into account all the factors that are important to you and then choose a certain schedule when the team from PluMax Plumbing can get the job done and we would do exactly according to that.</li>
	<li>PluMax Plumbing has the distinction of offering extremely reasonable rates, even for the most complex plumbing installations, repairs and maintenance.</li>
</ul>
Call us today at (310) 555-1212 and let us handle all of your plumbing needs with unmatchable expertise and impeccable service at extremely reasonable rates.

[/box]

[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'About', '', 'publish', 'open', 'open', '', 'about', '', '', '2014-02-16 18:42:35', '2014-02-16 18:42:35', '', 0, 'http://localhost:8080/fixitall//?page_id=71', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (72, 1, '2014-02-13 21:09:10', '2014-02-13 21:09:10', '', 'About', '', 'inherit', 'open', 'open', '', '71-revision-v1', '', '', '2014-02-13 21:09:10', '2014-02-13 21:09:10', '', 71, 'http://localhost:8080/fixitall//?p=72', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (73, 1, '2014-02-13 21:09:42', '2014-02-13 21:09:42', '', 'Latest News', '', 'publish', 'open', 'open', '', 'latest-news', '', '', '2014-02-13 21:09:42', '2014-02-13 21:09:42', '', 0, 'http://localhost:8080/fixitall//?page_id=73', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (74, 1, '2014-02-13 21:09:42', '2014-02-13 21:09:42', '', 'Latest News', '', 'inherit', 'open', 'open', '', '73-revision-v1', '', '', '2014-02-13 21:09:42', '2014-02-13 21:09:42', '', 73, 'http://localhost:8080/fixitall//?p=74', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (75, 1, '2014-02-13 21:10:16', '2014-02-13 21:10:16', ' ', '', '', 'publish', 'open', 'open', '', '75', '', '', '2014-02-13 22:30:41', '2014-02-13 22:30:41', '', 0, 'http://localhost:8080/fixitall//?p=75', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (76, 1, '2014-02-13 21:10:15', '2014-02-13 21:10:15', ' ', '', '', 'publish', 'open', 'open', '', '76', '', '', '2014-02-13 22:30:41', '2014-02-13 22:30:41', '', 0, 'http://localhost:8080/fixitall//?p=76', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (77, 1, '2014-02-13 21:14:13', '2014-02-13 21:14:13', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 21:14:13', '2014-02-13 21:14:13', '', 50, 'http://localhost:8080/fixitall//?p=77', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (78, 1, '2014-02-13 21:19:17', '2014-02-13 21:19:17', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="1_2"][et_pb_blurb admin_label="Blurb" title="Locally Owned and Operated" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

V-Max Plumbing is locally owned, based and operated. The founders of the company, the staffs and everyone associated with the organization are from the city and surrounding areas of Paramount in California. While there is no standard rule that says locally owned companies are better than those having a nationwide presence or than the franchisees that are often catering to distant areas where they do not have a base, but the reality is that knowledge and awareness helps. When plumbers cater to areas that they are personal extremely familiar with, they are more aware of the challenges that a home, office or commercial property faces. For instance, if you are planning to install a new plumbing system, a local plumbing company would be helpful as they wouldn’t have to find out the building regulations. They would already know. At V-Max Plumbing, we already know the kinds of problems that residents, business owners and property managers face in Paramount and surrounding areas in California. Seldom do we need a briefing from our clients because of the knowledge and albeit due to our expertise.

&nbsp;

[/et_pb_blurb][/et_pb_column][et_pb_column type="1_2"][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 21:19:17', '2014-02-13 21:19:17', '', 50, 'http://localhost:8080/fixitall//?p=78', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (79, 1, '2014-02-13 21:19:58', '2014-02-13 21:19:58', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][et_pb_blurb admin_label="Blurb" title="Locally Owned and Operated" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

V-Max Plumbing is locally owned, based and operated. The founders of the company, the staffs and everyone associated with the organization are from the city and surrounding areas of Paramount in California. While there is no standard rule that says locally owned companies are better than those having a nationwide presence or than the franchisees that are often catering to distant areas where they do not have a base, but the reality is that knowledge and awareness helps. When plumbers cater to areas that they are personal extremely familiar with, they are more aware of the challenges that a home, office or commercial property faces. For instance, if you are planning to install a new plumbing system, a local plumbing company would be helpful as they wouldn’t have to find out the building regulations. They would already know. At V-Max Plumbing, we already know the kinds of problems that residents, business owners and property managers face in Paramount and surrounding areas in California. Seldom do we need a briefing from our clients because of the knowledge and albeit due to our expertise.

[/et_pb_blurb][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="1_2"][/et_pb_column][et_pb_column type="1_2"][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 21:19:58', '2014-02-13 21:19:58', '', 50, 'http://localhost:8080/fixitall//?p=79', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (80, 1, '2014-02-13 21:20:41', '2014-02-13 21:20:41', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][et_pb_blurb admin_label="Blurb" title="Locally Owned and Operated" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing is locally owned, based and operated. The founders of the company, the staffs and everyone associated with the organization are from the city and surrounding areas of Paramount in California. While there is no standard rule that says locally owned companies are better than those having a nationwide presence or than the franchisees that are often catering to distant areas where they do not have a base, but the reality is that knowledge and awareness helps. When plumbers cater to areas that they are personal extremely familiar with, they are more aware of the challenges that a home, office or commercial property faces. For instance, if you are planning to install a new plumbing system, a local plumbing company would be helpful as they wouldn’t have to find out the building regulations. They would already know. At V-Max Plumbing, we already know the kinds of problems that residents, business owners and property managers face in Paramount and surrounding areas in California. Seldom do we need a briefing from our clients because of the knowledge and albeit due to our expertise.

[/et_pb_blurb][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="1_2"][/et_pb_column][et_pb_column type="1_2"][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 21:20:41', '2014-02-13 21:20:41', '', 50, 'http://localhost:8080/fixitall//?p=80', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (81, 1, '2014-02-13 21:21:14', '2014-02-13 21:21:14', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][et_pb_blurb admin_label="Blurb" title="Locally Owned and Operated" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing is locally owned, based and operated. The founders of the company, the staffs and everyone associated with the organization are from the city and surrounding areas of Paramount in California. While there is no standard rule that says locally owned companies are better than those having a nationwide presence or than the franchisees that are often catering to distant areas where they do not have a base, but the reality is that knowledge and awareness helps. When plumbers cater to areas that they are personal extremely familiar with, they are more aware of the challenges that a home, office or commercial property faces. For instance, if you are planning to install a new plumbing system, a local plumbing company would be helpful as they wouldn’t have to find out the building regulations. They would already know. At PluMax Plumbing, we already know the kinds of problems that residents, business owners and property managers face in Paramount and surrounding areas in California. Seldom do we need a briefing from our clients because of the knowledge and albeit due to our expertise.

[/et_pb_blurb][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="1_2"][/et_pb_column][et_pb_column type="1_2"][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 21:21:14', '2014-02-13 21:21:14', '', 50, 'http://localhost:8080/fixitall//?p=81', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (82, 1, '2014-02-13 21:23:26', '2014-02-13 21:23:26', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][et_pb_blurb admin_label="Blurb" title="Locally Owned and Operated" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing is locally owned, based and operated. The founders of the company, the staffs and everyone associated with the organization are from the city and surrounding areas of Paramount in California. While there is no standard rule that says locally owned companies are better than those having a nationwide presence or than the franchisees that are often catering to distant areas where they do not have a base, but the reality is that knowledge and awareness helps. When plumbers cater to areas that they are personal extremely familiar with, they are more aware of the challenges that a home, office or commercial property faces. For instance, if you are planning to install a new plumbing system, a local plumbing company would be helpful as they wouldn’t have to find out the building regulations. They would already know. At PluMax Plumbing, we already know the kinds of problems that residents, business owners and property managers face in Paramount and surrounding areas in California. Seldom do we need a briefing from our clients because of the knowledge and albeit due to our expertise.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="24/7 Emergency Plumbing" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.

&nbsp;

[/et_pb_blurb][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="1_2"][/et_pb_column][et_pb_column type="1_2"][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 21:23:26', '2014-02-13 21:23:26', '', 50, 'http://localhost:8080/fixitall//?p=82', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (83, 1, '2014-02-13 21:24:36', '2014-02-13 21:24:36', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][et_pb_blurb admin_label="Blurb" title="Locally Owned and Operated" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing is locally owned, based and operated. The founders of the company, the staffs and everyone associated with the organization are from the city and surrounding areas of Paramount in California. While there is no standard rule that says locally owned companies are better than those having a nationwide presence or than the franchisees that are often catering to distant areas where they do not have a base, but the reality is that knowledge and awareness helps. When plumbers cater to areas that they are personal extremely familiar with, they are more aware of the challenges that a home, office or commercial property faces. For instance, if you are planning to install a new plumbing system, a local plumbing company would be helpful as they wouldn’t have to find out the building regulations. They would already know. At PluMax Plumbing, we already know the kinds of problems that residents, business owners and property managers face in Paramount and surrounding areas in California. Seldom do we need a briefing from our clients because of the knowledge and albeit due to our expertise.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="24/7 Emergency Plumbing" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Satisfaction Guarenteed" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has a unique offering where you are not only happy with the quality of work done but you would also be extremely satisfied with the entire experience. Right from the initial consultation through the schedule to the post service relation that we cherish with our clients, you would be completely satiated with every facet of our service and that is a guarantee.

[/et_pb_blurb][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="1_2"][/et_pb_column][et_pb_column type="1_2"][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 21:24:36', '2014-02-13 21:24:36', '', 50, 'http://localhost:8080/fixitall//?p=83', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (84, 1, '2014-02-13 21:26:25', '2014-02-13 21:26:25', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][et_pb_blurb admin_label="Blurb" title="Locally Owned and Operated" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing is locally owned, based and operated. The founders of the company, the staffs and everyone associated with the organization are from the city and surrounding areas of Paramount in California. While there is no standard rule that says locally owned companies are better than those having a nationwide presence or than the franchisees that are often catering to distant areas where they do not have a base, but the reality is that knowledge and awareness helps. When plumbers cater to areas that they are personal extremely familiar with, they are more aware of the challenges that a home, office or commercial property faces. For instance, if you are planning to install a new plumbing system, a local plumbing company would be helpful as they wouldn’t have to find out the building regulations. They would already know. At PluMax Plumbing, we already know the kinds of problems that residents, business owners and property managers face in Paramount and surrounding areas in California. Seldom do we need a briefing from our clients because of the knowledge and albeit due to our expertise.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="24/7 Emergency Plumbing" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Satisfaction Guarenteed" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has a unique offering where you are not only happy with the quality of work done but you would also be extremely satisfied with the entire experience. Right from the initial consultation through the schedule to the post service relation that we cherish with our clients, you would be completely satiated with every facet of our service and that is a guarantee.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Quality at an Affordable Price" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

Quality doesn’t come cheap and what comes cheap cannot be of great quality – such is the reality in many cases. With PluMax Plumbing, you experience an exception. We are one of the very few plumbing companies in the state that offers quality work at inexpensive rates.

&nbsp;

[/et_pb_blurb][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="1_2"][/et_pb_column][et_pb_column type="1_2"][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 21:26:25', '2014-02-13 21:26:25', '', 50, 'http://localhost:8080/fixitall//?p=84', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (85, 1, '2014-02-13 21:30:33', '2014-02-13 21:30:33', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][et_pb_blurb admin_label="Blurb" title="Locally Owned and Operated" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing is locally owned, based and operated. The founders of the company, the staffs and everyone associated with the organization are from the city and surrounding areas of Paramount in California. While there is no standard rule that says locally owned companies are better than those having a nationwide presence or than the franchisees that are often catering to distant areas where they do not have a base, but the reality is that knowledge and awareness helps. When plumbers cater to areas that they are personal extremely familiar with, they are more aware of the challenges that a home, office or commercial property faces. For instance, if you are planning to install a new plumbing system, a local plumbing company would be helpful as they wouldn’t have to find out the building regulations. They would already know. At PluMax Plumbing, we already know the kinds of problems that residents, business owners and property managers face in Paramount and surrounding areas in California. Seldom do we need a briefing from our clients because of the knowledge and albeit due to our expertise.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="24/7 Emergency Plumbing" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Satisfaction Guarenteed" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has a unique offering where you are not only happy with the quality of work done but you would also be extremely satisfied with the entire experience. Right from the initial consultation through the schedule to the post service relation that we cherish with our clients, you would be completely satiated with every facet of our service and that is a guarantee.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Quality at an Affordable Price" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

Quality doesn’t come cheap and what comes cheap cannot be of great quality – such is the reality in many cases. With PluMax Plumbing, you experience an exception. We are one of the very few plumbing companies in the state that offers quality work at inexpensive rates.

[/et_pb_blurb][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="David Bodner" url_new_window="off"]

I wholeheartedly recommend PluMax Plumbing for your residential plumbing needs. I have used their services on two occasions now. They are prompt, perform excellent work and charge fair prices. They clean up after their work and leave your house in excellent condition. Will use their services again.

[/et_pb_testimonial][/et_pb_column][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="Michael Bilnik" url_new_window="off"]

We have called Plumax Plumbing on two separation occasions. The first was a flooded basement. Josh gave us a competitive quote and installed a sump pump that works great. It was great to find a reliable, honest plumber who wouldn\'t take advantage of your dire situation. PluMax Plumbing also installed our hot water tank. And they did it quick and with respect for our property - leaving no mess behind. In both cases, we received professional installation. And more importantly, both projects stayed within the estimate, and our budget. If you\'re looking for a plumber you can trust, and afford, I highly recommend PluMax Plumbing!

&nbsp;

[/et_pb_testimonial][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 21:30:33', '2014-02-13 21:30:33', '', 50, 'http://localhost:8080/fixitall//?p=85', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (86, 1, '2014-02-13 21:33:43', '2014-02-13 21:33:43', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<em>At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach.</em>

[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 21:33:43', '2014-02-13 21:33:43', '', 41, 'http://localhost:8080/fixitall//?p=86', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (87, 1, '2014-02-13 21:34:36', '2014-02-13 21:34:36', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<em>At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach.</em>

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 21:34:36', '2014-02-13 21:34:36', '', 41, 'http://localhost:8080/fixitall//?p=87', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (88, 1, '2014-02-13 22:23:29', '2014-02-13 22:23:29', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>
<h4>Unclog Your Drain</h4>
We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479.jpg"><img class="size-thumbnail wp-image-107 alignleft" alt="Root-Intrusion-by-Wilf-Ratzburg-e1374302277479" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479-150x150.jpg" width="150" height="150" /></a>
<h4>Fix Root Intrusions</h4>
We’ll get to the root of the problem! Old clay pipes can be damaged and leak because of inferior materials used in older construction.

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Gas-leak-by-Crow-Girl-e1374331227435.jpg"><img class="size-thumbnail wp-image-114 alignleft" alt="Gas-leak-by-Crow-Girl-e1374331227435" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Gas-leak-by-Crow-Girl-e1374331227435-150x150.jpg" width="150" height="150" /></a>
<h4>Detect Gas Leaks</h4>
We can test your office/retail location for a gas leak, shut-off a gas leak and repair a gas leak.

[/et_pb_text][et_pb_text admin_label="Text" /][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-autosave-v1', '', '', '2014-02-13 22:23:29', '2014-02-13 22:23:29', '', 41, 'http://localhost:8080/fixitall//?p=88', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (89, 1, '2014-02-13 21:36:54', '2014-02-13 21:36:54', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<em>At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach.</em>

[/et_pb_text][et_pb_blurb admin_label="Blurb" title="gggg" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.

&nbsp;

[/et_pb_blurb][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 21:36:54', '2014-02-13 21:36:54', '', 41, 'http://localhost:8080/fixitall//?p=89', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (90, 1, '2014-02-13 21:37:54', '2014-02-13 21:37:54', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.

[/et_pb_blurb][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 21:37:54', '2014-02-13 21:37:54', '', 41, 'http://localhost:8080/fixitall//?p=90', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (91, 1, '2014-02-13 21:38:04', '2014-02-13 21:38:04', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.

[/et_pb_blurb][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 21:38:04', '2014-02-13 21:38:04', '', 41, 'http://localhost:8080/fixitall//?p=91', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (92, 1, '2014-02-13 21:38:41', '2014-02-13 21:38:41', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 21:38:41', '2014-02-13 21:38:41', '', 41, 'http://localhost:8080/fixitall//?p=92', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (93, 1, '2014-02-13 21:40:42', '2014-02-13 21:40:42', '', 'Drain-by-Seannnnnnn-e1374301069177', '', 'inherit', 'open', 'open', '', 'drain-by-seannnnnnn-e1374301069177', '', '', '2014-02-13 21:40:42', '2014-02-13 21:40:42', '', 41, 'http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (94, 1, '2014-02-13 21:40:54', '2014-02-13 21:40:54', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_cta admin_label="Call To Action" title="Unclog Your Drain" background_color="#7EBEC5" use_background_color="on" background_layout="dark" text_orientation="center"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-full wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg" width="200" height="200" /></a>We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.

[/et_pb_cta][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 21:40:54', '2014-02-13 21:40:54', '', 41, 'http://localhost:8080/fixitall//?p=94', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (95, 1, '2014-02-13 21:42:05', '2014-02-13 21:42:05', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_cta admin_label="Call To Action" title="Unclog Your Drain" background_color="#7EBEC5" use_background_color="on" background_layout="dark" text_orientation="center"]

We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.

[/et_pb_cta][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 21:42:05', '2014-02-13 21:42:05', '', 41, 'http://localhost:8080/fixitall//?p=95', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (96, 1, '2014-02-13 21:43:00', '2014-02-13 21:43:00', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_cta admin_label="Call To Action" title="Unclog Your Drain" background_color="#7EBEC5" use_background_color="on" background_layout="dark" text_orientation="center"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="alignnone size-thumbnail wp-image-93" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.

[/et_pb_cta][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 21:43:00', '2014-02-13 21:43:00', '', 41, 'http://localhost:8080/fixitall//?p=96', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (97, 1, '2014-02-13 21:43:35', '2014-02-13 21:43:35', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_cta admin_label="Call To Action" title="Unclog Your Drain" background_color="#7EBEC5" use_background_color="on" background_layout="dark" text_orientation="center"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="alignnone size-thumbnail wp-image-93" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>

We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.

[/et_pb_cta][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 21:43:35', '2014-02-13 21:43:35', '', 41, 'http://localhost:8080/fixitall//?p=97', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (98, 1, '2014-02-13 21:44:36', '2014-02-13 21:44:36', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_cta admin_label="Call To Action" title="Unclog Your Drain" background_color="#7EBEC5" use_background_color="on" background_layout="dark" text_orientation="center"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="alignnone size-thumbnail wp-image-93" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>

We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.

[/et_pb_cta][et_pb_image admin_label="Image" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg" url_new_window="off" animation="off" /][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 21:44:36', '2014-02-13 21:44:36', '', 41, 'http://localhost:8080/fixitall//?p=98', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (99, 1, '2014-02-13 21:46:29', '2014-02-13 21:46:29', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_cta admin_label="Call To Action" title="Unclog Your Drain" background_color="#7EBEC5" use_background_color="on" background_layout="dark" text_orientation="center"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>
<blockquote>We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.</blockquote>
[/et_pb_cta][et_pb_image admin_label="Image" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg" url_new_window="off" animation="off" /][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 21:46:29', '2014-02-13 21:46:29', '', 41, 'http://localhost:8080/fixitall//?p=99', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (100, 1, '2014-02-13 21:47:37', '2014-02-13 21:47:37', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_cta admin_label="Call To Action" background_color="#7EBEC5" use_background_color="on" background_layout="dark" text_orientation="center"]

Unclog Your Drain

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>
<blockquote>We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.</blockquote>
[/et_pb_cta][et_pb_image admin_label="Image" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg" url_new_window="off" animation="off" /][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 21:47:37', '2014-02-13 21:47:37', '', 41, 'http://localhost:8080/fixitall//?p=100', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (101, 1, '2014-02-13 21:52:19', '2014-02-13 21:52:19', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_cta admin_label="Call To Action" background_color="#7EBEC5" use_background_color="on" background_layout="dark" text_orientation="center" title="Unclog Your Drain"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>

We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.

[/et_pb_cta][et_pb_image admin_label="Image" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg" url_new_window="off" animation="off" /][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 21:52:19', '2014-02-13 21:52:19', '', 41, 'http://localhost:8080/fixitall//?p=101', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (102, 1, '2014-02-13 21:56:50', '2014-02-13 21:56:50', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_cta admin_label="Call To Action" background_color="#7EBEC5" use_background_color="on" background_layout="dark" text_orientation="center" title="Unclog Your Drain"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>

<hr />

We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.

[/et_pb_cta][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 21:56:50', '2014-02-13 21:56:50', '', 41, 'http://localhost:8080/fixitall//?p=102', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (103, 1, '2014-02-13 21:59:12', '2014-02-13 21:59:12', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_cta admin_label="Call To Action" background_color="#7EBEC5" use_background_color="on" background_layout="dark" text_orientation="center" title="Unclog Your Drain"]<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignnone" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>

<hr />

We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.

[/et_pb_cta][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 21:59:12', '2014-02-13 21:59:12', '', 41, 'http://localhost:8080/fixitall//?p=103', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (104, 1, '2014-02-13 22:00:36', '2014-02-13 22:00:36', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_cta admin_label="Call To Action" background_color="#7EBEC5" use_background_color="on" background_layout="dark" text_orientation="center" title="Unclog Your Drain"]<p><a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="alignnone size-thumbnail wp-image-93" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a></p><p>We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.</p>[/et_pb_cta][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 22:00:36', '2014-02-13 22:00:36', '', 41, 'http://localhost:8080/fixitall//?p=104', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (105, 1, '2014-02-13 22:05:07', '2014-02-13 22:05:07', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_cta admin_label="Call To Action" background_color="#7EBEC5" use_background_color="on" background_layout="dark" text_orientation="center" title="Unclog Your Drain"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="alignnone size-thumbnail wp-image-93" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>

We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.

[/et_pb_cta][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h4>Unclog Your Drain</h4>
<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.

[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 22:05:07', '2014-02-13 22:05:07', '', 41, 'http://localhost:8080/fixitall//?p=105', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (106, 1, '2014-02-13 22:05:59', '2014-02-13 22:05:59', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_cta admin_label="Call To Action" background_color="#7EBEC5" use_background_color="on" background_layout="dark" text_orientation="center" title="Unclog Your Drain"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="alignnone size-thumbnail wp-image-93" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>

We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.

[/et_pb_cta][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>
<h4>Unclog Your Drain</h4>
We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.

[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 22:05:59', '2014-02-13 22:05:59', '', 41, 'http://localhost:8080/fixitall//?p=106', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (107, 1, '2014-02-13 22:06:58', '2014-02-13 22:06:58', '', 'Root-Intrusion-by-Wilf-Ratzburg-e1374302277479', '', 'inherit', 'open', 'open', '', 'root-intrusion-by-wilf-ratzburg-e1374302277479', '', '', '2014-02-13 22:06:58', '2014-02-13 22:06:58', '', 41, 'http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (108, 1, '2014-02-13 22:08:29', '2014-02-13 22:08:29', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>
<h4>Unclog Your Drain</h4>
We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]<p><a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479.jpg"><img class="size-thumbnail wp-image-107 alignleft" alt="Root-Intrusion-by-Wilf-Ratzburg-e1374302277479" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479-150x150.jpg" width="150" height="150" /></a></p><h4>Fix Root Intrusions</h4><p>We’ll get to the root of the problem! Old clay pipes can be damaged and leak because of inferior materials used in older construction.</p>[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 22:08:29', '2014-02-13 22:08:29', '', 41, 'http://localhost:8080/fixitall//?p=108', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (109, 1, '2014-02-13 22:09:03', '2014-02-13 22:09:03', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>
<h4>Unclog Your Drain</h4>
We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479.jpg"><img class="size-thumbnail wp-image-107 alignleft" alt="Root-Intrusion-by-Wilf-Ratzburg-e1374302277479" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479-150x150.jpg" width="150" height="150" /></a>
<h4>Fix Root Intrusions</h4>
We’ll get to the root of the problem! Old clay pipes can be damaged and leak because of inferior materials used in older construction.

[/et_pb_text][et_pb_divider admin_label="Divider" color="#ffffff" show_divider="off" /][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 22:09:03', '2014-02-13 22:09:03', '', 41, 'http://localhost:8080/fixitall//?p=109', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (110, 1, '2014-02-13 22:09:35', '2014-02-13 22:09:35', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>
<h4>Unclog Your Drain</h4>
We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.

[/et_pb_text][et_pb_divider admin_label="Divider" color="#ffffff" show_divider="off" /][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479.jpg"><img class="size-thumbnail wp-image-107 alignleft" alt="Root-Intrusion-by-Wilf-Ratzburg-e1374302277479" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479-150x150.jpg" width="150" height="150" /></a>
<h4>Fix Root Intrusions</h4>
We’ll get to the root of the problem! Old clay pipes can be damaged and leak because of inferior materials used in older construction.

[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="4_4"][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 22:09:35', '2014-02-13 22:09:35', '', 41, 'http://localhost:8080/fixitall//?p=110', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (111, 1, '2014-02-13 22:10:27', '2014-02-13 22:10:27', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>
<h4>Unclog Your Drain</h4>
We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479.jpg"><img class="size-thumbnail wp-image-107 alignleft" alt="Root-Intrusion-by-Wilf-Ratzburg-e1374302277479" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479-150x150.jpg" width="150" height="150" /></a>
<h4>Fix Root Intrusions</h4>
We’ll get to the root of the problem! Old clay pipes can be damaged and leak because of inferior materials used in older construction.

[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="4_4"][et_pb_divider admin_label="Divider" color="#ffffff" show_divider="off" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 22:10:27', '2014-02-13 22:10:27', '', 41, 'http://localhost:8080/fixitall//?p=111', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (112, 1, '2014-02-13 22:11:11', '2014-02-13 22:11:11', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>
<h4>Unclog Your Drain</h4>
We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.

<hr />

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479.jpg"><img class="size-thumbnail wp-image-107 alignleft" alt="Root-Intrusion-by-Wilf-Ratzburg-e1374302277479" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479-150x150.jpg" width="150" height="150" /></a>
<h4>Fix Root Intrusions</h4>
We’ll get to the root of the problem! Old clay pipes can be damaged and leak because of inferior materials used in older construction.

[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="4_4"][et_pb_divider admin_label="Divider" color="#ffffff" show_divider="off" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 22:11:11', '2014-02-13 22:11:11', '', 41, 'http://localhost:8080/fixitall//?p=112', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (113, 1, '2014-02-13 22:12:06', '2014-02-13 22:12:06', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>
<h4>Unclog Your Drain</h4>
We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479.jpg"><img class="size-thumbnail wp-image-107 alignleft" alt="Root-Intrusion-by-Wilf-Ratzburg-e1374302277479" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479-150x150.jpg" width="150" height="150" /></a>
<h4>Fix Root Intrusions</h4>
We’ll get to the root of the problem! Old clay pipes can be damaged and leak because of inferior materials used in older construction.

[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="4_4"][et_pb_divider admin_label="Divider" color="#ffffff" show_divider="off" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 22:12:06', '2014-02-13 22:12:06', '', 41, 'http://localhost:8080/fixitall//?p=113', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (114, 1, '2014-02-13 22:18:59', '2014-02-13 22:18:59', '', 'Gas-leak-by-Crow-Girl-e1374331227435', '', 'inherit', 'open', 'open', '', 'gas-leak-by-crow-girl-e1374331227435', '', '', '2014-02-13 22:18:59', '2014-02-13 22:18:59', '', 41, 'http://localhost:8080/fixitall//wp-content/uploads/2014/02/Gas-leak-by-Crow-Girl-e1374331227435.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (115, 1, '2014-02-13 22:19:57', '2014-02-13 22:19:57', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>
<h4>Unclog Your Drain</h4>
We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479.jpg"><img class="size-thumbnail wp-image-107 alignleft" alt="Root-Intrusion-by-Wilf-Ratzburg-e1374302277479" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479-150x150.jpg" width="150" height="150" /></a>
<h4>Fix Root Intrusions</h4>
We’ll get to the root of the problem! Old clay pipes can be damaged and leak because of inferior materials used in older construction.

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]<p><a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Gas-leak-by-Crow-Girl-e1374331227435.jpg"><img class="alignnone size-thumbnail wp-image-114" alt="Gas-leak-by-Crow-Girl-e1374331227435" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Gas-leak-by-Crow-Girl-e1374331227435-150x150.jpg" width="150" height="150" /></a></p><h4>Detect Gas Leaks</h4><p>We can test your office/retail location for a gas leak, shut-off a gas leak and repair a gas leak.</p>[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 22:19:57', '2014-02-13 22:19:57', '', 41, 'http://localhost:8080/fixitall//?p=115', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (116, 1, '2014-02-13 22:20:26', '2014-02-13 22:20:26', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>
<h4>Unclog Your Drain</h4>
We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479.jpg"><img class="size-thumbnail wp-image-107 alignleft" alt="Root-Intrusion-by-Wilf-Ratzburg-e1374302277479" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479-150x150.jpg" width="150" height="150" /></a>
<h4>Fix Root Intrusions</h4>
We’ll get to the root of the problem! Old clay pipes can be damaged and leak because of inferior materials used in older construction.

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Gas-leak-by-Crow-Girl-e1374331227435.jpg"><img class="size-thumbnail wp-image-114 alignleft" alt="Gas-leak-by-Crow-Girl-e1374331227435" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Gas-leak-by-Crow-Girl-e1374331227435-150x150.jpg" width="150" height="150" /></a>
<h4>Detect Gas Leaks</h4>
We can test your office/retail location for a gas leak, shut-off a gas leak and repair a gas leak.

[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 22:20:26', '2014-02-13 22:20:26', '', 41, 'http://localhost:8080/fixitall//?p=116', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (117, 1, '2014-02-13 22:22:52', '2014-02-13 22:22:52', '', 'Reinstall-Pipes-by-Michaela-Kobyakov-V-Max-plumbing-e1374362282501', '', 'inherit', 'open', 'open', '', 'reinstall-pipes-by-michaela-kobyakov-v-max-plumbing-e1374362282501', '', '', '2014-02-13 22:22:52', '2014-02-13 22:22:52', '', 41, 'http://localhost:8080/fixitall//wp-content/uploads/2014/02/Reinstall-Pipes-by-Michaela-Kobyakov-V-Max-plumbing-e1374362282501.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (118, 1, '2014-02-13 22:23:51', '2014-02-13 22:23:51', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>
<h4>Unclog Your Drain</h4>
We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479.jpg"><img class="size-thumbnail wp-image-107 alignleft" alt="Root-Intrusion-by-Wilf-Ratzburg-e1374302277479" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479-150x150.jpg" width="150" height="150" /></a>
<h4>Fix Root Intrusions</h4>
We’ll get to the root of the problem! Old clay pipes can be damaged and leak because of inferior materials used in older construction.

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Gas-leak-by-Crow-Girl-e1374331227435.jpg"><img class="size-thumbnail wp-image-114 alignleft" alt="Gas-leak-by-Crow-Girl-e1374331227435" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Gas-leak-by-Crow-Girl-e1374331227435-150x150.jpg" width="150" height="150" /></a>
<h4>Detect Gas Leaks</h4>
We can test your office/retail location for a gas leak, shut-off a gas leak and repair a gas leak.

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Reinstall-Pipes-by-Michaela-Kobyakov-V-Max-plumbing-e1374362282501.jpg"><img class="size-thumbnail wp-image-117 alignleft" alt="Reinstall-Pipes-by-Michaela-Kobyakov-V-Max-plumbing-e1374362282501" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Reinstall-Pipes-by-Michaela-Kobyakov-V-Max-plumbing-e1374362282501-150x150.jpg" width="150" height="150" /></a>
<h4>Reinstall Pipes</h4>
We can reinstall pipes in your walls, including removing your old galvanized pipes and replacing them with modern, type “L”, copper pipes.

[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 22:23:51', '2014-02-13 22:23:51', '', 41, 'http://localhost:8080/fixitall//?p=118', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (119, 1, '2014-02-13 22:27:15', '2014-02-13 22:27:15', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>
<h4>Unclog Your Drain</h4>
We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479.jpg"><img class="size-thumbnail wp-image-107 alignleft" alt="Root-Intrusion-by-Wilf-Ratzburg-e1374302277479" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479-150x150.jpg" width="150" height="150" /></a>
<h4>Fix Root Intrusions</h4>
We’ll get to the root of the problem! Old clay pipes can be damaged and leak because of inferior materials used in older construction.

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Gas-leak-by-Crow-Girl-e1374331227435.jpg"><img class="size-thumbnail wp-image-114 alignleft" alt="Gas-leak-by-Crow-Girl-e1374331227435" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Gas-leak-by-Crow-Girl-e1374331227435-150x150.jpg" width="150" height="150" /></a>
<h4>Detect Gas Leaks</h4>
We can test your office/retail location for a gas leak, shut-off a gas leak and repair a gas leak.

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Reinstall-Pipes-by-Michaela-Kobyakov-V-Max-plumbing-e1374362282501.jpg"><img class="size-thumbnail wp-image-117 alignleft" alt="Reinstall-Pipes-by-Michaela-Kobyakov-V-Max-plumbing-e1374362282501" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Reinstall-Pipes-by-Michaela-Kobyakov-V-Max-plumbing-e1374362282501-150x150.jpg" width="150" height="150" /></a>
<h4>Reinstall Pipes</h4>
We can reinstall pipes in your walls, including removing your old galvanized pipes and replacing them with modern, type “L”, copper pipes.

[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial/Residential', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 22:27:15', '2014-02-13 22:27:15', '', 41, 'http://localhost:8080/fixitall//?p=119', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (120, 1, '2014-02-13 22:29:57', '2014-02-13 22:29:57', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At V-Max Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

<hr />



<hr />
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>
<h4>Unclog Your Drain</h4>
We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479.jpg"><img class="size-thumbnail wp-image-107 alignleft" alt="Root-Intrusion-by-Wilf-Ratzburg-e1374302277479" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479-150x150.jpg" width="150" height="150" /></a>
<h4>Fix Root Intrusions</h4>
We’ll get to the root of the problem! Old clay pipes can be damaged and leak because of inferior materials used in older construction.

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Gas-leak-by-Crow-Girl-e1374331227435.jpg"><img class="size-thumbnail wp-image-114 alignleft" alt="Gas-leak-by-Crow-Girl-e1374331227435" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Gas-leak-by-Crow-Girl-e1374331227435-150x150.jpg" width="150" height="150" /></a>
<h4>Detect Gas Leaks</h4>
We can test your office/retail location for a gas leak, shut-off a gas leak and repair a gas leak.

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Reinstall-Pipes-by-Michaela-Kobyakov-V-Max-plumbing-e1374362282501.jpg"><img class="size-thumbnail wp-image-117 alignleft" alt="Reinstall-Pipes-by-Michaela-Kobyakov-V-Max-plumbing-e1374362282501" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Reinstall-Pipes-by-Michaela-Kobyakov-V-Max-plumbing-e1374362282501-150x150.jpg" width="150" height="150" /></a>
<h4>Reinstall Pipes</h4>
We can reinstall pipes in your walls, including removing your old galvanized pipes and replacing them with modern, type “L”, copper pipes.

[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial/Residential', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-13 22:29:57', '2014-02-13 22:29:57', '', 41, 'http://localhost:8080/fixitall//?p=120', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (121, 1, '2014-02-13 22:34:28', '2014-02-13 22:34:28', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_text admin_label="Text" /][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'About', '', 'inherit', 'open', 'open', '', '71-autosave-v1', '', '', '2014-02-13 22:34:28', '2014-02-13 22:34:28', '', 71, 'http://localhost:8080/fixitall//?p=121', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (122, 1, '2014-02-13 22:36:17', '2014-02-13 22:36:17', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h2>The Most Reliable Plumber In Paramount &amp; Surrounding Areas In California.</h2>
Over the years, the quality, efficacy, affordability and longevity of the work done by V-Max Plumbing has made us the most trusted and favorite plumbers for homeowners as well as commercial property owners.

PluMax Plumbing specializes in all kinds of plumbing tasks. Whether you need a particular plumbing fixture repaired or you are looking for a complete overhaul of your plumbing systems, PluMax Plumbing is the best choice at your discretion. No job is too big and no task is too small for us at PluMax Plumbing.

[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'About', '', 'inherit', 'open', 'open', '', '71-revision-v1', '', '', '2014-02-13 22:36:17', '2014-02-13 22:36:17', '', 71, 'http://localhost:8080/fixitall//?p=122', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (123, 1, '2014-02-13 22:38:15', '2014-02-13 22:38:15', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h2><span style="text-decoration: underline;">The Most Reliable Plumber In Paramount &amp; Surrounding Areas In California.</span></h2>
[box] Over the years, the quality, efficacy, affordability and longevity of the work done by V-Max Plumbing has made us the most trusted and favorite plumbers for homeowners as well as commercial property owners. PluMax Plumbing specializes in all kinds of plumbing tasks. Whether you need a particular plumbing fixture repaired or you are looking for a complete overhaul of your plumbing systems, PluMax Plumbing is the best choice at your discretion. No job is too big and no task is too small for us at PluMax Plumbing.[/box]

&nbsp;

[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'About', '', 'inherit', 'open', 'open', '', '71-revision-v1', '', '', '2014-02-13 22:38:15', '2014-02-13 22:38:15', '', 71, 'http://localhost:8080/fixitall//?p=123', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (124, 1, '2014-02-13 22:39:33', '2014-02-13 22:39:33', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h2>The Most Reliable Plumber In Southern California</h2>
[box] Over the years, the quality, efficacy, affordability and longevity of the work done by V-Max Plumbing has made us the most trusted and favorite plumbers for homeowners as well as commercial property owners. PluMax Plumbing specializes in all kinds of plumbing tasks. Whether you need a particular plumbing fixture repaired or you are looking for a complete overhaul of your plumbing systems, PluMax Plumbing is the best choice at your discretion. No job is too big and no task is too small for us at PluMax Plumbing.[/box]

[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'About', '', 'inherit', 'open', 'open', '', '71-revision-v1', '', '', '2014-02-13 22:39:33', '2014-02-13 22:39:33', '', 71, 'http://localhost:8080/fixitall//?p=124', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (125, 1, '2014-02-13 22:40:42', '2014-02-13 22:40:42', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h2>The Most Reliable Plumber In Southern California</h2>
[box]

Over the years, the quality, efficacy, affordability and longevity of the work done by V-Max Plumbing has made us the most trusted and favorite plumbers for homeowners as well as commercial property owners. PluMax Plumbing specializes in all kinds of plumbing tasks.

Whether you need a particular plumbing fixture repaired or you are looking for a complete overhaul of your plumbing systems, PluMax Plumbing is the best choice at your discretion. No job is too big and no task is too small for us at PluMax Plumbing.

[/box]

[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'About', '', 'inherit', 'open', 'open', '', '71-revision-v1', '', '', '2014-02-13 22:40:42', '2014-02-13 22:40:42', '', 71, 'http://localhost:8080/fixitall//?p=125', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (126, 1, '2014-02-13 22:42:40', '2014-02-13 22:42:40', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h2>The Most Reliable Plumber In Southern California</h2>
[box]

Over the years, the quality, efficacy, affordability and longevity of the work done by V-Max Plumbing has made us the most trusted and favorite plumbers for homeowners as well as commercial property owners. PluMax Plumbing specializes in all kinds of plumbing tasks.

Whether you need a particular plumbing fixture repaired or you are looking for a complete overhaul of your plumbing systems, PluMax Plumbing is the best choice at your discretion. No job is too big and no task is too small for us at PluMax Plumbing.

[/box]

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h2>Experienced Combined With Unparalleled Service</h2>
[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'About', '', 'inherit', 'open', 'open', '', '71-revision-v1', '', '', '2014-02-13 22:42:40', '2014-02-13 22:42:40', '', 71, 'http://localhost:8080/fixitall//?p=126', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (127, 1, '2014-02-13 22:44:57', '2014-02-13 22:44:57', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h2>The Most Reliable Plumber In Southern California</h2>
[box]

Over the years, the quality, efficacy, affordability and longevity of the work done by V-Max Plumbing has made us the most trusted and favorite plumbers for homeowners as well as commercial property owners. PluMax Plumbing specializes in all kinds of plumbing tasks.

Whether you need a particular plumbing fixture repaired or you are looking for a complete overhaul of your plumbing systems, PluMax Plumbing is the best choice at your discretion. No job is too big and no task is too small for us at PluMax Plumbing.

[/box]

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h2>Experienced Combined With Unparalleled Service</h2>
[box] PluMax Plumbing has always put customers first. While dealing with us, right from the first phone call or email to the invoicing and post service interactions or consultations, you would experience unparallel service.[/box]

[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'About', '', 'inherit', 'open', 'open', '', '71-revision-v1', '', '', '2014-02-13 22:44:57', '2014-02-13 22:44:57', '', 71, 'http://localhost:8080/fixitall//?p=127', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (128, 1, '2014-02-13 22:47:50', '2014-02-13 22:47:50', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h2>The Most Reliable Plumber In Southern California</h2>
[box]

Over the years, the quality, efficacy, affordability and longevity of the work done by V-Max Plumbing has made us the most trusted and favorite plumbers for homeowners as well as commercial property owners. PluMax Plumbing specializes in all kinds of plumbing tasks.

Whether you need a particular plumbing fixture repaired or you are looking for a complete overhaul of your plumbing systems, PluMax Plumbing is the best choice at your discretion. No job is too big and no task is too small for us at PluMax Plumbing.

[/box]

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h2>Experienced Combined With Unparalleled Service</h2>
[box] PluMax Plumbing has always put customers first. While dealing with us, right from the first phone call or email to the invoicing and post service interactions or consultations, you would experience unparallel service.
<ul>
	<li>PluMax Plumbing offers prompt and dependable service. Our teams would be at your site at the time that is promised and would get the job done as promised.</li>
	<li>You have the luxury to opt for a schedule that is convenient for you. You can take into account all the factors that are important to you and then choose a certain schedule when the team from PluMax Plumbing can get the job done and we would do exactly according to that.</li>
	<li>PluMax Plumbing has the distinction of offering extremely reasonable rates, even for the most complex plumbing installations, repairs and maintenance.</li>
</ul>
Call us today at (310) 555-1212 and let us handle all of your plumbing needs with unmatchable expertise and impeccable service at extremely reasonable rates.

[/box]

[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'About', '', 'inherit', 'open', 'open', '', '71-revision-v1', '', '', '2014-02-13 22:47:50', '2014-02-13 22:47:50', '', 71, 'http://localhost:8080/fixitall//?p=128', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (129, 1, '2014-02-13 22:50:18', '2014-02-13 22:50:18', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Study to test home plumbing for MCHM', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-02-13 22:50:18', '2014-02-13 22:50:18', '', 1, 'http://localhost:8080/fixitall//?p=129', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (130, 1, '2014-02-13 22:50:58', '2014-02-13 22:50:58', '<p>CHARLESTON, W.Va. -- West Virginia will fund an independent team of experts to test water in homes to try to determine long-term effects of the Elk River chemical spill, Gov. Earl Ray Tomblin announced Tuesday.</p>

<p>Over the next three weeks, the team will test water in the home plumbing systems of 10 private homes: one in each of the nine affected counties, plus an extra home in Kanawha County.</p>', 'Study to test home plumbing for MCHM', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-02-13 22:50:58', '2014-02-13 22:50:58', '', 1, 'http://localhost:8080/fixitall//?p=130', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (131, 1, '2014-02-13 22:52:17', '2014-02-13 22:52:17', 'CHARLESTON, W.Va. -- West Virginia will fund an independent team of experts to test water in homes to try to determine long-term effects of the Elk River chemical spill, Gov. Earl Ray Tomblin announced Tuesday.

Over the next three weeks, the team will test water in the home plumbing systems of 10 private homes: one in each of the nine affected counties, plus an extra home in Kanawha County.<!--more-->', 'Study to test home plumbing for MCHM', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-02-13 22:52:17', '2014-02-13 22:52:17', '', 1, 'http://localhost:8080/fixitall//?p=131', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (132, 1, '2014-02-13 22:52:55', '2014-02-13 22:52:55', 'CHARLESTON, W.Va. -- West Virginia will fund an independent team of experts to test water in homes to try to determine long-term effects of the Elk River chemical spill, Gov. Earl Ray Tomblin announced Tuesday.

Over the next three weeks, the team will test water in the home plumbing systems of 10 private homes: one in each of the nine affected counties, plus an extra home in Kanawha County.<!--more-->

The study -- called the West Virginia Testing Assessment Project, or WVTAP -- will have three main objectives. The team will convene a group of independent experts to evaluate the West Virginia\'s testing threshold of 10 parts per billion of Crude MCHM in water -- its usefulness as well as its limitations.

Second, a team of four scientists, let by Andrew Whelton, an environmental scientist from the University of South Alabama, will test water in homes to try to determine how Crude MCHM, and the other spilled chemical, PPH, interact with, and potentially stick to, different types of pipes.

Finally, the study also wants to find out the odor threshold of Crude MCHM -- how little of the chemical can be in the water in order for people to be able to smell it.

"The scale of chemical contamination of the drinking water in Charleston, W.Va., has been unprecedented," Whelton said at a Tuesday-evening news conference with Tomblin. "There is so little data available, many federal and state agencies could not and still cannot answer all the questions West Virginians are demanding to be answered."

Jeffrey Rosen, of Corona Environmental Consulting, will help Whelton conduct the study.

The 10 homes already have been selected. They are homes of people Whelton has been in touch with since he first arrived in West Virginia to do water crisis-related research three weeks ago.

Whelton\'s team will go into the homes accompanied by staff from local volunteer fire departments. They will sample hot and cold water -- about 21 gallons -- from the kitchen and the most commonly used bathroom. They will examine the plumbing, as different homes may have copper, iron, PVC or other plastic pipes.

Testing will be done at independent labs, and Whelton\'s team will not report to any state agency.

Once the initial round of 10 home tests is complete, the team will release preliminary results. They will then do more than 100 tests in additional homes around the region, Whelton said.

Tomblin has committed $650,000 from the state budget to fund the study, but he admitted Tuesday that that probably would not be nearly enough money. He said he has asked West Virginia\'s congressional delegation for help in securing federal money to further fund the study.

Asked how much federal money he thought would be needed, Tomblin said, "A lot."

"To be frank, this is an unprecedented disaster," Whelton said, adding that "$650,000 is a lot of money, but long-term monitoring is needed."

He said that with the help of the National Science Foundation and the National Institutes of Health, researchers need to begin more toxicological studies and animal studies as soon as possible.

Tomblin said West Virginia American Water President Jeff McIntyre told him at their last meeting that the company would offer money for home testing if the state needed it. The governor said they have not yet requested any financial assistance.', 'Study to test home plumbing for MCHM', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-02-13 22:52:55', '2014-02-13 22:52:55', '', 1, 'http://localhost:8080/fixitall//?p=132', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (133, 1, '2014-02-13 23:01:09', '2014-02-13 23:01:09', 'Murray Supply is coming off of a record sales year in 2013 with an extremely bright outlook for the future. Their mission is as follows; "Murray Supply Company is a progressive, industry-leading organization with deep-seeded family business roots, yet incorporates world class business practices. Our professional associates are provided best-in-class training and tools to provide solutions that exceed the expectations of our customers. Our commitment is to our associates, our customers, our vendors, our industry and our environment. They can efficiently and economically handle the material needs of our customers." While other companies were cutting back and closing locations, they have been on a steady rate of expansion since 2008. They began an entirely new business in the MRO sector and now have 25 new employees and two new locations with more on the way. They developed a Hot Water division and have become the first choice for many of their customers hot water needs. Their Industrial division has grown steadily with the addition of 4 new people.

They have been recruiting graduates into their Sales and Management Training Program from Appalachian State and East Carolina Universities and many of those recruits have earned their way into sales and management positions. They continued to support all of the industry organizations with both financial and time support. The good people at Murray Supply have been here for you! Is it time you took a look at where you are and who you want your company to be associated with? Do you want to be associated with a financially strong, local company, with a strong family background? Does that sound like your own company? Ask yourself, "Am I doing business with companies that share my values"? If not now might be the time to make some changes. Is it time to move your business to a company you can still build a personal relationship with and support a company who will still be here when your children take over? The good people at Murray Supply think it is. Is your career headed in the direction you want it to go? Is your company growing and providing opportunities for your future? Are you one of those people who has always dreamed of starting your own business? Have you always felt there were opportunities in the market no one was capturing? Do you have a business idea and feel like no one is listening? Are you looking to join one of the best companies in the Carolinas? The good people at Murray Supply invite you to reach out to them. In 2015 Murray Supply will celebrate its 50th anniversary.

Murray Supply encourages you to call and explore the many opportunities. They are still one of the local companies where you can call and speak to the owners and on a good day you might even find one of the founders of the company hanging around the office. Can you experience that where you are? Go ahead and give them a call at Murray Supply. They have the resources to make your dreams come true! Murray Supply Company is engaged in the distribution of residential and commercial plumbing supplies, PVF, HVAC, power and process piping along with maintenance, repair and operations products. To learn more about us, visit www.murraysupply.com.', 'Murray Supply Company Looks Ahead to 2014', '', 'publish', 'open', 'open', '', 'murray-supply-company-looks-ahead-to-2014', '', '', '2014-04-29 18:01:19', '2014-04-29 18:01:19', '', 0, 'http://localhost:8080/fixitall//?p=133', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (134, 1, '2014-02-13 23:01:09', '2014-02-13 23:01:09', 'Murray Supply is coming off of a record sales year in 2013 with an extremely bright outlook for the future. Their mission is as follows; "Murray Supply Company is a progressive, industry-leading organization with deep-seeded family business roots, yet incorporates world class business practices. Our professional associates are provided best-in-class training and tools to provide solutions that exceed the expectations of our customers. Our commitment is to our associates, our customers, our vendors, our industry and our environment. They can efficiently and economically handle the material needs of our customers." While other companies were cutting back and closing locations, they have been on a steady rate of expansion since 2008. They began an entirely new business in the MRO sector and now have 25 new employees and two new locations with more on the way. They developed a Hot Water division and have become the first choice for many of their customers hot water needs. Their Industrial division has grown steadily with the addition of 4 new people.', 'Murray Supply Company Looks Ahead to 2014', '', 'inherit', 'open', 'open', '', '133-revision-v1', '', '', '2014-02-13 23:01:09', '2014-02-13 23:01:09', '', 133, 'http://localhost:8080/fixitall//?p=134', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (135, 1, '2014-02-13 23:01:53', '2014-02-13 23:01:53', 'Murray Supply is coming off of a record sales year in 2013 with an extremely bright outlook for the future. Their mission is as follows; "Murray Supply Company is a progressive, industry-leading organization with deep-seeded family business roots, yet incorporates world class business practices. Our professional associates are provided best-in-class training and tools to provide solutions that exceed the expectations of our customers. Our commitment is to our associates, our customers, our vendors, our industry and our environment. They can efficiently and economically handle the material needs of our customers." While other companies were cutting back and closing locations, they have been on a steady rate of expansion since 2008. They began an entirely new business in the MRO sector and now have 25 new employees and two new locations with more on the way. They developed a Hot Water division and have become the first choice for many of their customers hot water needs. Their Industrial division has grown steadily with the addition of 4 new people.

They have been recruiting graduates into their Sales and Management Training Program from Appalachian State and East Carolina Universities and many of those recruits have earned their way into sales and management positions. They continued to support all of the industry organizations with both financial and time support. The good people at Murray Supply have been here for you! Is it time you took a look at where you are and who you want your company to be associated with? Do you want to be associated with a financially strong, local company, with a strong family background? Does that sound like your own company? Ask yourself, "Am I doing business with companies that share my values"? If not now might be the time to make some changes. Is it time to move your business to a company you can still build a personal relationship with and support a company who will still be here when your children take over? The good people at Murray Supply think it is. Is your career headed in the direction you want it to go? Is your company growing and providing opportunities for your future? Are you one of those people who has always dreamed of starting your own business? Have you always felt there were opportunities in the market no one was capturing? Do you have a business idea and feel like no one is listening? Are you looking to join one of the best companies in the Carolinas? The good people at Murray Supply invite you to reach out to them. In 2015 Murray Supply will celebrate its 50th anniversary.

Murray Supply encourages you to call and explore the many opportunities. They are still one of the local companies where you can call and speak to the owners and on a good day you might even find one of the founders of the company hanging around the office. Can you experience that where you are? Go ahead and give them a call at Murray Supply. They have the resources to make your dreams come true! Murray Supply Company is engaged in the distribution of residential and commercial plumbing supplies, PVF, HVAC, power and process piping along with maintenance, repair and operations products. To learn more about us, visit www.murraysupply.com.', 'Murray Supply Company Looks Ahead to 2014', '', 'inherit', 'open', 'open', '', '133-revision-v1', '', '', '2014-02-13 23:01:53', '2014-02-13 23:01:53', '', 133, 'http://localhost:8080/fixitall//?p=135', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (136, 1, '2014-02-13 23:02:06', '2014-02-13 23:02:06', 'Murray Supply is coming off of a record sales year in 2013 with an extremely bright outlook for the future. Their mission is as follows; "Murray Supply Company is a progressive, industry-leading organization with deep-seeded family business roots, yet incorporates world class business practices. Our professional associates are provided best-in-class training and tools to provide solutions that exceed the expectations of our customers. Our commitment is to our associates, our customers, our vendors, our industry and our environment. They can efficiently and economically handle the material needs of our customers." While other companies were cutting back and closing locations, they have been on a steady rate of expansion since 2008. They began an entirely new business in the MRO sector and now have 25 new employees and two new locations with more on the way. They developed a Hot Water division and have become the first choice for many of their customers hot water needs. Their Industrial division has grown steadily with the addition of 4 new people.<!--more-->

They have been recruiting graduates into their Sales and Management Training Program from Appalachian State and East Carolina Universities and many of those recruits have earned their way into sales and management positions. They continued to support all of the industry organizations with both financial and time support. The good people at Murray Supply have been here for you! Is it time you took a look at where you are and who you want your company to be associated with? Do you want to be associated with a financially strong, local company, with a strong family background? Does that sound like your own company? Ask yourself, "Am I doing business with companies that share my values"? If not now might be the time to make some changes. Is it time to move your business to a company you can still build a personal relationship with and support a company who will still be here when your children take over? The good people at Murray Supply think it is. Is your career headed in the direction you want it to go? Is your company growing and providing opportunities for your future? Are you one of those people who has always dreamed of starting your own business? Have you always felt there were opportunities in the market no one was capturing? Do you have a business idea and feel like no one is listening? Are you looking to join one of the best companies in the Carolinas? The good people at Murray Supply invite you to reach out to them. In 2015 Murray Supply will celebrate its 50th anniversary.

Murray Supply encourages you to call and explore the many opportunities. They are still one of the local companies where you can call and speak to the owners and on a good day you might even find one of the founders of the company hanging around the office. Can you experience that where you are? Go ahead and give them a call at Murray Supply. They have the resources to make your dreams come true! Murray Supply Company is engaged in the distribution of residential and commercial plumbing supplies, PVF, HVAC, power and process piping along with maintenance, repair and operations products. To learn more about us, visit www.murraysupply.com.', 'Murray Supply Company Looks Ahead to 2014', '', 'inherit', 'open', 'open', '', '133-revision-v1', '', '', '2014-02-13 23:02:06', '2014-02-13 23:02:06', '', 133, 'http://localhost:8080/fixitall//?p=136', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (137, 1, '2014-02-13 23:02:41', '2014-02-13 23:02:41', 'Murray Supply is coming off of a record sales year in 2013 with an extremely bright outlook for the future. Their mission is as follows; "Murray Supply Company is a progressive, industry-leading organization with deep-seeded family business roots, yet incorporates world class business practices. Our professional associates are provided best-in-class training and tools to provide solutions that exceed the expectations of our customers. Our commitment is to our associates, our customers, our vendors, our industry and our environment. They can efficiently and economically handle the material needs of our customers." While other companies were cutting back and closing locations, they have been on a steady rate of expansion since 2008. They began an entirely new business in the MRO sector and now have 25 new employees and two new locations with more on the way. They developed a Hot Water division and have become the first choice for many of their customers hot water needs. Their Industrial division has grown steadily with the addition of 4 new people.

They have been recruiting graduates into their Sales and Management Training Program from Appalachian State and East Carolina Universities and many of those recruits have earned their way into sales and management positions. They continued to support all of the industry organizations with both financial and time support. The good people at Murray Supply have been here for you! Is it time you took a look at where you are and who you want your company to be associated with? Do you want to be associated with a financially strong, local company, with a strong family background? Does that sound like your own company? Ask yourself, "Am I doing business with companies that share my values"? If not now might be the time to make some changes. Is it time to move your business to a company you can still build a personal relationship with and support a company who will still be here when your children take over? The good people at Murray Supply think it is. Is your career headed in the direction you want it to go? Is your company growing and providing opportunities for your future? Are you one of those people who has always dreamed of starting your own business? Have you always felt there were opportunities in the market no one was capturing? Do you have a business idea and feel like no one is listening? Are you looking to join one of the best companies in the Carolinas? The good people at Murray Supply invite you to reach out to them. In 2015 Murray Supply will celebrate its 50th anniversary.

Murray Supply encourages you to call and explore the many opportunities. They are still one of the local companies where you can call and speak to the owners and on a good day you might even find one of the founders of the company hanging around the office. Can you experience that where you are? Go ahead and give them a call at Murray Supply. They have the resources to make your dreams come true! Murray Supply Company is engaged in the distribution of residential and commercial plumbing supplies, PVF, HVAC, power and process piping along with maintenance, repair and operations products. To learn more about us, visit www.murraysupply.com.', 'Murray Supply Company Looks Ahead to 2014', '', 'inherit', 'open', 'open', '', '133-revision-v1', '', '', '2014-02-13 23:02:41', '2014-02-13 23:02:41', '', 133, 'http://localhost:8080/fixitall//?p=137', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (138, 1, '2014-02-13 23:02:55', '2014-02-13 23:02:55', 'CHARLESTON, W.Va. -- West Virginia will fund an independent team of experts to test water in homes to try to determine long-term effects of the Elk River chemical spill, Gov. Earl Ray Tomblin announced Tuesday.

Over the next three weeks, the team will test water in the home plumbing systems of 10 private homes: one in each of the nine affected counties, plus an extra home in Kanawha County.

The study -- called the West Virginia Testing Assessment Project, or WVTAP -- will have three main objectives. The team will convene a group of independent experts to evaluate the West Virginia\'s testing threshold of 10 parts per billion of Crude MCHM in water -- its usefulness as well as its limitations.

Second, a team of four scientists, let by Andrew Whelton, an environmental scientist from the University of South Alabama, will test water in homes to try to determine how Crude MCHM, and the other spilled chemical, PPH, interact with, and potentially stick to, different types of pipes.

Finally, the study also wants to find out the odor threshold of Crude MCHM -- how little of the chemical can be in the water in order for people to be able to smell it.

"The scale of chemical contamination of the drinking water in Charleston, W.Va., has been unprecedented," Whelton said at a Tuesday-evening news conference with Tomblin. "There is so little data available, many federal and state agencies could not and still cannot answer all the questions West Virginians are demanding to be answered."

Jeffrey Rosen, of Corona Environmental Consulting, will help Whelton conduct the study.

The 10 homes already have been selected. They are homes of people Whelton has been in touch with since he first arrived in West Virginia to do water crisis-related research three weeks ago.

Whelton\'s team will go into the homes accompanied by staff from local volunteer fire departments. They will sample hot and cold water -- about 21 gallons -- from the kitchen and the most commonly used bathroom. They will examine the plumbing, as different homes may have copper, iron, PVC or other plastic pipes.

Testing will be done at independent labs, and Whelton\'s team will not report to any state agency.

Once the initial round of 10 home tests is complete, the team will release preliminary results. They will then do more than 100 tests in additional homes around the region, Whelton said.

Tomblin has committed $650,000 from the state budget to fund the study, but he admitted Tuesday that that probably would not be nearly enough money. He said he has asked West Virginia\'s congressional delegation for help in securing federal money to further fund the study.

Asked how much federal money he thought would be needed, Tomblin said, "A lot."

"To be frank, this is an unprecedented disaster," Whelton said, adding that "$650,000 is a lot of money, but long-term monitoring is needed."

He said that with the help of the National Science Foundation and the National Institutes of Health, researchers need to begin more toxicological studies and animal studies as soon as possible.

Tomblin said West Virginia American Water President Jeff McIntyre told him at their last meeting that the company would offer money for home testing if the state needed it. The governor said they have not yet requested any financial assistance.', 'Study to test home plumbing for MCHM', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-02-13 23:02:55', '2014-02-13 23:02:55', '', 1, 'http://localhost:8080/fixitall//?p=138', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (139, 1, '2014-02-13 23:15:56', '2014-02-13 23:15:56', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][et_pb_blurb admin_label="Blurb" title="Locally Owned and Operated" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing is locally owned, based and operated. The founders of the company, the staffs and everyone associated with the organization are from the city and surrounding areas of Paramount in California. While there is no standard rule that says locally owned companies are better than those having a nationwide presence or than the franchisees that are often catering to distant areas where they do not have a base, but the reality is that knowledge and awareness helps. When plumbers cater to areas that they are personal extremely familiar with, they are more aware of the challenges that a home, office or commercial property faces. For instance, if you are planning to install a new plumbing system, a local plumbing company would be helpful as they wouldn’t have to find out the building regulations. They would already know. At PluMax Plumbing, we already know the kinds of problems that residents, business owners and property managers face in Paramount and surrounding areas in California. Seldom do we need a briefing from our clients because of the knowledge and albeit due to our expertise.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="24/7 Emergency Plumbing" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Satisfaction Guarenteed" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has a unique offering where you are not only happy with the quality of work done but you would also be extremely satisfied with the entire experience. Right from the initial consultation through the schedule to the post service relation that we cherish with our clients, you would be completely satiated with every facet of our service and that is a guarantee.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Quality at an Affordable Price" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

Quality doesn’t come cheap and what comes cheap cannot be of great quality – such is the reality in many cases. With PluMax Plumbing, you experience an exception. We are one of the very few plumbing companies in the state that offers quality work at inexpensive rates.

[/et_pb_blurb][et_pb_divider admin_label="Divider" color="#ffffff" show_divider="on" /][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="David Bodner" url_new_window="off"]

I wholeheartedly recommend PluMax Plumbing for your residential plumbing needs. I have used their services on two occasions now. They are prompt, perform excellent work and charge fair prices. They clean up after their work and leave your house in excellent condition. Will use their services again.

[/et_pb_testimonial][/et_pb_column][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="Michael Bilnik" url_new_window="off"]

We have called Plumax Plumbing on two separation occasions. The first was a flooded basement. Josh gave us a competitive quote and installed a sump pump that works great. It was great to find a reliable, honest plumber who wouldn\'t take advantage of your dire situation. PluMax Plumbing also installed our hot water tank. And they did it quick and with respect for our property - leaving no mess behind. In both cases, we received professional installation. And more importantly, both projects stayed within the estimate, and our budget. If you\'re looking for a plumber you can trust, and afford, I highly recommend PluMax Plumbing!

[/et_pb_testimonial][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 23:15:56', '2014-02-13 23:15:56', '', 50, 'http://localhost:8080/fixitall/?p=139', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (140, 1, '2014-02-13 23:16:59', '2014-02-13 23:16:59', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="Locally Owned and Operated" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing is locally owned, based and operated. The founders of the company, the staffs and everyone associated with the organization are from the city and surrounding areas of Paramount in California. While there is no standard rule that says locally owned companies are better than those having a nationwide presence or than the franchisees that are often catering to distant areas where they do not have a base, but the reality is that knowledge and awareness helps. When plumbers cater to areas that they are personal extremely familiar with, they are more aware of the challenges that a home, office or commercial property faces. For instance, if you are planning to install a new plumbing system, a local plumbing company would be helpful as they wouldn’t have to find out the building regulations. They would already know. At PluMax Plumbing, we already know the kinds of problems that residents, business owners and property managers face in Paramount and surrounding areas in California. Seldom do we need a briefing from our clients because of the knowledge and albeit due to our expertise.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="24/7 Emergency Plumbing" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Satisfaction Guarenteed" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has a unique offering where you are not only happy with the quality of work done but you would also be extremely satisfied with the entire experience. Right from the initial consultation through the schedule to the post service relation that we cherish with our clients, you would be completely satiated with every facet of our service and that is a guarantee.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Quality at an Affordable Price" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

Quality doesn’t come cheap and what comes cheap cannot be of great quality – such is the reality in many cases. With PluMax Plumbing, you experience an exception. We are one of the very few plumbing companies in the state that offers quality work at inexpensive rates.

[/et_pb_blurb][et_pb_divider admin_label="Divider" color="#ffffff" show_divider="on" /][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="David Bodner" url_new_window="off"]

I wholeheartedly recommend PluMax Plumbing for your residential plumbing needs. I have used their services on two occasions now. They are prompt, perform excellent work and charge fair prices. They clean up after their work and leave your house in excellent condition. Will use their services again.

[/et_pb_testimonial][/et_pb_column][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="Michael Bilnik" url_new_window="off"]

We have called Plumax Plumbing on two separation occasions. The first was a flooded basement. Josh gave us a competitive quote and installed a sump pump that works great. It was great to find a reliable, honest plumber who wouldn\'t take advantage of your dire situation. PluMax Plumbing also installed our hot water tank. And they did it quick and with respect for our property - leaving no mess behind. In both cases, we received professional installation. And more importantly, both projects stayed within the estimate, and our budget. If you\'re looking for a plumber you can trust, and afford, I highly recommend PluMax Plumbing!

[/et_pb_testimonial][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="4_4"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 23:16:59', '2014-02-13 23:16:59', '', 50, 'http://localhost:8080/fixitall/?p=140', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (141, 1, '2014-02-13 23:18:08', '2014-02-13 23:18:08', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="Locally Owned and Operated" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing is locally owned, based and operated. The founders of the company, the staffs and everyone associated with the organization are from the city and surrounding areas of Paramount in California. While there is no standard rule that says locally owned companies are better than those having a nationwide presence or than the franchisees that are often catering to distant areas where they do not have a base, but the reality is that knowledge and awareness helps. When plumbers cater to areas that they are personal extremely familiar with, they are more aware of the challenges that a home, office or commercial property faces. For instance, if you are planning to install a new plumbing system, a local plumbing company would be helpful as they wouldn’t have to find out the building regulations. They would already know. At PluMax Plumbing, we already know the kinds of problems that residents, business owners and property managers face in Paramount and surrounding areas in California. Seldom do we need a briefing from our clients because of the knowledge and albeit due to our expertise.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="24/7 Emergency Plumbing" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Satisfaction Guarenteed" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has a unique offering where you are not only happy with the quality of work done but you would also be extremely satisfied with the entire experience. Right from the initial consultation through the schedule to the post service relation that we cherish with our clients, you would be completely satiated with every facet of our service and that is a guarantee.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Quality at an Affordable Price" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

Quality doesn’t come cheap and what comes cheap cannot be of great quality – such is the reality in many cases. With PluMax Plumbing, you experience an exception. We are one of the very few plumbing companies in the state that offers quality work at inexpensive rates.

[/et_pb_blurb][et_pb_divider admin_label="Divider" color="#ffffff" show_divider="on" /][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="David Bodner" url_new_window="off"]

I wholeheartedly recommend PluMax Plumbing for your residential plumbing needs. I have used their services on two occasions now. They are prompt, perform excellent work and charge fair prices. They clean up after their work and leave your house in excellent condition. Will use their services again.

[/et_pb_testimonial][/et_pb_column][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="Michael Bilnik" url_new_window="off"]

We have called Plumax Plumbing on two separation occasions. The first was a flooded basement. Josh gave us a competitive quote and installed a sump pump that works great. It was great to find a reliable, honest plumber who wouldn\'t take advantage of your dire situation. PluMax Plumbing also installed our hot water tank. And they did it quick and with respect for our property - leaving no mess behind. In both cases, we received professional installation. And more importantly, both projects stayed within the estimate, and our budget. If you\'re looking for a plumber you can trust, and afford, I highly recommend PluMax Plumbing!

[/et_pb_testimonial][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="4_4"][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 23:18:08', '2014-02-13 23:18:08', '', 50, 'http://localhost:8080/fixitall/?p=141', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (142, 1, '2014-02-13 23:18:59', '2014-02-13 23:18:59', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="Locally Owned and Operated" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing is locally owned, based and operated. The founders of the company, the staffs and everyone associated with the organization are from the city and surrounding areas of Paramount in California. While there is no standard rule that says locally owned companies are better than those having a nationwide presence or than the franchisees that are often catering to distant areas where they do not have a base, but the reality is that knowledge and awareness helps. When plumbers cater to areas that they are personal extremely familiar with, they are more aware of the challenges that a home, office or commercial property faces. For instance, if you are planning to install a new plumbing system, a local plumbing company would be helpful as they wouldn’t have to find out the building regulations. They would already know. At PluMax Plumbing, we already know the kinds of problems that residents, business owners and property managers face in Paramount and surrounding areas in California. Seldom do we need a briefing from our clients because of the knowledge and albeit due to our expertise.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="24/7 Emergency Plumbing" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Satisfaction Guarenteed" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has a unique offering where you are not only happy with the quality of work done but you would also be extremely satisfied with the entire experience. Right from the initial consultation through the schedule to the post service relation that we cherish with our clients, you would be completely satiated with every facet of our service and that is a guarantee.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Quality at an Affordable Price" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

Quality doesn’t come cheap and what comes cheap cannot be of great quality – such is the reality in many cases. With PluMax Plumbing, you experience an exception. We are one of the very few plumbing companies in the state that offers quality work at inexpensive rates.

[/et_pb_blurb][et_pb_divider admin_label="Divider" color="#ffffff" show_divider="on" /][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="David Bodner" url_new_window="off"]

I wholeheartedly recommend PluMax Plumbing for your residential plumbing needs. I have used their services on two occasions now. They are prompt, perform excellent work and charge fair prices. They clean up after their work and leave your house in excellent condition. Will use their services again.

[/et_pb_testimonial][/et_pb_column][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="Michael Bilnik" url_new_window="off"]

We have called Plumax Plumbing on two separation occasions. The first was a flooded basement. Josh gave us a competitive quote and installed a sump pump that works great. It was great to find a reliable, honest plumber who wouldn\'t take advantage of your dire situation. PluMax Plumbing also installed our hot water tank. And they did it quick and with respect for our property - leaving no mess behind. In both cases, we received professional installation. And more importantly, both projects stayed within the estimate, and our budget. If you\'re looking for a plumber you can trust, and afford, I highly recommend PluMax Plumbing!

[/et_pb_testimonial][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][/et_pb_column][et_pb_column type="1_3"][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 23:18:59', '2014-02-13 23:18:59', '', 50, 'http://localhost:8080/fixitall/?p=142', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (143, 1, '2014-02-13 23:19:34', '2014-02-13 23:19:34', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="Locally Owned and Operated" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing is locally owned, based and operated. The founders of the company, the staffs and everyone associated with the organization are from the city and surrounding areas of Paramount in California. While there is no standard rule that says locally owned companies are better than those having a nationwide presence or than the franchisees that are often catering to distant areas where they do not have a base, but the reality is that knowledge and awareness helps. When plumbers cater to areas that they are personal extremely familiar with, they are more aware of the challenges that a home, office or commercial property faces. For instance, if you are planning to install a new plumbing system, a local plumbing company would be helpful as they wouldn’t have to find out the building regulations. They would already know. At PluMax Plumbing, we already know the kinds of problems that residents, business owners and property managers face in Paramount and surrounding areas in California. Seldom do we need a briefing from our clients because of the knowledge and albeit due to our expertise.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="24/7 Emergency Plumbing" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Satisfaction Guarenteed" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has a unique offering where you are not only happy with the quality of work done but you would also be extremely satisfied with the entire experience. Right from the initial consultation through the schedule to the post service relation that we cherish with our clients, you would be completely satiated with every facet of our service and that is a guarantee.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Quality at an Affordable Price" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

Quality doesn’t come cheap and what comes cheap cannot be of great quality – such is the reality in many cases. With PluMax Plumbing, you experience an exception. We are one of the very few plumbing companies in the state that offers quality work at inexpensive rates.

[/et_pb_blurb][/et_pb_column][et_pb_column type="1_3"][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="David Bodner" url_new_window="off"]

I wholeheartedly recommend PluMax Plumbing for your residential plumbing needs. I have used their services on two occasions now. They are prompt, perform excellent work and charge fair prices. They clean up after their work and leave your house in excellent condition. Will use their services again.

[/et_pb_testimonial][/et_pb_column][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="Michael Bilnik" url_new_window="off"]

We have called Plumax Plumbing on two separation occasions. The first was a flooded basement. Josh gave us a competitive quote and installed a sump pump that works great. It was great to find a reliable, honest plumber who wouldn\'t take advantage of your dire situation. PluMax Plumbing also installed our hot water tank. And they did it quick and with respect for our property - leaving no mess behind. In both cases, we received professional installation. And more importantly, both projects stayed within the estimate, and our budget. If you\'re looking for a plumber you can trust, and afford, I highly recommend PluMax Plumbing!

[/et_pb_testimonial][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][et_pb_divider admin_label="Divider" color="#ffffff" show_divider="on" /][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 23:19:34', '2014-02-13 23:19:34', '', 50, 'http://localhost:8080/fixitall/?p=143', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (144, 1, '2014-02-13 23:20:35', '2014-02-13 23:20:35', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][/et_pb_column][et_pb_column type="1_3"][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="David Bodner" url_new_window="off"]

I wholeheartedly recommend PluMax Plumbing for your residential plumbing needs. I have used their services on two occasions now. They are prompt, perform excellent work and charge fair prices. They clean up after their work and leave your house in excellent condition. Will use their services again.

[/et_pb_testimonial][/et_pb_column][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="Michael Bilnik" url_new_window="off"]

We have called Plumax Plumbing on two separation occasions. The first was a flooded basement. Josh gave us a competitive quote and installed a sump pump that works great. It was great to find a reliable, honest plumber who wouldn\'t take advantage of your dire situation. PluMax Plumbing also installed our hot water tank. And they did it quick and with respect for our property - leaving no mess behind. In both cases, we received professional installation. And more importantly, both projects stayed within the estimate, and our budget. If you\'re looking for a plumber you can trust, and afford, I highly recommend PluMax Plumbing!

[/et_pb_testimonial][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][et_pb_divider admin_label="Divider" color="#ffffff" show_divider="on" /][et_pb_blurb admin_label="Blurb" title="Locally Owned and Operated" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing is locally owned, based and operated. The founders of the company, the staffs and everyone associated with the organization are from the city and surrounding areas of Paramount in California. While there is no standard rule that says locally owned companies are better than those having a nationwide presence or than the franchisees that are often catering to distant areas where they do not have a base, but the reality is that knowledge and awareness helps. When plumbers cater to areas that they are personal extremely familiar with, they are more aware of the challenges that a home, office or commercial property faces. For instance, if you are planning to install a new plumbing system, a local plumbing company would be helpful as they wouldn’t have to find out the building regulations. They would already know. At PluMax Plumbing, we already know the kinds of problems that residents, business owners and property managers face in Paramount and surrounding areas in California. Seldom do we need a briefing from our clients because of the knowledge and albeit due to our expertise.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="24/7 Emergency Plumbing" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Satisfaction Guarenteed" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has a unique offering where you are not only happy with the quality of work done but you would also be extremely satisfied with the entire experience. Right from the initial consultation through the schedule to the post service relation that we cherish with our clients, you would be completely satiated with every facet of our service and that is a guarantee.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Quality at an Affordable Price" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

Quality doesn’t come cheap and what comes cheap cannot be of great quality – such is the reality in many cases. With PluMax Plumbing, you experience an exception. We are one of the very few plumbing companies in the state that offers quality work at inexpensive rates.

[/et_pb_blurb][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 23:20:35', '2014-02-13 23:20:35', '', 50, 'http://localhost:8080/fixitall/?p=144', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (145, 1, '2014-02-13 23:21:01', '2014-02-13 23:21:01', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="David Bodner" url_new_window="off"]

I wholeheartedly recommend PluMax Plumbing for your residential plumbing needs. I have used their services on two occasions now. They are prompt, perform excellent work and charge fair prices. They clean up after their work and leave your house in excellent condition. Will use their services again.

[/et_pb_testimonial][/et_pb_column][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="Michael Bilnik" url_new_window="off"]

We have called Plumax Plumbing on two separation occasions. The first was a flooded basement. Josh gave us a competitive quote and installed a sump pump that works great. It was great to find a reliable, honest plumber who wouldn\'t take advantage of your dire situation. PluMax Plumbing also installed our hot water tank. And they did it quick and with respect for our property - leaving no mess behind. In both cases, we received professional installation. And more importantly, both projects stayed within the estimate, and our budget. If you\'re looking for a plumber you can trust, and afford, I highly recommend PluMax Plumbing!

[/et_pb_testimonial][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][et_pb_divider admin_label="Divider" color="#ffffff" show_divider="on" /][et_pb_blurb admin_label="Blurb" title="Locally Owned and Operated" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing is locally owned, based and operated. The founders of the company, the staffs and everyone associated with the organization are from the city and surrounding areas of Paramount in California. While there is no standard rule that says locally owned companies are better than those having a nationwide presence or than the franchisees that are often catering to distant areas where they do not have a base, but the reality is that knowledge and awareness helps. When plumbers cater to areas that they are personal extremely familiar with, they are more aware of the challenges that a home, office or commercial property faces. For instance, if you are planning to install a new plumbing system, a local plumbing company would be helpful as they wouldn’t have to find out the building regulations. They would already know. At PluMax Plumbing, we already know the kinds of problems that residents, business owners and property managers face in Paramount and surrounding areas in California. Seldom do we need a briefing from our clients because of the knowledge and albeit due to our expertise.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="24/7 Emergency Plumbing" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Satisfaction Guarenteed" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has a unique offering where you are not only happy with the quality of work done but you would also be extremely satisfied with the entire experience. Right from the initial consultation through the schedule to the post service relation that we cherish with our clients, you would be completely satiated with every facet of our service and that is a guarantee.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Quality at an Affordable Price" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

Quality doesn’t come cheap and what comes cheap cannot be of great quality – such is the reality in many cases. With PluMax Plumbing, you experience an exception. We are one of the very few plumbing companies in the state that offers quality work at inexpensive rates.

[/et_pb_blurb][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 23:21:01', '2014-02-13 23:21:01', '', 50, 'http://localhost:8080/fixitall/?p=145', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (146, 1, '2014-02-13 23:22:05', '2014-02-13 23:22:05', '[et_pb_section][et_pb_row][et_pb_column type="4_4"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][et_pb_divider admin_label="Divider" color="#ffffff" show_divider="on" /][et_pb_blurb admin_label="Blurb" title="Locally Owned and Operated" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing is locally owned, based and operated. The founders of the company, the staffs and everyone associated with the organization are from the city and surrounding areas of Paramount in California. While there is no standard rule that says locally owned companies are better than those having a nationwide presence or than the franchisees that are often catering to distant areas where they do not have a base, but the reality is that knowledge and awareness helps. When plumbers cater to areas that they are personal extremely familiar with, they are more aware of the challenges that a home, office or commercial property faces. For instance, if you are planning to install a new plumbing system, a local plumbing company would be helpful as they wouldn’t have to find out the building regulations. They would already know. At PluMax Plumbing, we already know the kinds of problems that residents, business owners and property managers face in Paramount and surrounding areas in California. Seldom do we need a briefing from our clients because of the knowledge and albeit due to our expertise.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="24/7 Emergency Plumbing" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Satisfaction Guarenteed" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has a unique offering where you are not only happy with the quality of work done but you would also be extremely satisfied with the entire experience. Right from the initial consultation through the schedule to the post service relation that we cherish with our clients, you would be completely satiated with every facet of our service and that is a guarantee.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Quality at an Affordable Price" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

Quality doesn’t come cheap and what comes cheap cannot be of great quality – such is the reality in many cases. With PluMax Plumbing, you experience an exception. We are one of the very few plumbing companies in the state that offers quality work at inexpensive rates.

[/et_pb_blurb][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="David Bodner" url_new_window="off"]

I wholeheartedly recommend PluMax Plumbing for your residential plumbing needs. I have used their services on two occasions now. They are prompt, perform excellent work and charge fair prices. They clean up after their work and leave your house in excellent condition. Will use their services again.

[/et_pb_testimonial][/et_pb_column][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="Michael Bilnik" url_new_window="off"]

We have called Plumax Plumbing on two separation occasions. The first was a flooded basement. Josh gave us a competitive quote and installed a sump pump that works great. It was great to find a reliable, honest plumber who wouldn\'t take advantage of your dire situation. PluMax Plumbing also installed our hot water tank. And they did it quick and with respect for our property - leaving no mess behind. In both cases, we received professional installation. And more importantly, both projects stayed within the estimate, and our budget. If you\'re looking for a plumber you can trust, and afford, I highly recommend PluMax Plumbing!

[/et_pb_testimonial][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 23:22:05', '2014-02-13 23:22:05', '', 50, 'http://localhost:8080/fixitall/?p=146', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (147, 1, '2014-02-13 23:43:26', '2014-02-13 23:43:26', '[et_pb_section][et_pb_row][et_pb_column type="1_3"][et_pb_cta admin_label="Call To Action" title="Call Now!" background_color="#7EBEC5" use_background_color="on" background_layout="dark" text_orientation="center"]
<h1>(310) 555-1212[/et_pb_cta][/et_pb_column][et_pb_column type="2_3"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]</h1>
<h1>Why choose us</h1>
There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and V-Max Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][et_pb_divider admin_label="Divider" color="#ffffff" show_divider="on" /][et_pb_blurb admin_label="Blurb" title="Locally Owned and Operated" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing is locally owned, based and operated. The founders of the company, the staffs and everyone associated with the organization are from the city and surrounding areas of Paramount in California. While there is no standard rule that says locally owned companies are better than those having a nationwide presence or than the franchisees that are often catering to distant areas where they do not have a base, but the reality is that knowledge and awareness helps. When plumbers cater to areas that they are personal extremely familiar with, they are more aware of the challenges that a home, office or commercial property faces. For instance, if you are planning to install a new plumbing system, a local plumbing company would be helpful as they wouldn’t have to find out the building regulations. They would already know. At PluMax Plumbing, we already know the kinds of problems that residents, business owners and property managers face in Paramount and surrounding areas in California. Seldom do we need a briefing from our clients because of the knowledge and albeit due to our expertise.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="24/7 Emergency Plumbing" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Satisfaction Guarenteed" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has a unique offering where you are not only happy with the quality of work done but you would also be extremely satisfied with the entire experience. Right from the initial consultation through the schedule to the post service relation that we cherish with our clients, you would be completely satiated with every facet of our service and that is a guarantee.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Quality at an Affordable Price" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

Quality doesn’t come cheap and what comes cheap cannot be of great quality – such is the reality in many cases. With PluMax Plumbing, you experience an exception. We are one of the very few plumbing companies in the state that offers quality work at inexpensive rates.

[/et_pb_blurb][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="David Bodner" url_new_window="off"]

I wholeheartedly recommend PluMax Plumbing for your residential plumbing needs. I have used their services on two occasions now. They are prompt, perform excellent work and charge fair prices. They clean up after their work and leave your house in excellent condition. Will use their services again.

[/et_pb_testimonial][/et_pb_column][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="Michael Bilnik" url_new_window="off"]

We have called Plumax Plumbing on two separation occasions. The first was a flooded basement. Josh gave us a competitive quote and installed a sump pump that works great. It was great to find a reliable, honest plumber who wouldn\'t take advantage of your dire situation. PluMax Plumbing also installed our hot water tank. And they did it quick and with respect for our property - leaving no mess behind. In both cases, we received professional installation. And more importantly, both projects stayed within the estimate, and our budget. If you\'re looking for a plumber you can trust, and afford, I highly recommend PluMax Plumbing!

[/et_pb_testimonial][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-13 23:43:26', '2014-02-13 23:43:26', '', 50, 'http://localhost:8080/fixitall/?p=147', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (148, 1, '2014-02-16 18:40:12', '2014-02-16 18:40:12', '[et_pb_section][et_pb_row][et_pb_column type="1_3"][et_pb_cta admin_label="Call To Action" title="Call Now!" background_color="#7EBEC5" use_background_color="on" background_layout="dark" text_orientation="center"]
<h1>(310) 555-1212[/et_pb_cta][/et_pb_column][et_pb_column type="2_3"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]<h1>Why choose us</h1><p>There are many plumbing companies in California and there are more than a dozen servicing the entire Los Angeles County. How do you choose a plumbing company in Paramount and surrounding areas in California? Do you have a list of criteria based on which you can assess the positive attributes and shortcomings of plumbers in your area? Any decision has to be based on factual information and PluMax Plumbing gives you more than half a dozen reasons that would more than rationalize why you should choose our services.</p>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="2_3"][et_pb_slider admin_label="Slider" show_arrows="on" show_pagination="on" parallax="off" auto="on" auto_speed="7000"][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumber-guy2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide2.jpg" background_color="#ffffff" background_layout="dark" /][et_pb_slide background_image="http://localhost:8080/fixitall//wp-content/uploads/2014/02/plumbing-slide3.jpg" background_color="#ffffff" background_layout="dark" /][/et_pb_slider][et_pb_divider admin_label="Divider" color="#ffffff" show_divider="on" /][et_pb_blurb admin_label="Blurb" title="Locally Owned and Operated" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing is locally owned, based and operated. The founders of the company, the staffs and everyone associated with the organization are from the city and surrounding areas of Paramount in California. While there is no standard rule that says locally owned companies are better than those having a nationwide presence or than the franchisees that are often catering to distant areas where they do not have a base, but the reality is that knowledge and awareness helps. When plumbers cater to areas that they are personal extremely familiar with, they are more aware of the challenges that a home, office or commercial property faces. For instance, if you are planning to install a new plumbing system, a local plumbing company would be helpful as they wouldn’t have to find out the building regulations. They would already know. At PluMax Plumbing, we already know the kinds of problems that residents, business owners and property managers face in Paramount and surrounding areas in California. Seldom do we need a briefing from our clients because of the knowledge and albeit due to our expertise.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="24/7 Emergency Plumbing" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Satisfaction Guarenteed" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

PluMax Plumbing has a unique offering where you are not only happy with the quality of work done but you would also be extremely satisfied with the entire experience. Right from the initial consultation through the schedule to the post service relation that we cherish with our clients, you would be completely satiated with every facet of our service and that is a guarantee.

[/et_pb_blurb][et_pb_blurb admin_label="Blurb" title="Quality at an Affordable Price" url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

Quality doesn’t come cheap and what comes cheap cannot be of great quality – such is the reality in many cases. With PluMax Plumbing, you experience an exception. We are one of the very few plumbing companies in the state that offers quality work at inexpensive rates.

[/et_pb_blurb][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="David Bodner" url_new_window="off"]

I wholeheartedly recommend PluMax Plumbing for your residential plumbing needs. I have used their services on two occasions now. They are prompt, perform excellent work and charge fair prices. They clean up after their work and leave your house in excellent condition. Will use their services again.

[/et_pb_testimonial][/et_pb_column][et_pb_column type="1_2"][et_pb_testimonial admin_label="Testimonial" author="Michael Bilnik" url_new_window="off"]

We have called Plumax Plumbing on two separation occasions. The first was a flooded basement. Josh gave us a competitive quote and installed a sump pump that works great. It was great to find a reliable, honest plumber who wouldn\'t take advantage of your dire situation. PluMax Plumbing also installed our hot water tank. And they did it quick and with respect for our property - leaving no mess behind. In both cases, we received professional installation. And more importantly, both projects stayed within the estimate, and our budget. If you\'re looking for a plumber you can trust, and afford, I highly recommend PluMax Plumbing!

[/et_pb_testimonial][/et_pb_column][/et_pb_row][/et_pb_section]', 'Home', '', 'inherit', 'open', 'open', '', '50-revision-v1', '', '', '2014-02-16 18:40:12', '2014-02-16 18:40:12', '', 50, 'http://localhost:8080/fixitall/?p=148', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (149, 1, '2014-02-16 18:41:32', '2014-02-16 18:41:32', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_blurb admin_label="Blurb" title="At PluMax Plumbing, we focus on providing quality. inexpensive commercial plumbing from Santa Monica to Seal Beach." url_new_window="off" animation="top" background_layout="light" text_orientation="center"]

<hr />



<hr />
<p style="text-align: left;">PluMax Plumbing specializes in commercial and residential plumbing. The two may seem similar in many ways but the sheer scale, difference in specific purposes and the nature of the plumbing fixtures are the dissimilarities that a plumber has to deal with. Every staff at PluMax Plumbing is trained and experienced on both residential and commercial plumbing. To cater to the former there is a greater demand of sensitivity and delicate work while the latter demands larger infrastructures, manpower capacity and ability to handle massive tasks. PluMax Plumbing can attend to any plumbing need you may have at Paramount and surrounding areas in California. PluMax Plumbing has designated business hours when you can call us at our office and you can conveniently schedule the plumbing installation, repair, maintenance or replacement but we also have a round the clock emergency service. Whether it is a weekend or a national holiday, at the dead hours of the night or in the wee hours of the morning, if you need the services of a plumbing company on an emergency basis, you would always find us ready to drive out to your place.</p>
[/et_pb_blurb][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177.jpg"><img class="size-thumbnail wp-image-93 alignleft" alt="Drain-by-Seannnnnnn-e1374301069177" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Drain-by-Seannnnnnn-e1374301069177-150x150.jpg" width="150" height="150" /></a>
<h4>Unclog Your Drain</h4>
We can help remove drain stoppages in your office/retail location, from toilets to sinks, there’s no drain we can’t drain or replace.[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479.jpg"><img class="size-thumbnail wp-image-107 alignleft" alt="Root-Intrusion-by-Wilf-Ratzburg-e1374302277479" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Root-Intrusion-by-Wilf-Ratzburg-e1374302277479-150x150.jpg" width="150" height="150" /></a>
<h4>Fix Root Intrusions</h4>
We’ll get to the root of the problem! Old clay pipes can be damaged and leak because of inferior materials used in older construction.

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Gas-leak-by-Crow-Girl-e1374331227435.jpg"><img class="size-thumbnail wp-image-114 alignleft" alt="Gas-leak-by-Crow-Girl-e1374331227435" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Gas-leak-by-Crow-Girl-e1374331227435-150x150.jpg" width="150" height="150" /></a>
<h4>Detect Gas Leaks</h4>
We can test your office/retail location for a gas leak, shut-off a gas leak and repair a gas leak.

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]

<a href="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Reinstall-Pipes-by-Michaela-Kobyakov-V-Max-plumbing-e1374362282501.jpg"><img class="size-thumbnail wp-image-117 alignleft" alt="Reinstall-Pipes-by-Michaela-Kobyakov-V-Max-plumbing-e1374362282501" src="http://localhost:8080/fixitall//wp-content/uploads/2014/02/Reinstall-Pipes-by-Michaela-Kobyakov-V-Max-plumbing-e1374362282501-150x150.jpg" width="150" height="150" /></a>
<h4>Reinstall Pipes</h4>
We can reinstall pipes in your walls, including removing your old galvanized pipes and replacing them with modern, type “L”, copper pipes.

[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'Commercial/Residential', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-02-16 18:41:32', '2014-02-16 18:41:32', '', 41, 'http://localhost:8080/fixitall/?p=149', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (150, 1, '2014-02-16 18:42:35', '2014-02-16 18:42:35', '[et_pb_section][et_pb_row][et_pb_column type="2_3"][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h2>The Most Reliable Plumber In Southern California</h2>
[box]

Over the years, the quality, efficacy, affordability and longevity of the work done by PluMax Plumbing has made us the most trusted and favorite plumbers for homeowners as well as commercial property owners. PluMax Plumbing specializes in all kinds of plumbing tasks.

Whether you need a particular plumbing fixture repaired or you are looking for a complete overhaul of your plumbing systems, PluMax Plumbing is the best choice at your discretion. No job is too big and no task is too small for us at PluMax Plumbing.

[/box]

[/et_pb_text][et_pb_text admin_label="Text" background_layout="light" text_orientation="left"]
<h2>Experienced Combined With Unparalleled Service</h2>
[box] PluMax Plumbing has always put customers first. While dealing with us, right from the first phone call or email to the invoicing and post service interactions or consultations, you would experience unparallel service.
<ul>
	<li>PluMax Plumbing offers prompt and dependable service. Our teams would be at your site at the time that is promised and would get the job done as promised.</li>
	<li>You have the luxury to opt for a schedule that is convenient for you. You can take into account all the factors that are important to you and then choose a certain schedule when the team from PluMax Plumbing can get the job done and we would do exactly according to that.</li>
	<li>PluMax Plumbing has the distinction of offering extremely reasonable rates, even for the most complex plumbing installations, repairs and maintenance.</li>
</ul>
Call us today at (310) 555-1212 and let us handle all of your plumbing needs with unmatchable expertise and impeccable service at extremely reasonable rates.

[/box]

[/et_pb_text][/et_pb_column][et_pb_column type="1_3"][et_pb_sidebar admin_label="Sidebar" orientation="right" area="sidebar-1" background_layout="light" /][/et_pb_column][/et_pb_row][/et_pb_section]', 'About', '', 'inherit', 'open', 'open', '', '71-revision-v1', '', '', '2014-02-16 18:42:35', '2014-02-16 18:42:35', '', 71, 'http://localhost:8080/fixitall/?p=150', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (154, 1, '2014-04-29 17:51:32', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-04-29 17:51:32', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/fixitall/?p=154', 0, 'post', '', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://localhost:8080/fixitall MySQL database backup
#
# Generated: Wednesday 30. April 2014 03:27 UTC
# Hostname: localhost
# Database: `fixitall`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_messages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_emails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_stats`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_relationships (7 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (38, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (49, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (75, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (76, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (133, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (133, 4, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost:8080/fixitall MySQL database backup
#
# Generated: Wednesday 30. April 2014 03:27 UTC
# Hostname: localhost
# Database: `fixitall`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_messages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_emails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_stats`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_taxonomy (4 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (2, 2, 'nav_menu', '', 0, 4) ; 
INSERT INTO `wp_term_taxonomy` VALUES (3, 3, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (4, 4, 'post_tag', '', 0, 1) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost:8080/fixitall MySQL database backup
#
# Generated: Wednesday 30. April 2014 03:27 UTC
# Hostname: localhost
# Database: `fixitall`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_messages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_emails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_stats`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_terms (4 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wp_terms` VALUES (2, 'Menu 1', 'menu-1', 0) ; 
INSERT INTO `wp_terms` VALUES (3, 'news', 'news', 0) ; 
INSERT INTO `wp_terms` VALUES (4, 'plumbing', 'plumbing', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://localhost:8080/fixitall MySQL database backup
#
# Generated: Wednesday 30. April 2014 03:27 UTC
# Hostname: localhost
# Database: `fixitall`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_messages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_emails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_stats`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_usermeta (19 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'nickname', 'admin') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'show_welcome_panel', '1') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'wp_dashboard_quick_press_last_post_id', '154') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'metaboxhidden_nav-menus', 'a:5:{i:0;s:8:"add-post";i:1;s:11:"add-project";i:2;s:12:"add-post_tag";i:3;s:20:"add-project_category";i:4;s:15:"add-project_tag";}') ; 
INSERT INTO `wp_usermeta` VALUES (17, 1, 'nav_menu_recently_edited', '2') ; 
INSERT INTO `wp_usermeta` VALUES (18, 1, 'wp_user-settings', 'editor=tinymce&libraryContent=browse&imgsize=thumbnail&hidetb=1') ; 
INSERT INTO `wp_usermeta` VALUES (19, 1, 'wp_user-settings-time', '1392576008') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://localhost:8080/fixitall MySQL database backup
#
# Generated: Wednesday 30. April 2014 03:27 UTC
# Hostname: localhost
# Database: `fixitall`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_messages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_emails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_stats`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_users (1 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'admin', '$P$BJqFTO3CKecX8z6L8/jEKh9DTP6owM1', 'admin', 'kshoufer@gmail.com', '', '2014-02-13 15:22:51', '', 0, 'admin') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

# WordPress : http://localhost:8080/fixitall MySQL database backup
#
# Generated: Wednesday 30. April 2014 03:27 UTC
# Hostname: localhost
# Database: `fixitall`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cftemail_messages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_emails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_newsletter_stats`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_w3tc_cdn_queue`
# --------------------------------------------------------


#
# Delete any existing table `wp_w3tc_cdn_queue`
#

DROP TABLE IF EXISTS `wp_w3tc_cdn_queue`;


#
# Table structure of table `wp_w3tc_cdn_queue`
#

CREATE TABLE `wp_w3tc_cdn_queue` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `local_path` varchar(500) NOT NULL DEFAULT '',
  `remote_path` varchar(500) NOT NULL DEFAULT '',
  `command` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 - Upload, 2 - Delete, 3 - Purge',
  `last_error` varchar(150) NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `path` (`local_path`,`remote_path`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_w3tc_cdn_queue (0 records)
#

#
# End of data contents of table wp_w3tc_cdn_queue
# --------------------------------------------------------

